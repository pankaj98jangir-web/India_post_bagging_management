export type OfficeName = 
  | 'Indore RMS L1U'
  | 'Indore TMO'
  | 'Indore PH'
  | 'Indore NSH';

export type SetName = 
  | 'SET/1'
  | 'SET/2'
  | 'SET/2A'
  | 'SET/2B'
  | 'SET/3A'
  | 'SET/3B';

export type BagStatus = 
  | 'received for open'
  | 'received for forwarding'
  | 'opened'
  | 'closed'
  | 'despatched';

export type ArticleType = 'Speed Post' | 'Parcel' | 'Registered';

export interface UserSession {
  userId: string;
  officeName: OfficeName;
  setName: SetName;
  loginTime: string;
}

export interface ArticleItem {
  id: string;
  articleNumber: string; // 13 characters (e.g. EE123456789IN)
  articleType: ArticleType;
  isInsured: boolean;
  scannedAt: string;
  bagBarcode?: string;
  destinationOffice?: string;
  weightGrams?: number;
}

export interface BagRecord {
  id: string;
  bagBarcode: string; // 13 characters
  sourceOffice: string;
  destinationOffice: string;
  finalDestinationOffice?: string;
  bagStatus: BagStatus;
  speedPostCount: number;
  insuredCount: number;
  totalArticlesCount: number;
  setName: SetName;
  officeName: OfficeName;
  receivedAt?: string;
  openedAt?: string;
  closedAt?: string;
  despatchedAt?: string;
  isDepositBag?: boolean;
  targetSetForDeposit?: string;
  bagWeightKg?: number;
  articles: ArticleItem[];
  despatchScheduleId?: string;
}

export interface DespatchSchedule {
  id: string;
  scheduleCode: string; // e.g. "SCH-01"
  scheduleName: string; // e.g. "Indore - Bhopal NSH Morning Transit"
  destinationOffice: string; // Destination Office (Transit Hub / Section / NSH)
  finalDestinationOffices: string[]; // Final Destination Offices under this destination office
  transitMode: 'Road / MMS' | 'Train / RMS' | 'Air Mail' | 'Special Van';
  departureTime?: string; // e.g. "10:30"
  carrierOrVehicle?: string; // e.g. "MMS Van MP-09-AB-1234"
  remarks?: string;
  createdAt?: string;
  updatedAt?: string;
  isSystemDefault?: boolean;
}

export interface FinalDestinationBifurcation {
  finalDestinationOffice: string;
  pincode?: string;
  bags: BagRecord[];
  totalBags: number;
  totalWeightKg: number;
  totalArticles: number;
  speedPostCount: number;
  insuredCount: number;
}

export interface DestinationOfficeBifurcation {
  destinationOffice: string;
  totalBags: number;
  totalWeightKg: number;
  totalArticles: number;
  finalDestinations: FinalDestinationBifurcation[];
}

export interface DespatchRecord {
  id: string;
  scheduleId: string;
  scheduleCode?: string;
  scheduleName?: string;
  transitMode?: string;
  departureTime?: string;
  carrierOrVehicle?: string;
  destinationOffice: string;
  setName: SetName;
  officeName: OfficeName;
  despatchedAt: string;
  bags: BagRecord[];
  totalBags: number;
  totalWeightKg: number;
  bifurcatedGroups?: DestinationOfficeBifurcation[];
}

export interface ActionSuccessDetails {
  title: string;
  subtitle?: string;
  badge?: string;
  barcode?: string;
  actionType: 'receive' | 'forward_receive' | 'open' | 'close' | 'despatch' | 'deposit_close';
  details: { label: string; value: string | number }[];
  bag?: BagRecord;
}

export interface ShiftSummary {
  totalBagsReceived: number;
  totalBagsForwardReceived: number;
  totalBagsOpened: number;
  totalBagsClosed: number;
  totalBagsDespatched: number;
  totalDepositBags: number;
  totalArticlesProcessed: number;
  totalWeightKg: number;
  speedPostArticles: number;
  insuredArticles: number;
}

export interface ShiftRecord {
  id: string;
  shiftDate: string; // YYYY-MM-DD
  startTime: string;
  endTime?: string;
  officeName: OfficeName;
  setName: SetName;
  userId: string; // 8-digit operator ID
  status: 'active' | 'ended';
  bags: BagRecord[];
  despatches: DespatchRecord[];
  summary: ShiftSummary;
  handoverRemarks?: string;
  supervisorSignOff?: string;
  savedAt?: string;
}

// Sub Tab 11: Create Consolidated Abstract Manual Types
export interface ManualBagAbstractRow {
  id: string;
  employeeId: string;
  employeeName: string;
  bagReceived: number | '';
  bagClosed: number | '';
  bagDispatched: number | '';
}

export interface ManualArticleAbstractRow {
  id: string;
  employeeId: string;
  employeeName: string;
  articleClosed: number | '';
  insuredArticleClosed: number | '';
  totalArticleClosed: number | '';
}

export interface ManualConsolidatedAbstractData {
  id: string;
  date: string;
  officeName: string;
  setName: string;
  supervisorName: string;
  bagRows: ManualBagAbstractRow[];
  articleRows: ManualArticleAbstractRow[];
  notes?: string;
  savedAt?: string;
}

// Sub Tab 12: Generate Barcode Types
export interface GeneratedBarcodeItem {
  id: string;
  barcode: string;
  destinationOffice: string; // Blank if not chosen
  bagWeightKg: number;
  sourceOffice: string;
  bagType: string;
  generatedAt: string;
}

