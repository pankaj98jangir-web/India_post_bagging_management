import React from 'react';

export const DopLogo: React.FC<{ className?: string; size?: number }> = ({ className = '', size = 48 }) => {
  return (
    <div className={`inline-flex items-center gap-2 ${className}`}>
      {/* Official India Post / Department of Posts Emblem Symbol */}
      <div 
        className="relative flex items-center justify-center rounded-sm bg-[#c92228] text-white font-bold shadow-xs select-none"
        style={{ width: size, height: size }}
      >
        <svg viewBox="0 0 100 100" className="w-[82%] h-[82%] fill-current">
          {/* Stylized India Post postal bird / red envelope wing mark */}
          <path d="M10 20 L90 20 L90 80 L10 80 Z" fill="#ffd100" />
          <path d="M10 20 L50 55 L90 20 Z" fill="#c92228" />
          <path d="M18 30 L82 75 L82 78 L18 78 Z" fill="#c92228" opacity="0.3" />
          <polygon points="50,45 88,78 12,78" fill="#a01217" />
          {/* Post winged arrow */}
          <path d="M25 50 Q50 30 78 46 L70 54 Q48 40 32 58 Z" fill="#ffffff" />
        </svg>
      </div>
      <div className="flex flex-col leading-tight">
        <span className="text-[10px] font-semibold tracking-wider text-neutral-800 uppercase">भारतीय डाक</span>
        <span className="text-xs font-black tracking-widest text-[#c92228] uppercase">India Post</span>
      </div>
    </div>
  );
};
