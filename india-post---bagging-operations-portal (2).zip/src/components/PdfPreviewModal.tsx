import React from 'react';
import { FileText, Download, ExternalLink, Printer, X, ShieldCheck } from 'lucide-react';
import { GeneratedPdfResult, DocumentType } from '../utils/pdfGenerator';

interface PdfPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  pdfResult: GeneratedPdfResult | null;
  docType: DocumentType;
  title: string;
}

export const PdfPreviewModal: React.FC<PdfPreviewModalProps> = ({
  isOpen,
  onClose,
  pdfResult,
  docType,
  title,
}) => {
  if (!isOpen || !pdfResult) return null;

  const docTypeLabel =
    docType === 'label'
      ? 'Official Bag Label (120mm × 70mm)'
      : docType === 'manifest'
      ? 'Bag Manifest Form M-52 (A4 Portrait)'
      : 'Despatch Mail Delivery Bill Form M-11 (A4 Portrait)';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-neutral-900/80 backdrop-blur-xs p-3 sm:p-5">
      <div className="bg-white rounded-2xl shadow-2xl border border-neutral-200 w-full max-w-5xl h-[92vh] flex flex-col overflow-hidden animate-in fade-in duration-150">
        {/* Modal Header */}
        <div className="bg-[#c92228] text-white px-5 py-3.5 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/10 rounded-lg">
              <FileText size={22} className="text-amber-200" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-sm sm:text-base leading-tight">
                  {title}
                </h3>
                <span className="hidden sm:inline-block text-[10px] uppercase font-bold bg-amber-400 text-neutral-950 px-2 py-0.5 rounded-xs">
                  Pure PDF
                </span>
              </div>
              <p className="text-xs text-amber-100/90 mt-0.5 flex items-center gap-2">
                <span>{docTypeLabel}</span>
                <span>•</span>
                <span className="font-mono">{pdfResult.fileName}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Open in New Window Button */}
            <button
              type="button"
              onClick={pdfResult.openInNewWindow}
              title="Open PDF in new browser tab / window"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white/15 hover:bg-white/25 text-white rounded-lg text-xs font-semibold transition-colors cursor-pointer"
            >
              <ExternalLink size={14} />
              <span className="hidden sm:inline">Open in New Tab</span>
            </button>

            {/* Direct Download Button */}
            <button
              type="button"
              onClick={pdfResult.download}
              title="Download standalone PDF document"
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-amber-400 hover:bg-amber-300 text-neutral-950 font-bold rounded-lg text-xs transition-colors shadow-xs cursor-pointer"
            >
              <Download size={14} />
              <span>Download PDF</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-white/80 hover:text-white hover:bg-white/20 rounded-lg transition-colors cursor-pointer ml-1"
              title="Close Preview"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Notice Bar */}
        <div className="bg-neutral-100 border-b border-neutral-200 px-5 py-2 flex items-center justify-between text-xs text-neutral-700 shrink-0">
          <div className="flex items-center gap-2 font-medium">
            <ShieldCheck size={16} className="text-emerald-600" />
            <span>
              Standalone PDF document generated. Website layout, sidebars, and navigation buttons are excluded.
            </span>
          </div>
          <div className="flex items-center gap-2 text-[11px] font-mono text-neutral-500">
            <span>Size: {docType === 'label' ? '120×70 mm' : 'A4'}</span>
          </div>
        </div>

        {/* PDF Viewer Container */}
        <div className="flex-1 bg-neutral-200 p-2 sm:p-4 overflow-hidden flex items-center justify-center">
          <iframe
            src={`${pdfResult.blobUrl}#toolbar=1&navpanes=0`}
            title="PDF Document Preview"
            className="w-full h-full rounded-lg bg-white shadow-md border border-neutral-300"
          />
        </div>

        {/* Footer */}
        <div className="bg-white border-t border-neutral-200 px-5 py-2.5 flex items-center justify-between text-xs shrink-0">
          <span className="text-neutral-500 text-[11px]">
            Department of Posts (MNOP) • Standalone PDF Export Module
          </span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={pdfResult.download}
              className="px-3 py-1.5 bg-neutral-100 hover:bg-neutral-200 text-neutral-700 font-semibold rounded-md border border-neutral-300 text-xs cursor-pointer flex items-center gap-1.5"
            >
              <Download size={13} />
              Save As File
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 bg-neutral-800 hover:bg-neutral-900 text-white font-semibold rounded-md text-xs cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
