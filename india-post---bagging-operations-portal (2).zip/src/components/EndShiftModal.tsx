import React, { useState } from 'react';
import { ShiftRecord, BagRecord, DespatchRecord } from '../types';
import { calculateShiftSummary, formatIndianDate } from '../utils/shiftStorage';
import {
  StopCircle,
  Save,
  CheckCircle2,
  Package,
  Layers,
  Clock,
  Building,
  UserCheck,
  Calendar,
  X,
  FileSpreadsheet,
  AlertCircle,
  Truck,
  ShieldCheck,
  Scale,
} from 'lucide-react';

interface EndShiftModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeShift: ShiftRecord;
  bags: BagRecord[];
  despatches: DespatchRecord[];
  onConfirmEndShift: (params: {
    handoverRemarks: string;
    supervisorSignOff: string;
  }) => void;
}

export const EndShiftModal: React.FC<EndShiftModalProps> = ({
  isOpen,
  onClose,
  activeShift,
  bags,
  despatches,
  onConfirmEndShift,
}) => {
  const [handoverRemarks, setHandoverRemarks] = useState<string>(
    'All bags processed, closed, and accounted for according to MNOP schedule.'
  );
  const [supervisorSignOff, setSupervisorSignOff] = useState<string>(
    'Verified by Head Sorting Assistant / Supervisor'
  );

  if (!isOpen) return null;

  const summary = calculateShiftSummary(bags, despatches);
  const currentTime = new Date().toLocaleTimeString('en-IN', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onConfirmEndShift({
      handoverRemarks: handoverRemarks.trim(),
      supervisorSignOff: supervisorSignOff.trim(),
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-3 sm:p-5 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full overflow-hidden border border-neutral-200 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-[#c92228] text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/15 rounded-xl">
              <StopCircle size={24} className="text-amber-300" />
            </div>
            <div>
              <h3 className="font-bold text-base leading-tight">Shift End • Close & Save Shift Data</h3>
              <p className="text-xs text-amber-200/90 mt-0.5">
                Save full operational statistics & bag records to local storage for future reference
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 hover:bg-white/15 rounded-lg text-white/80 hover:text-white transition-colors cursor-pointer"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content & Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* Shift Identity Strip */}
          <div className="bg-neutral-50 rounded-xl p-3.5 border border-neutral-200 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <Calendar size={14} className="text-neutral-500" />
              <span className="font-bold text-neutral-800">
                Date: {formatIndianDate(activeShift.shiftDate)}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Building size={14} className="text-neutral-500" />
              <span className="font-semibold text-neutral-700">{activeShift.officeName}</span>
            </div>
            <div className="flex items-center gap-2">
              <Layers size={14} className="text-amber-700" />
              <span className="font-bold text-amber-800">{activeShift.setName}</span>
            </div>
            <div className="flex items-center gap-2">
              <UserCheck size={14} className="text-emerald-700" />
              <span className="font-mono font-bold text-neutral-800">ID: {activeShift.userId}</span>
            </div>
            <div className="flex items-center gap-2 text-neutral-600">
              <Clock size={14} className="text-blue-600" />
              <span>Started: {activeShift.startTime}</span>
              <span>→</span>
              <span className="font-bold text-neutral-900">Ending: {currentTime}</span>
            </div>
          </div>

          {/* Operational Statistics Matrix */}
          <div>
            <h4 className="text-xs font-bold text-neutral-800 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <FileSpreadsheet size={14} className="text-[#c92228]" />
              <span>Shift Performance Summary (To be Saved in Local Storage)</span>
            </h4>
            
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              <div className="bg-blue-50/70 border border-blue-200 rounded-xl p-3 text-center">
                <span className="text-[11px] font-semibold text-blue-700 uppercase block mb-1">
                  Received for Open
                </span>
                <span className="text-xl font-black text-blue-950 font-mono">
                  {summary.totalBagsReceived}
                </span>
                <span className="text-[10px] text-blue-600 block mt-0.5">Bags</span>
              </div>

              <div className="bg-purple-50/70 border border-purple-200 rounded-xl p-3 text-center">
                <span className="text-[11px] font-semibold text-purple-700 uppercase block mb-1">
                  Received Forwarding
                </span>
                <span className="text-xl font-black text-purple-950 font-mono">
                  {summary.totalBagsForwardReceived}
                </span>
                <span className="text-[10px] text-purple-600 block mt-0.5">Bags</span>
              </div>

              <div className="bg-emerald-50/70 border border-emerald-200 rounded-xl p-3 text-center">
                <span className="text-[11px] font-semibold text-emerald-700 uppercase block mb-1">
                  Bags Opened
                </span>
                <span className="text-xl font-black text-emerald-950 font-mono">
                  {summary.totalBagsOpened}
                </span>
                <span className="text-[10px] text-emerald-600 block mt-0.5">Bags</span>
              </div>

              <div className="bg-amber-50/70 border border-amber-200 rounded-xl p-3 text-center">
                <span className="text-[11px] font-semibold text-amber-700 uppercase block mb-1">
                  Bags Closed
                </span>
                <span className="text-xl font-black text-amber-950 font-mono">
                  {summary.totalBagsClosed}
                </span>
                <span className="text-[10px] text-amber-600 block mt-0.5">Bags</span>
              </div>

              <div className="bg-red-50/70 border border-red-200 rounded-xl p-3 text-center">
                <span className="text-[11px] font-semibold text-red-700 uppercase block mb-1">
                  Despatched
                </span>
                <span className="text-xl font-black text-red-950 font-mono">
                  {summary.totalBagsDespatched}
                </span>
                <span className="text-[10px] text-red-600 block mt-0.5">Bags</span>
              </div>

              <div className="bg-neutral-100 border border-neutral-200 rounded-xl p-3 text-center">
                <span className="text-[11px] font-semibold text-neutral-600 uppercase block mb-1">
                  Articles Processed
                </span>
                <span className="text-xl font-black text-neutral-900 font-mono">
                  {summary.totalArticlesProcessed}
                </span>
                <span className="text-[10px] text-neutral-500 block mt-0.5">Speed/Insured</span>
              </div>

              <div className="bg-neutral-100 border border-neutral-200 rounded-xl p-3 text-center">
                <span className="text-[11px] font-semibold text-neutral-600 uppercase block mb-1">
                  Total Weight
                </span>
                <span className="text-xl font-black text-neutral-900 font-mono">
                  {summary.totalWeightKg}
                </span>
                <span className="text-[10px] text-neutral-500 block mt-0.5">Kilograms (Kg)</span>
              </div>

              <div className="bg-neutral-100 border border-neutral-200 rounded-xl p-3 text-center">
                <span className="text-[11px] font-semibold text-neutral-600 uppercase block mb-1">
                  Despatches Logged
                </span>
                <span className="text-xl font-black text-neutral-900 font-mono">
                  {despatches.length}
                </span>
                <span className="text-[10px] text-neutral-500 block mt-0.5">Schedules</span>
              </div>
            </div>
          </div>

          {/* Handover Remarks & Supervisory Sign-off */}
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-neutral-800 uppercase tracking-wider mb-1">
                Handover & Shift Remarks
              </label>
              <textarea
                rows={2}
                value={handoverRemarks}
                onChange={(e) => setHandoverRemarks(e.target.value)}
                className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-xs text-neutral-900 focus:outline-hidden focus:ring-2 focus:ring-[#c92228]"
                placeholder="Enter handover notes, pending bags if any, or mail irregularities..."
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-neutral-800 uppercase tracking-wider mb-1">
                Supervisor Sign-Off / Verification Designation
              </label>
              <input
                type="text"
                value={supervisorSignOff}
                onChange={(e) => setSupervisorSignOff(e.target.value)}
                className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-xs font-semibold text-neutral-900 focus:outline-hidden focus:ring-2 focus:ring-[#c92228]"
                placeholder="Name or Designation of Supervisor"
              />
            </div>
          </div>

          {/* Local Storage Confirmation Banner */}
          <div className="bg-emerald-50 border border-emerald-300 rounded-xl p-3.5 flex items-start gap-3 text-emerald-950 text-xs">
            <ShieldCheck size={20} className="text-emerald-700 shrink-0 mt-0.5" />
            <div>
              <strong className="font-bold block text-emerald-900">
                Data Persistence Guarantee
              </strong>
              <span>
                Ending this shift will automatically preserve this entire operational session (including all <strong>{bags.length}</strong> bag records, <strong>{despatches.length}</strong> despatches, and duty totals) in your browser's persistent local storage. You can view, search, or restore this shift anytime from the <strong>Saved Shifts</strong> archive.
              </span>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-2 border-t border-neutral-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-neutral-100 hover:bg-neutral-200 text-neutral-700 font-semibold rounded-lg text-xs transition-colors cursor-pointer"
            >
              Cancel / Keep Shift Running
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#c92228] hover:bg-[#a01217] text-white font-bold rounded-lg text-xs shadow-md transition-all cursor-pointer"
            >
              <Save size={16} />
              <span>Shift End & Save to Local Storage</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
