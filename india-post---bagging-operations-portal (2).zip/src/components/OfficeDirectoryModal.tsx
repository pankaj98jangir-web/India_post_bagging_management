import React, { useState, useEffect } from 'react';
import { PostalOfficeSuggestion } from '../data/postalOffices';
import {
  getStoredPostalOffices,
  addPostalOffice,
  updatePostalOffice,
  deletePostalOffice,
  resetPostalOfficesToDefault,
  DIRECTORY_UPDATE_EVENT,
} from '../utils/postalDirectoryStorage';
import {
  X,
  Search,
  Building2,
  MapPin,
  Check,
  ChevronRight,
  PlusCircle,
  Edit2,
  Trash2,
  Save,
  RotateCcw,
  AlertCircle,
  CheckCircle2,
  Layers,
} from 'lucide-react';

interface OfficeDirectoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectOffice?: (officeName: string) => void;
  selectedOffice?: string;
  initialMode?: 'browse' | 'add' | 'manage';
}

export const OfficeDirectoryModal: React.FC<OfficeDirectoryModalProps> = ({
  isOpen,
  onClose,
  onSelectOffice,
  selectedOffice,
  initialMode = 'browse',
}) => {
  const [offices, setOffices] = useState<PostalOfficeSuggestion[]>([]);
  const [activeTab, setActiveTab] = useState<'browse' | 'manage' | 'add'>(initialMode);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  // Form states for Add / Edit
  const [editingOfficeOriginalName, setEditingOfficeOriginalName] = useState<string | null>(null);
  const [formName, setFormName] = useState('');
  const [formPincode, setFormPincode] = useState('');
  const [formCategory, setFormCategory] = useState<PostalOfficeSuggestion['category']>('Indore Division SO');
  const [formDivision, setFormDivision] = useState('Indore City & Moffusil Division');
  const [formParentHO, setFormParentHO] = useState('Indore GPO');
  const [formState, setFormState] = useState('Madhya Pradesh');

  const [statusMsg, setStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Sync with stored postal offices
  const reloadOffices = () => {
    const list = getStoredPostalOffices();
    setOffices(list);
  };

  useEffect(() => {
    if (isOpen) {
      reloadOffices();
      setActiveTab(initialMode);
      setStatusMsg(null);
    }
  }, [isOpen, initialMode]);

  useEffect(() => {
    const handleUpdate = () => {
      reloadOffices();
    };
    window.addEventListener(DIRECTORY_UPDATE_EVENT, handleUpdate);
    return () => window.removeEventListener(DIRECTORY_UPDATE_EVENT, handleUpdate);
  }, []);

  if (!isOpen) return null;

  // Filtered offices for browse / manage
  const filteredOffices = offices.filter((item) => {
    if (selectedCategory !== 'ALL' && item.category !== selectedCategory) {
      return false;
    }
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    return (
      item.name.toLowerCase().includes(q) ||
      (item.pincode && item.pincode.includes(q)) ||
      (item.division && item.division.toLowerCase().includes(q)) ||
      (item.parentHO && item.parentHO.toLowerCase().includes(q)) ||
      item.category.toLowerCase().includes(q)
    );
  });

  const handleStartEdit = (item: PostalOfficeSuggestion) => {
    setEditingOfficeOriginalName(item.name);
    setFormName(item.name);
    setFormPincode(item.pincode || '');
    setFormCategory(item.category);
    setFormDivision(item.division || 'Indore City & Moffusil Division');
    setFormParentHO(item.parentHO || '');
    setFormState(item.state || 'Madhya Pradesh');
    setActiveTab('add');
    setStatusMsg(null);
  };

  const handleResetForm = () => {
    setEditingOfficeOriginalName(null);
    setFormName('');
    setFormPincode('');
    setFormCategory('Indore Division SO');
    setFormDivision('Indore City & Moffusil Division');
    setFormParentHO('Indore GPO');
    setFormState('Madhya Pradesh');
    setStatusMsg(null);
  };

  const handleSaveForm = (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMsg(null);

    const cleanName = formName.trim();
    const cleanPin = formPincode.trim();

    if (!cleanName) {
      setStatusMsg({ type: 'error', text: 'Office Name is required.' });
      return;
    }

    if (cleanPin && !/^\d{6}$/.test(cleanPin)) {
      setStatusMsg({ type: 'error', text: 'PIN code must be exactly 6 digits (e.g. 452001).' });
      return;
    }

    const payload: PostalOfficeSuggestion = {
      name: cleanName,
      pincode: cleanPin || undefined,
      category: formCategory,
      division: formDivision.trim() || undefined,
      parentHO: formParentHO.trim() || undefined,
      state: formState.trim() || 'Madhya Pradesh',
    };

    if (editingOfficeOriginalName) {
      const res = updatePostalOffice(editingOfficeOriginalName, payload);
      if (res.success) {
        setStatusMsg({ type: 'success', text: res.message });
        reloadOffices();
        setTimeout(() => {
          handleResetForm();
          setActiveTab('browse');
        }, 1200);
      } else {
        setStatusMsg({ type: 'error', text: res.message });
      }
    } else {
      const res = addPostalOffice(payload);
      if (res.success) {
        setStatusMsg({ type: 'success', text: res.message });
        reloadOffices();
        setTimeout(() => {
          handleResetForm();
          setActiveTab('browse');
        }, 1200);
      } else {
        setStatusMsg({ type: 'error', text: res.message });
      }
    }
  };

  const handleDelete = (name: string) => {
    if (confirm(`Are you sure you want to delete "${name}" from the office directory?`)) {
      const res = deletePostalOffice(name);
      if (res.success) {
        setStatusMsg({ type: 'success', text: res.message });
        reloadOffices();
      } else {
        setStatusMsg({ type: 'error', text: res.message });
      }
    }
  };

  const handleRestoreDefaults = () => {
    if (confirm('Reset entire directory back to original Department of Posts Indore Region and National list? Custom entries will be replaced.')) {
      resetPostalOfficesToDefault();
      reloadOffices();
      setStatusMsg({ type: 'success', text: 'Directory restored to standard India Post network.' });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs">
      <div
        id="office-directory-modal"
        className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-neutral-200"
      >
        {/* Modal Header */}
        <div className="bg-[#c92228] text-white px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/10 rounded-lg">
              <Building2 size={24} className="text-white" />
            </div>
            <div>
              <h2 className="text-base font-bold tracking-wide">
                Postal Office & PIN Code Directory Manager
              </h2>
              <p className="text-xs text-red-100 font-medium mt-0.5">
                Search, update, and manage Source & Destination offices ({offices.length} registered facilities)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-white/20 rounded-lg text-white/90 hover:text-white transition-colors cursor-pointer"
            title="Close"
          >
            <X size={20} />
          </button>
        </div>

        {/* Action Tabs Header */}
        <div className="bg-neutral-100 px-5 pt-3 border-b border-neutral-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setActiveTab('browse');
                setStatusMsg(null);
              }}
              className={`px-4 py-2 rounded-t-lg font-bold text-xs flex items-center gap-1.5 cursor-pointer border-t border-x transition-colors ${
                activeTab === 'browse'
                  ? 'bg-white text-neutral-900 border-neutral-300 -mb-px shadow-2xs'
                  : 'bg-transparent text-neutral-600 hover:text-neutral-900 border-transparent'
              }`}
            >
              <Search size={14} />
              <span>Browse & Select ({filteredOffices.length})</span>
            </button>
            <button
              onClick={() => {
                setActiveTab('add');
                handleResetForm();
              }}
              className={`px-4 py-2 rounded-t-lg font-bold text-xs flex items-center gap-1.5 cursor-pointer border-t border-x transition-colors ${
                activeTab === 'add'
                  ? 'bg-white text-[#c92228] border-neutral-300 -mb-px shadow-2xs'
                  : 'bg-transparent text-neutral-600 hover:text-neutral-900 border-transparent'
              }`}
            >
              <PlusCircle size={14} />
              <span>{editingOfficeOriginalName ? 'Edit Office Details' : '+ Add New Office / PIN'}</span>
            </button>
            <button
              onClick={() => {
                setActiveTab('manage');
                setStatusMsg(null);
              }}
              className={`px-4 py-2 rounded-t-lg font-bold text-xs flex items-center gap-1.5 cursor-pointer border-t border-x transition-colors ${
                activeTab === 'manage'
                  ? 'bg-white text-neutral-900 border-neutral-300 -mb-px shadow-2xs'
                  : 'bg-transparent text-neutral-600 hover:text-neutral-900 border-transparent'
              }`}
            >
              <Edit2 size={13} />
              <span>Manage & Update Records</span>
            </button>
          </div>

          <button
            onClick={handleRestoreDefaults}
            className="text-[11px] text-neutral-500 hover:text-red-700 font-semibold flex items-center gap-1 mb-2 cursor-pointer transition-colors"
            title="Reset to factory list"
          >
            <RotateCcw size={12} />
            <span className="hidden sm:inline">Reset Defaults</span>
          </button>
        </div>

        {/* Status Alerts */}
        {statusMsg && (
          <div
            className={`px-5 py-2.5 text-xs font-semibold flex items-center gap-2 ${
              statusMsg.type === 'success'
                ? 'bg-emerald-50 text-emerald-800 border-b border-emerald-200'
                : 'bg-red-50 text-red-800 border-b border-red-200'
            }`}
          >
            {statusMsg.type === 'success' ? (
              <CheckCircle2 size={16} className="text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle size={16} className="text-red-600 shrink-0" />
            )}
            <span>{statusMsg.text}</span>
          </div>
        )}

        {/* Tab 1: Browse & Quick Select */}
        {activeTab === 'browse' && (
          <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
            {/* Search & Filter Bar */}
            <div className="p-3.5 bg-neutral-50 border-b border-neutral-200 flex flex-col sm:flex-row gap-3 items-center justify-between">
              <div className="relative w-full sm:w-80">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search Office name, PIN code, HO, Division..."
                  className="w-full pl-9 pr-8 py-2 bg-white border border-neutral-300 rounded-lg text-xs font-semibold text-neutral-800 placeholder-neutral-400 focus:ring-2 focus:ring-[#c92228] focus:outline-hidden"
                  autoFocus
                />
                <Search
                  size={15}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 pointer-events-none"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600 text-xs font-bold"
                  >
                    ×
                  </button>
                )}
              </div>

              {/* Category Filter Pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0 text-xs">
                {['ALL', 'Indore Division SO', 'Indore Region SO', 'Head Office', 'Indore RMS / TMO', 'NSH', 'PH'].map(
                  (cat) => (
                    <button
                      key={cat}
                      onClick={() => setSelectedCategory(cat)}
                      className={`px-2.5 py-1 rounded-md text-[11px] font-bold whitespace-nowrap transition-colors cursor-pointer ${
                        selectedCategory === cat
                          ? 'bg-neutral-900 text-white'
                          : 'bg-white border border-neutral-200 text-neutral-700 hover:bg-neutral-100'
                      }`}
                    >
                      {cat}
                    </button>
                  )
                )}
              </div>
            </div>

            {/* Results Grid */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-5">
              {filteredOffices.length === 0 ? (
                <div className="text-center py-16 text-neutral-500 text-xs space-y-2">
                  <p>No offices found matching "{searchQuery}".</p>
                  <button
                    onClick={() => {
                      setFormName(searchQuery);
                      setActiveTab('add');
                    }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#c92228] text-white rounded-lg font-bold text-xs hover:bg-[#a01217]"
                  >
                    <PlusCircle size={14} /> Add "{searchQuery}" as New Office
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
                  {filteredOffices.map((office) => {
                    const isSelected = selectedOffice === office.name;
                    return (
                      <div
                        key={office.name}
                        onClick={() => {
                          if (onSelectOffice) {
                            onSelectOffice(office.name);
                            onClose();
                          }
                        }}
                        className={`p-3 rounded-xl border text-left transition-all flex items-center justify-between group ${
                          onSelectOffice ? 'cursor-pointer hover:border-[#c92228] hover:bg-red-50/40' : ''
                        } ${
                          isSelected
                            ? 'bg-red-50 border-[#c92228] ring-1 ring-[#c92228]'
                            : 'bg-white border-neutral-200'
                        }`}
                      >
                        <div className="min-w-0 pr-2">
                          <div className="text-xs font-bold text-neutral-900 truncate">
                            {office.name}
                          </div>
                          <div className="flex items-center gap-2 mt-1 text-[11px] text-neutral-500 font-mono">
                            {office.pincode ? (
                              <span className="bg-neutral-100 px-1.5 py-0.2 rounded font-bold text-neutral-800">
                                PIN: {office.pincode}
                              </span>
                            ) : (
                              <span className="text-neutral-400 italic">No PIN</span>
                            )}
                            {office.parentHO && (
                              <span className="truncate text-[10px] text-neutral-400">
                                HO: {office.parentHO.replace('Indore ', '')}
                              </span>
                            )}
                          </div>
                          <div className="mt-1">
                            <span className="text-[9px] px-1.5 py-0.5 rounded bg-neutral-100 font-semibold text-neutral-600">
                              {office.category}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          {isSelected ? (
                            <Check size={16} className="text-[#c92228]" />
                          ) : onSelectOffice ? (
                            <ChevronRight size={14} className="text-neutral-400 group-hover:text-[#c92228]" />
                          ) : null}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 2: Add / Edit Form */}
        {activeTab === 'add' && (
          <div className="flex-1 overflow-y-auto p-6 bg-neutral-50/70">
            <form onSubmit={handleSaveForm} className="max-w-2xl mx-auto bg-white p-6 rounded-xl border border-neutral-200 shadow-xs space-y-5">
              <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-[#c92228]" />
                  <h3 className="font-bold text-neutral-900 text-sm">
                    {editingOfficeOriginalName ? `Edit Office: ${editingOfficeOriginalName}` : 'Add New Postal Office & PIN Code'}
                  </h3>
                </div>
                {editingOfficeOriginalName && (
                  <button
                    type="button"
                    onClick={handleResetForm}
                    className="text-xs text-neutral-500 hover:text-neutral-800 font-semibold cursor-pointer"
                  >
                    Cancel Edit
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Office Name */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                    Office Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    placeholder="e.g. Indore Rajwada SO, Ujjain Mahakal SO, Bhopal NSH..."
                    className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-xs font-bold text-neutral-900 focus:ring-2 focus:ring-[#c92228] focus:bg-white focus:outline-hidden"
                  />
                </div>

                {/* PIN Code */}
                <div>
                  <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                    PIN Code (6 Digits)
                  </label>
                  <input
                    type="text"
                    maxLength={6}
                    value={formPincode}
                    onChange={(e) => setFormPincode(e.target.value.replace(/\D/g, ''))}
                    placeholder="e.g. 452001"
                    className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-xs font-mono font-bold text-neutral-900 focus:ring-2 focus:ring-[#c92228] focus:bg-white focus:outline-hidden"
                  />
                </div>

                {/* Category */}
                <div>
                  <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                    Facility Category *
                  </label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value as any)}
                    className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-xs font-bold text-neutral-900 focus:ring-2 focus:ring-[#c92228] focus:bg-white focus:outline-hidden"
                  >
                    <option value="Indore Division SO">Indore Division SO</option>
                    <option value="Indore Region SO">Indore Region SO</option>
                    <option value="Head Office">Head Office (HO)</option>
                    <option value="Indore RMS / TMO">Indore RMS / TMO</option>
                    <option value="NSH">National Sorting Hub (NSH)</option>
                    <option value="PH">Parcel Hub (PH)</option>
                    <option value="ICH">Intra-Circle Hub (ICH)</option>
                  </select>
                </div>

                {/* Parent Head Office (HO) */}
                <div>
                  <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                    Parent Head Office (HO)
                  </label>
                  <input
                    type="text"
                    value={formParentHO}
                    onChange={(e) => setFormParentHO(e.target.value)}
                    placeholder="e.g. Indore GPO, Ujjain HO..."
                    className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-xs font-semibold text-neutral-900 focus:ring-2 focus:ring-[#c92228] focus:bg-white focus:outline-hidden"
                  />
                </div>

                {/* Division */}
                <div>
                  <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                    Postal Division
                  </label>
                  <input
                    type="text"
                    value={formDivision}
                    onChange={(e) => setFormDivision(e.target.value)}
                    placeholder="e.g. Indore City & Moffusil Division, Indore RMS..."
                    className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-xs font-semibold text-neutral-900 focus:ring-2 focus:ring-[#c92228] focus:bg-white focus:outline-hidden"
                  />
                </div>

                {/* State */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                    State / Postal Circle
                  </label>
                  <input
                    type="text"
                    value={formState}
                    onChange={(e) => setFormState(e.target.value)}
                    placeholder="e.g. Madhya Pradesh"
                    className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-xs font-semibold text-neutral-900 focus:ring-2 focus:ring-[#c92228] focus:bg-white focus:outline-hidden"
                  />
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="pt-3 border-t border-neutral-200 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setActiveTab('browse')}
                  className="px-4 py-2 bg-neutral-100 hover:bg-neutral-200 text-neutral-700 rounded-lg text-xs font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#c92228] hover:bg-[#a01217] text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Save size={15} />
                  <span>{editingOfficeOriginalName ? 'Update Office & Save' : 'Save Office to Directory'}</span>
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Tab 3: Manage Records (Edit & Delete) */}
        {activeTab === 'manage' && (
          <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
            <div className="p-3.5 bg-neutral-50 border-b border-neutral-200 flex items-center justify-between">
              <div className="relative w-72">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Filter offices to edit or delete..."
                  className="w-full pl-8 pr-3 py-1.5 bg-white border border-neutral-300 rounded-lg text-xs font-semibold text-neutral-800 placeholder-neutral-400 focus:ring-2 focus:ring-[#c92228] focus:outline-hidden"
                />
                <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-neutral-400 pointer-events-none" />
              </div>
              <button
                onClick={() => {
                  handleResetForm();
                  setActiveTab('add');
                }}
                className="px-3 py-1.5 bg-[#c92228] hover:bg-[#a01217] text-white rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer"
              >
                <PlusCircle size={14} />
                <span>Add New Office</span>
              </button>
            </div>

            <div className="flex-1 overflow-y-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-neutral-100 text-neutral-700 font-bold border-b border-neutral-200 uppercase tracking-wider sticky top-0">
                  <tr>
                    <th className="py-2.5 px-4 w-12 text-center">Sr</th>
                    <th className="py-2.5 px-4">Office Name</th>
                    <th className="py-2.5 px-4">PIN Code</th>
                    <th className="py-2.5 px-4">Category</th>
                    <th className="py-2.5 px-4">Parent HO</th>
                    <th className="py-2.5 px-4">Division</th>
                    <th className="py-2.5 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-200">
                  {filteredOffices.slice(0, 100).map((item, idx) => (
                    <tr key={item.name} className="hover:bg-neutral-50">
                      <td className="py-2.5 px-4 text-center text-neutral-400 font-mono">{idx + 1}</td>
                      <td className="py-2.5 px-4 font-bold text-neutral-900">{item.name}</td>
                      <td className="py-2.5 px-4 font-mono font-bold text-neutral-700">
                        {item.pincode ? (
                          <span className="bg-neutral-100 px-2 py-0.5 rounded text-neutral-800">
                            {item.pincode}
                          </span>
                        ) : (
                          '-'
                        )}
                      </td>
                      <td className="py-2.5 px-4">
                        <span className="text-[10px] px-2 py-0.5 rounded bg-neutral-100 text-neutral-700 font-semibold">
                          {item.category}
                        </span>
                      </td>
                      <td className="py-2.5 px-4 text-neutral-600">{item.parentHO || '-'}</td>
                      <td className="py-2.5 px-4 text-neutral-500 text-[11px]">{item.division || '-'}</td>
                      <td className="py-2.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleStartEdit(item)}
                            className="p-1 text-blue-600 hover:bg-blue-50 rounded transition-colors cursor-pointer"
                            title="Edit this office"
                          >
                            <Edit2 size={14} />
                          </button>
                          <button
                            onClick={() => handleDelete(item.name)}
                            className="p-1 text-red-600 hover:bg-red-50 rounded transition-colors cursor-pointer"
                            title="Delete this office"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Modal Footer */}
        <div className="bg-neutral-100 border-t border-neutral-200 px-5 py-3 flex items-center justify-between text-xs text-neutral-600 font-medium">
          <span>
            {offices.length} offices saved for bag receiving, closing, and despatch routing
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-neutral-800 hover:bg-neutral-900 text-white rounded-lg font-bold transition-colors cursor-pointer"
          >
            Close Directory
          </button>
        </div>
      </div>
    </div>
  );
};
