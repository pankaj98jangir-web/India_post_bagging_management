import React from 'react';
import { Barcode, Volume2, VolumeX, SlidersHorizontal, Maximize2, Keyboard, Sparkles } from 'lucide-react';
import { SubTabId } from '../App';

interface PcBottomDockProps {
  activeSubTab: SubTabId;
  onSelectTab: (tabId: SubTabId) => void;
  onFocusScanner: () => void;
  isSoundEnabled: boolean;
  onToggleSound: () => void;
  isCompactMode: boolean;
  onToggleCompactMode: () => void;
  onToggleFullscreen: () => void;
  onOpenShortcuts: () => void;
}

export const PcBottomDock: React.FC<PcBottomDockProps> = ({
  activeSubTab,
  onSelectTab,
  onFocusScanner,
  isSoundEnabled,
  onToggleSound,
  isCompactMode,
  onToggleCompactMode,
  onToggleFullscreen,
  onOpenShortcuts,
}) => {
  const quickTabs: { id: SubTabId; key: string; label: string }[] = [
    { id: 'bag-receive', key: '1', label: 'Receive' },
    { id: 'forwarding-bag-receive', key: '2', label: 'Fwd' },
    { id: 'bag-open', key: '3', label: 'Open' },
    { id: 'bag-close', key: '4', label: 'Close' },
    { id: 'print-manifest', key: '5', label: 'Manifest' },
    { id: 'print-label', key: '6', label: 'Label' },
    { id: 'bag-despatch', key: '7', label: 'Despatch' },
    { id: 'deposit-bag-close', key: '8', label: 'Deposit' },
    { id: 'received-bags-abstract', key: '9', label: 'Recv-Abs' },
    { id: 'consolidated-abstract', key: '0', label: 'Consol-Abs' },
    { id: 'create-consolidated-abstract', key: '11', label: 'Create-Abs' },
    { id: 'generate-barcode', key: '12', label: 'Gen-Barcode' },
  ];

  return (
    <div className="sticky bottom-0 z-40 bg-neutral-900 border-t border-neutral-800 text-neutral-300 px-3 py-1.5 shadow-lg select-none print:hidden">
      <div className="max-w-[1720px] mx-auto flex flex-wrap items-center justify-between gap-2 text-[11px]">
        {/* Left: Tab Quick Switch F-keys/Alt-keys */}
        <div className="flex items-center flex-wrap gap-1 overflow-x-auto py-0.5">
          <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider mr-1 hidden sm:inline">
            TABS:
          </span>
          {quickTabs.map((t) => {
            const isActive = activeSubTab === t.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => onSelectTab(t.id)}
                className={`flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-semibold transition-colors cursor-pointer whitespace-nowrap border ${
                  isActive
                    ? 'bg-[#c92228] text-white border-red-700 shadow-2xs'
                    : 'bg-neutral-800/80 hover:bg-neutral-700 text-neutral-300 border-neutral-700'
                }`}
                title={`Switch to ${t.label} (Alt + ${t.key})`}
              >
                <kbd
                  className={`px-1 rounded text-[9px] font-mono font-bold ${
                    isActive ? 'bg-red-900 text-white' : 'bg-neutral-900 text-neutral-400'
                  }`}
                >
                  {t.key}
                </kbd>
                <span>{t.label}</span>
              </button>
            );
          })}
        </div>

        {/* Right: Key Function Shortcuts */}
        <div className="flex items-center gap-1.5">
          {/* F4: Focus Scanner */}
          <button
            type="button"
            onClick={onFocusScanner}
            className="flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-950/80 hover:bg-emerald-900/90 text-emerald-300 border border-emerald-700/80 text-[10px] font-bold transition-colors cursor-pointer"
            title="Focus Active Barcode Scanner (F4 or Alt + L)"
          >
            <Barcode size={12} className="text-emerald-400" />
            <span>SCAN</span>
            <kbd className="px-1 bg-emerald-900 text-emerald-200 rounded text-[9px] font-mono">F4</kbd>
          </button>

          {/* F8: Density */}
          <button
            type="button"
            onClick={onToggleCompactMode}
            className="hidden md:flex items-center gap-1 px-2 py-0.5 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 border border-neutral-700 text-[10px] font-bold transition-colors cursor-pointer"
            title="Toggle Compact PC Mode (F8)"
          >
            <SlidersHorizontal size={11} />
            <span>{isCompactMode ? 'COMPACT' : 'COMFORT'}</span>
            <kbd className="px-1 bg-neutral-900 text-neutral-400 rounded text-[9px] font-mono">F8</kbd>
          </button>

          {/* F9: Sound */}
          <button
            type="button"
            onClick={onToggleSound}
            className="hidden sm:flex items-center gap-1 px-2 py-0.5 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 border border-neutral-700 text-[10px] font-bold transition-colors cursor-pointer"
            title="Toggle Scanner Beep (F9)"
          >
            {isSoundEnabled ? <Volume2 size={11} className="text-emerald-400" /> : <VolumeX size={11} />}
            <span>BEEP</span>
            <kbd className="px-1 bg-neutral-900 text-neutral-400 rounded text-[9px] font-mono">F9</kbd>
          </button>

          {/* F11: Fullscreen */}
          <button
            type="button"
            onClick={onToggleFullscreen}
            className="hidden sm:flex items-center gap-1 px-2 py-0.5 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 border border-neutral-700 text-[10px] font-bold transition-colors cursor-pointer"
            title="Toggle Fullscreen Kiosk (F11)"
          >
            <Maximize2 size={11} />
            <kbd className="px-1 bg-neutral-900 text-neutral-400 rounded text-[9px] font-mono">F11</kbd>
          </button>

          {/* F1: Shortcuts Guide */}
          <button
            type="button"
            onClick={onOpenShortcuts}
            className="flex items-center gap-1 px-2 py-0.5 rounded bg-neutral-800 hover:bg-neutral-700 text-amber-300 border border-neutral-700 text-[10px] font-bold transition-colors cursor-pointer"
            title="Open PC Keyboard Guide (F1 or ?)"
          >
            <Keyboard size={11} />
            <span>HELP</span>
            <kbd className="px-1 bg-neutral-900 text-amber-400 rounded text-[9px] font-mono">F1</kbd>
          </button>
        </div>
      </div>
    </div>
  );
};
