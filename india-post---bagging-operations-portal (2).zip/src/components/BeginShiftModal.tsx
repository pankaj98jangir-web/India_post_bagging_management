import React, { useState } from 'react';
import { OfficeName, SetName, UserSession } from '../types';
import { getTodayDateString } from '../utils/shiftStorage';
import { PlayCircle, Calendar, Building, Layers, UserCheck, AlertTriangle, X, Sparkles, FolderPlus } from 'lucide-react';

interface BeginShiftModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentSession: UserSession;
  activeShiftExists: boolean;
  currentBagsCount: number;
  onConfirmBeginShift: (config: {
    shiftDate: string;
    officeName: OfficeName;
    setName: SetName;
    userId: string;
    startWithFreshEmpty: boolean;
  }) => void;
}

export const BeginShiftModal: React.FC<BeginShiftModalProps> = ({
  isOpen,
  onClose,
  currentSession,
  activeShiftExists,
  currentBagsCount,
  onConfirmBeginShift,
}) => {
  const [shiftDate, setShiftDate] = useState<string>(getTodayDateString());
  const [officeName, setOfficeName] = useState<OfficeName>(currentSession.officeName);
  const [setName, setSetName] = useState<SetName>(currentSession.setName);
  const [userId, setUserId] = useState<string>(currentSession.userId);
  const [startWithFreshEmpty, setStartWithFreshEmpty] = useState<boolean>(true);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onConfirmBeginShift({
      shiftDate,
      officeName,
      setName,
      userId: userId.trim(),
      startWithFreshEmpty,
    });
    onClose();
  };

  const handleSetToday = () => {
    setShiftDate(getTodayDateString());
  };

  const handleSetYesterday = () => {
    const d = new Date();
    d.setDate(d.getDate() - 1);
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    setShiftDate(`${yyyy}-${mm}-${dd}`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-neutral-200 animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="bg-[#1b5e20] text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/15 rounded-xl">
              <PlayCircle size={24} className="text-emerald-300" />
            </div>
            <div>
              <h3 className="font-bold text-base leading-tight">Shift Begin • Start Fresh Shift</h3>
              <p className="text-xs text-emerald-200/90 mt-0.5">
                Department of Posts (MNOP) Shift Commencement
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 hover:bg-white/15 rounded-lg text-white/80 hover:text-white transition-colors cursor-pointer"
          >
            <X size={20} />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* Ongoing Shift Warning */}
          {activeShiftExists && (
            <div className="bg-amber-50 border border-amber-300 rounded-xl p-3.5 flex items-start gap-3 text-amber-900 text-xs">
              <AlertTriangle size={18} className="text-amber-600 shrink-0 mt-0.5" />
              <div>
                <strong className="font-bold block text-amber-950 mb-0.5">
                  An active shift is currently running!
                </strong>
                Starting a new shift will archive the ongoing shift and reset the bagging queue for the new shift date. Current active bags: <strong>{currentBagsCount}</strong>.
              </div>
            </div>
          )}

          {/* Shift Date */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-bold text-neutral-800 uppercase tracking-wider flex items-center gap-1.5">
                <Calendar size={14} className="text-[#1b5e20]" />
                <span>Shift Date *</span>
              </label>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={handleSetToday}
                  className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 px-2 py-0.5 rounded border border-emerald-200 cursor-pointer"
                >
                  Today
                </button>
                <button
                  type="button"
                  onClick={handleSetYesterday}
                  className="text-[11px] font-semibold text-neutral-600 bg-neutral-100 hover:bg-neutral-200 px-2 py-0.5 rounded border border-neutral-300 cursor-pointer"
                >
                  Yesterday
                </button>
              </div>
            </div>
            <input
              type="date"
              required
              value={shiftDate}
              onChange={(e) => setShiftDate(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-lg text-sm font-semibold text-neutral-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-600 focus:border-transparent cursor-pointer"
            />
            <p className="text-[11px] text-neutral-500 mt-1">
              All scanned bags, opened bags, and mail despatches will be logged under this operational date.
            </p>
          </div>

          {/* Office & Set Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Office Name */}
            <div>
              <label className="block text-xs font-bold text-neutral-800 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                <Building size={14} className="text-[#c92228]" />
                <span>Working Office</span>
              </label>
              <select
                value={officeName}
                onChange={(e) => setOfficeName(e.target.value as OfficeName)}
                className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-xs font-bold text-neutral-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-600 cursor-pointer"
              >
                <option value="Indore NSH">Indore NSH (National Sorting Hub)</option>
                <option value="Indore RMS L1U">Indore RMS L1U (Level-1 Unit)</option>
                <option value="Indore TMO">Indore TMO (Transit Mail Office)</option>
                <option value="Indore PH">Indore PH (Parcel Hub)</option>
              </select>
            </div>

            {/* Set Name */}
            <div>
              <label className="block text-xs font-bold text-neutral-800 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                <Layers size={14} className="text-amber-700" />
                <span>Duty Set / Shift</span>
              </label>
              <select
                value={setName}
                onChange={(e) => setSetName(e.target.value as SetName)}
                className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-xs font-bold text-neutral-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-600 cursor-pointer"
              >
                <option value="SET/1">SET/1 (Morning Shift)</option>
                <option value="SET/2">SET/2 (Day Shift)</option>
                <option value="SET/2A">SET/2A (Interim Day Shift)</option>
                <option value="SET/2B">SET/2B (Evening Shift)</option>
                <option value="SET/3A">SET/3A (Night Shift A)</option>
                <option value="SET/3B">SET/3B (Night Shift B)</option>
              </select>
            </div>
          </div>

          {/* Operator ID */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-bold text-neutral-800 uppercase tracking-wider flex items-center gap-1.5">
                <UserCheck size={14} className="text-emerald-700" />
                <span>Operator / User ID (8 Digits)</span>
              </label>
              <span className="text-[10px] font-mono font-bold text-neutral-500">
                {userId.length}/8 Digits
              </span>
            </div>
            <input
              type="text"
              inputMode="numeric"
              pattern="[0-9]{8}"
              maxLength={8}
              value={userId}
              onChange={(e) => setUserId(e.target.value.replace(/\D/g, '').slice(0, 8))}
              required
              placeholder="e.g. 10048219"
              className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-xs font-mono font-bold tracking-widest text-neutral-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-600"
            />
          </div>

          {/* Initial Queue Option */}
          <div className="bg-neutral-50 rounded-xl p-3 border border-neutral-200">
            <span className="block text-xs font-bold text-neutral-800 mb-2">
              Queue Initialization Mode
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <label
                className={`flex items-start gap-2.5 p-2.5 rounded-lg border text-xs cursor-pointer transition-colors ${
                  startWithFreshEmpty
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-semibold'
                    : 'bg-white border-neutral-200 text-neutral-700'
                }`}
              >
                <input
                  type="radio"
                  name="queueMode"
                  checked={startWithFreshEmpty}
                  onChange={() => setStartWithFreshEmpty(true)}
                  className="mt-0.5 text-emerald-600 focus:ring-emerald-500"
                />
                <div>
                  <div className="font-bold flex items-center gap-1">
                    <FolderPlus size={13} className="text-emerald-700" />
                    <span>Fresh Empty Queue</span>
                  </div>
                  <p className="text-[10px] text-neutral-500 mt-0.5">
                    Start with 0 bags, ready for live scanning.
                  </p>
                </div>
              </label>

              <label
                className={`flex items-start gap-2.5 p-2.5 rounded-lg border text-xs cursor-pointer transition-colors ${
                  !startWithFreshEmpty
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-semibold'
                    : 'bg-white border-neutral-200 text-neutral-700'
                }`}
              >
                <input
                  type="radio"
                  name="queueMode"
                  checked={!startWithFreshEmpty}
                  onChange={() => setStartWithFreshEmpty(false)}
                  className="mt-0.5 text-emerald-600 focus:ring-emerald-500"
                />
                <div>
                  <div className="font-bold flex items-center gap-1">
                    <Sparkles size={13} className="text-amber-600" />
                    <span>Load Sample Seed Bags</span>
                  </div>
                  <p className="text-[10px] text-neutral-500 mt-0.5">
                    Pre-populate with sample test bags for practice.
                  </p>
                </div>
              </label>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-2 border-t border-neutral-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-neutral-100 hover:bg-neutral-200 text-neutral-700 font-semibold rounded-lg text-xs transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-2 px-5 py-2 bg-[#1b5e20] hover:bg-[#144717] text-white font-bold rounded-lg text-xs shadow-md transition-all cursor-pointer"
            >
              <PlayCircle size={16} />
              <span>Shift Begin (Start Shift)</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
