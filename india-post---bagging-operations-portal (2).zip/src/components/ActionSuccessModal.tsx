import React, { useEffect, useState } from 'react';
import { ActionSuccessDetails, BagRecord } from '../types';
import { CheckCircle2, X, Printer, FileText, Tag, ArrowRight, Sparkles } from 'lucide-react';

interface ActionSuccessModalProps {
  actionData: ActionSuccessDetails | null;
  onClose: () => void;
  onNavigateToTab?: (tabId: string) => void;
}

export const ActionSuccessModal: React.FC<ActionSuccessModalProps> = ({
  actionData,
  onClose,
  onNavigateToTab,
}) => {
  const [countdown, setCountdown] = useState(6);

  useEffect(() => {
    if (!actionData) return;

    // Play subtle pleasant confirmation audio chime
    try {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioContextClass) {
        const ctx = new AudioContextClass();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
        osc.frequency.setValueAtTime(880, ctx.currentTime + 0.08); // A5
        gain.gain.setValueAtTime(0.12, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.36);
      }
    } catch {
      // Audio autoplay may be disabled in some environments, safely ignore
    }

    setCountdown(6);
    const interval = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          onClose();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' || e.key === 'Enter') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      clearInterval(interval);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [actionData, onClose]);

  if (!actionData) return null;

  const isClosedBag = actionData.actionType === 'close';

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-neutral-200 animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Banner */}
        <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-full bg-white/20 backdrop-blur-xs flex items-center justify-center shrink-0 border border-white/30">
              <CheckCircle2 size={26} className="text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full bg-white/20 text-emerald-100">
                  {actionData.badge || 'CONFIRMED'}
                </span>
                <span className="text-[11px] text-emerald-100 font-mono">
                  {new Date().toLocaleTimeString('en-IN')}
                </span>
              </div>
              <h3 className="text-lg font-black tracking-tight mt-0.5">
                {actionData.title}
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-white/80 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition-colors"
            title="Dismiss (Esc / Enter)"
          >
            <X size={20} />
          </button>
        </div>

        {/* Barcode & Core Details Body */}
        <div className="p-6 space-y-4">
          {actionData.barcode && (
            <div className="p-3.5 bg-neutral-50 rounded-xl border border-neutral-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <span className="text-[10px] uppercase font-bold tracking-wider text-neutral-400 block">
                  Bag Barcode Number
                </span>
                <span className="text-lg font-mono font-black text-neutral-900 tracking-wider">
                  {actionData.barcode}
                </span>
              </div>
              <div className="text-right sm:text-right">
                <span className="text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-md inline-block">
                  ✓ Recorded in System
                </span>
              </div>
            </div>
          )}

          {/* Details Table */}
          <div className="bg-neutral-50/70 border border-neutral-200 rounded-xl divide-y divide-neutral-200 overflow-hidden text-xs">
            {actionData.details.map((item, idx) => (
              <div key={idx} className="flex items-center justify-between px-4 py-2.5">
                <span className="font-semibold text-neutral-500">{item.label}</span>
                <span className="font-bold text-neutral-900 text-right">{item.value}</span>
              </div>
            ))}
          </div>

          {/* Special Quick Actions for Closed Bags */}
          {isClosedBag && onNavigateToTab && (
            <div className="pt-2 flex flex-col sm:flex-row gap-2">
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onNavigateToTab('print-label');
                }}
                className="flex-1 py-2 px-3 bg-neutral-900 hover:bg-black text-white rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <Tag size={14} />
                <span>Go to Print Bag Label</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onNavigateToTab('print-manifest');
                }}
                className="flex-1 py-2 px-3 bg-red-700 hover:bg-red-800 text-white rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <FileText size={14} />
                <span>Go to Print Manifest</span>
              </button>
            </div>
          )}
        </div>

        {/* Footer with auto-close timer and confirm button */}
        <div className="p-4 bg-neutral-50 border-t border-neutral-200 flex items-center justify-between">
          <span className="text-[11px] text-neutral-500 font-medium">
            Auto-closing in <strong className="text-neutral-800">{countdown}s</strong> or press{' '}
            <kbd className="px-1.5 py-0.5 rounded bg-neutral-200 text-neutral-700 text-[10px] font-mono font-bold">
              Enter
            </kbd>
          </span>

          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
          >
            <span>Continue</span>
            <ArrowRight size={14} />
          </button>
        </div>
      </div>
    </div>
  );
};
