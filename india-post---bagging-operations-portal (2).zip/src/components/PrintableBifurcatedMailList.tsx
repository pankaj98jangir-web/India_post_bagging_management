import React, { useState } from 'react';
import { DopLogo } from './DopLogo';
import { DespatchRecord, DespatchSchedule, FinalDestinationBifurcation, DestinationOfficeBifurcation } from '../types';
import { Printer, X, Download, Truck, CheckCircle2, Building2, FileText, Loader2 } from 'lucide-react';
import { generateDocumentPdf, printIsolatedElement, GeneratedPdfResult } from '../utils/pdfGenerator';
import { PdfPreviewModal } from './PdfPreviewModal';

interface PrintableBifurcatedMailListProps {
  despatch: DespatchRecord;
  schedule?: DespatchSchedule;
  onClose?: () => void;
  isModal?: boolean;
}

export const PrintableBifurcatedMailList: React.FC<PrintableBifurcatedMailListProps> = ({
  despatch,
  schedule,
  onClose,
  isModal = false,
}) => {
  const [pdfResult, setPdfResult] = useState<GeneratedPdfResult | null>(null);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [isPdfModalOpen, setIsPdfModalOpen] = useState(false);

  const destinationOffice = despatch.destinationOffice;
  const fileName = `MailList_M11_${destinationOffice.replace(/\s+/g, '_')}_${despatch.despatchNumber}.pdf`;

  const handlePrint = () => {
    printIsolatedElement('bifurcated-mail-list-document', `Mail Delivery Bill Form M-11 - ${destinationOffice}`);
  };

  const handleOpenPdf = async () => {
    setIsGeneratingPdf(true);
    try {
      const res = await generateDocumentPdf(
        'bifurcated-mail-list-document',
        'maillist',
        fileName
      );
      setPdfResult(res);
      setIsPdfModalOpen(true);
    } catch (err) {
      console.error('Failed to generate Mail List PDF:', err);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  const handleDownloadPdf = async () => {
    setIsGeneratingPdf(true);
    try {
      const res = await generateDocumentPdf(
        'bifurcated-mail-list-document',
        'maillist',
        fileName
      );
      res.download();
    } catch (err) {
      console.error('Failed to download Mail List PDF:', err);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  // Build the bifurcation groups if not already present on despatch
  // Group bags by final destination office
  const finalDestMap = new Map<string, typeof despatch.bags>();
  for (const bag of despatch.bags) {
    const finalDest = bag.finalDestinationOffice?.trim() || destinationOffice;
    if (!finalDestMap.has(finalDest)) {
      finalDestMap.set(finalDest, []);
    }
    finalDestMap.get(finalDest)!.push(bag);
  }

  const bifurcations: FinalDestinationBifurcation[] = Array.from(finalDestMap.entries()).map(
    ([finalDest, bagsList]) => {
      const totalWeight = bagsList.reduce((acc, b) => acc + (b.bagWeightKg || 2.5), 0);
      const totalArticles = bagsList.reduce((acc, b) => acc + (b.totalArticlesCount || 0), 0);
      const speedCount = bagsList.reduce((acc, b) => acc + (b.speedPostCount || 0), 0);
      const insuredCount = bagsList.reduce((acc, b) => acc + (b.insuredCount || 0), 0);
      return {
        finalDestinationOffice: finalDest,
        bags: bagsList,
        totalBags: bagsList.length,
        totalWeightKg: totalWeight,
        totalArticles,
        speedPostCount: speedCount,
        insuredCount,
      };
    }
  );

  const totalBags = despatch.bags.length;
  const totalWeight = despatch.totalWeightKg || despatch.bags.reduce((a, b) => a + (b.bagWeightKg || 2.5), 0);
  const totalArticles = despatch.bags.reduce((a, b) => a + (b.totalArticlesCount || 0), 0);
  const totalInsured = despatch.bags.reduce((a, b) => a + (b.insuredCount || 0), 0);

  const mailListContent = (
    <div
      id="bifurcated-mail-list-document"
      className="bg-white text-neutral-900 border border-neutral-300 rounded-lg p-7 mx-auto shadow-sm print:border-none print:shadow-none print:p-2 print:m-0 w-full"
      style={{
        maxWidth: '210mm',
        minHeight: '297mm',
        boxSizing: 'border-box',
      }}
    >
      {/* Official Department of Posts Header */}
      <div className="border-b-2 border-neutral-900 pb-4 mb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <DopLogo size={48} />
            <div>
              <h1 className="text-base font-black uppercase tracking-wider text-neutral-900">
                Department of Posts, India
              </h1>
              <p className="text-xs font-bold text-neutral-800 uppercase">
                Railway Mail Service (RMS) — Indore RMS Division
              </p>
              <p className="text-[11px] font-semibold text-neutral-600">
                Office of Despatch: {despatch.officeName} | {despatch.setName}
              </p>
            </div>
          </div>

          <div className="text-right font-mono text-xs">
            <div className="px-2.5 py-1 bg-neutral-900 text-white font-bold rounded text-center mb-1">
              FORM M-11
            </div>
            <p className="font-bold text-neutral-800">
              Despatch ID: <span className="text-[#c92228]">{despatch.scheduleId}</span>
            </p>
            <p className="text-neutral-500 text-[11px]">{despatch.despatchedAt}</p>
          </div>
        </div>

        <div className="mt-3 text-center py-1.5 bg-neutral-100 border-y border-neutral-300">
          <h2 className="text-xs font-black uppercase tracking-wider text-neutral-900">
            Bifurcated Mail Delivery Bill / Mail List (According to Destination Office)
          </h2>
        </div>
      </div>

      {/* Transit & Schedule Information Box */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-neutral-50 border border-neutral-300 p-3 rounded text-xs mb-4">
        <div>
          <span className="text-[10px] font-bold uppercase text-neutral-500 block">Schedule Code & Name</span>
          <span className="font-bold font-mono text-neutral-900">
            {despatch.scheduleCode || schedule?.scheduleCode || 'SCH-ROUTE'}
          </span>
          <p className="text-[11px] text-neutral-700 truncate">{despatch.scheduleName || schedule?.scheduleName || 'Standard Despatch'}</p>
        </div>

        <div>
          <span className="text-[10px] font-bold uppercase text-neutral-500 block">Primary Destination Office</span>
          <span className="font-bold text-[#c92228] text-xs uppercase flex items-center gap-1">
            <Building2 size={13} />
            {destinationOffice}
          </span>
          <span className="text-[10px] text-neutral-500 block">(Transit Hub / Section)</span>
        </div>

        <div>
          <span className="text-[10px] font-bold uppercase text-neutral-500 block">Transit Mode / Carrier</span>
          <span className="font-bold text-neutral-900">
            {despatch.transitMode || schedule?.transitMode || 'Road / MMS'}
          </span>
          <p className="text-[11px] font-mono text-neutral-600 truncate">
            {despatch.carrierOrVehicle || schedule?.carrierOrVehicle || 'Dept Van'}
          </p>
        </div>

        <div>
          <span className="text-[10px] font-bold uppercase text-neutral-500 block">Departure Time & Date</span>
          <span className="font-bold text-neutral-900">
            {despatch.departureTime || schedule?.departureTime || 'Immediate'}
          </span>
          <p className="text-[10px] text-neutral-500 truncate">{despatch.despatchedAt}</p>
        </div>
      </div>

      {/* Destination Office Header Banner */}
      <div className="bg-[#c92228] text-white p-2.5 rounded-t font-bold text-xs flex items-center justify-between uppercase tracking-wider">
        <div className="flex items-center gap-2">
          <span>Destination Office: {destinationOffice}</span>
          <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded">
            {bifurcations.length} Final Destinations Bifurcated
          </span>
        </div>
        <div className="text-[11px] font-mono">
          Total Bags: {totalBags} | Net Weight: {totalWeight.toFixed(3)} KG
        </div>
      </div>

      {/* Bifurcated Tables (Final Destination Office under Destination Office) */}
      <div className="border border-neutral-300 border-t-0 divide-y-2 divide-neutral-300 mb-5">
        {bifurcations.map((group, groupIdx) => (
          <div key={group.finalDestinationOffice} className="p-3 bg-white">
            {/* Final Destination Sub-Header */}
            <div className="flex items-center justify-between pb-2 mb-2 border-b border-neutral-200">
              <div className="flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-neutral-800 text-white font-bold text-[10px] flex items-center justify-center">
                  {groupIdx + 1}
                </span>
                <div>
                  <h3 className="font-extrabold text-xs text-neutral-900 uppercase">
                    Final Destination Office: <span className="text-[#c92228]">{group.finalDestinationOffice}</span>
                  </h3>
                  <p className="text-[10px] text-neutral-500">
                    Bifurcated under Destination Transit Hub: {destinationOffice}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 text-[11px] font-mono">
                <span className="px-2 py-0.5 bg-neutral-100 rounded border border-neutral-300 font-bold text-neutral-800">
                  {group.totalBags} {group.totalBags === 1 ? 'Bag' : 'Bags'}
                </span>
                <span className="font-bold text-neutral-900">
                  {group.totalWeightKg.toFixed(3)} KG
                </span>
                <span className="text-neutral-600 font-bold">
                  {group.totalArticles} Arts ({group.insuredCount} Ins)
                </span>
              </div>
            </div>

            {/* Bags Table under this Final Destination */}
            <table className="w-full text-[11px] border border-neutral-300 mb-1">
              <thead className="bg-neutral-100 text-neutral-700 font-bold border-b border-neutral-300">
                <tr>
                  <th className="p-1.5 text-center w-8">#</th>
                  <th className="p-1.5 text-left">Bag Barcode (13 Chars)</th>
                  <th className="p-1.5 text-left">Origin Office</th>
                  <th className="p-1.5 text-center">Bag Status</th>
                  <th className="p-1.5 text-center">Speed/Regd</th>
                  <th className="p-1.5 text-center">Insured</th>
                  <th className="p-1.5 text-center">Total Arts</th>
                  <th className="p-1.5 text-right">Weight (KG)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-200 font-mono">
                {group.bags.map((bag, i) => (
                  <tr key={bag.id} className="hover:bg-neutral-50">
                    <td className="p-1.5 text-center font-bold text-neutral-400">{i + 1}</td>
                    <td className="p-1.5 font-bold text-neutral-900 tracking-wider">
                      {bag.bagBarcode}
                    </td>
                    <td className="p-1.5 font-sans text-neutral-700 font-medium">
                      {bag.sourceOffice}
                    </td>
                    <td className="p-1.5 text-center font-sans">
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-bold uppercase bg-neutral-100 text-neutral-700">
                        {bag.bagStatus}
                      </span>
                    </td>
                    <td className="p-1.5 text-center font-bold text-neutral-700">
                      {bag.speedPostCount || 0}
                    </td>
                    <td className="p-1.5 text-center font-bold text-amber-800">
                      {bag.insuredCount || 0}
                    </td>
                    <td className="p-1.5 text-center font-bold text-neutral-900">
                      {bag.totalArticlesCount || 0}
                    </td>
                    <td className="p-1.5 text-right font-bold text-neutral-800">
                      {(bag.bagWeightKg || 2.5).toFixed(3)}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-neutral-50 font-bold border-t border-neutral-300 text-[11px]">
                <tr>
                  <td colSpan={4} className="p-1.5 text-right font-sans text-neutral-700">
                    Subtotal for {group.finalDestinationOffice}:
                  </td>
                  <td className="p-1.5 text-center">{group.speedPostCount}</td>
                  <td className="p-1.5 text-center text-amber-800">{group.insuredCount}</td>
                  <td className="p-1.5 text-center text-neutral-900">{group.totalArticles}</td>
                  <td className="p-1.5 text-right text-neutral-900 font-mono">
                    {group.totalWeightKg.toFixed(3)} KG
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        ))}
      </div>

      {/* Grand Summary Block */}
      <div className="bg-neutral-100 border-2 border-neutral-900 p-3 rounded mb-6 text-xs">
        <div className="font-black text-neutral-900 uppercase mb-2 border-b border-neutral-300 pb-1 flex items-center justify-between">
          <span>Grand Despatch Summary for Destination: {destinationOffice}</span>
          <span className="font-mono text-[11px] font-normal text-neutral-600">
            India Post MNOP Bagging Standards
          </span>
        </div>
        <div className="grid grid-cols-4 gap-3 text-center font-mono">
          <div className="bg-white p-2 rounded border border-neutral-300">
            <span className="text-[10px] font-sans font-bold text-neutral-500 uppercase block">
              Final Destinations
            </span>
            <span className="text-sm font-black text-neutral-900">{bifurcations.length} Stations</span>
          </div>
          <div className="bg-white p-2 rounded border border-neutral-300">
            <span className="text-[10px] font-sans font-bold text-neutral-500 uppercase block">
              Total Bags
            </span>
            <span className="text-sm font-black text-[#c92228]">{totalBags} Bags</span>
          </div>
          <div className="bg-white p-2 rounded border border-neutral-300">
            <span className="text-[10px] font-sans font-bold text-neutral-500 uppercase block">
              Total Articles
            </span>
            <span className="text-sm font-black text-neutral-900">
              {totalArticles} ({totalInsured} Insured)
            </span>
          </div>
          <div className="bg-white p-2 rounded border border-neutral-300">
            <span className="text-[10px] font-sans font-bold text-neutral-500 uppercase block">
              Total Weight (KG)
            </span>
            <span className="text-sm font-black text-neutral-900">{totalWeight.toFixed(3)} KG</span>
          </div>
        </div>
      </div>

      {/* Official Signatures & Date Stamp Seals Block */}
      <div className="grid grid-cols-3 gap-4 pt-4 border-t-2 border-neutral-900 text-center text-xs">
        <div className="border border-dashed border-neutral-400 p-3 rounded min-h-[90px] flex flex-col justify-between">
          <div>
            <p className="font-bold text-neutral-900 uppercase text-[11px]">Despatched By</p>
            <p className="text-[10px] text-neutral-500">Sorting Assistant (Indore RMS)</p>
          </div>
          <div className="pt-6 border-t border-dotted border-neutral-300">
            <p className="text-[9px] text-neutral-400">Signature & RMS Date Stamp</p>
          </div>
        </div>

        <div className="border border-dashed border-neutral-400 p-3 rounded min-h-[90px] flex flex-col justify-between">
          <div>
            <p className="font-bold text-neutral-900 uppercase text-[11px]">Escort / Carrier Handover</p>
            <p className="text-[10px] text-neutral-500">
              {despatch.carrierOrVehicle || 'MMS Van Driver / Mail Guard'}
            </p>
          </div>
          <div className="pt-6 border-t border-dotted border-neutral-300">
            <p className="text-[9px] text-neutral-400">Signature & Badge Number</p>
          </div>
        </div>

        <div className="border border-dashed border-neutral-400 p-3 rounded min-h-[90px] flex flex-col justify-between">
          <div>
            <p className="font-bold text-neutral-900 uppercase text-[11px]">Received At Destination</p>
            <p className="text-[10px] text-neutral-500">
              {destinationOffice} (Receiving Section)
            </p>
          </div>
          <div className="pt-6 border-t border-dotted border-neutral-300">
            <p className="text-[9px] text-neutral-400">Signature & Office Round Stamp</p>
          </div>
        </div>
      </div>

      <div className="mt-5 text-center text-[10px] text-neutral-400 border-t border-neutral-200 pt-2">
        Postal Transit Document — Generated by Indore RMS Bagging & Despatch Workstation Terminal
      </div>
    </div>
  );

  if (isModal) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/70 backdrop-blur-xs overflow-y-auto print:p-0 print:bg-white">
        <div className="bg-neutral-100 rounded-2xl shadow-2xl max-w-4xl w-full max-h-[95vh] flex flex-col overflow-hidden border border-neutral-300 print:border-none print:shadow-none print:max-h-none print:w-full">
          {/* Action Toolbar */}
          <div className="bg-neutral-900 text-white px-5 py-3 flex items-center justify-between print:hidden flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <Truck size={18} className="text-[#c92228]" />
              <span className="font-bold text-xs uppercase tracking-wider">
                Bifurcated Mail List (M-11) — {destinationOffice}
              </span>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <button
                type="button"
                disabled={isGeneratingPdf}
                onClick={handleOpenPdf}
                className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs border border-neutral-700 disabled:opacity-50"
                title="Open Standalone Form M-11 PDF without web layout"
              >
                {isGeneratingPdf ? <Loader2 size={14} className="animate-spin" /> : <FileText size={14} className="text-amber-400" />}
                <span>Open in PDF</span>
              </button>

              <button
                type="button"
                disabled={isGeneratingPdf}
                onClick={handleDownloadPdf}
                className="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-neutral-950 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-50"
                title="Download Standalone Form M-11 PDF file"
              >
                <Download size={14} />
                <span>Download PDF</span>
              </button>

              <button
                type="button"
                onClick={handlePrint}
                className="px-3.5 py-1.5 bg-[#c92228] hover:bg-[#a01217] text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                title="Print Mail Delivery Bill (Form M-11)"
              >
                <Printer size={14} />
                <span>Print Mail List</span>
              </button>

              {onClose && (
                <button
                  type="button"
                  onClick={onClose}
                  className="p-1.5 hover:bg-neutral-800 rounded-lg text-neutral-400 hover:text-white transition-colors cursor-pointer ml-1"
                  title="Close"
                >
                  <X size={18} />
                </button>
              )}
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-4 sm:p-6 print:p-0 print:overflow-visible">
            {mailListContent}
          </div>
        </div>

        <PdfPreviewModal
          isOpen={isPdfModalOpen}
          onClose={() => setIsPdfModalOpen(false)}
          pdfResult={pdfResult}
          docType="maillist"
          title={`Mail Delivery Bill Form M-11: ${destinationOffice}`}
        />
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-end gap-2 mb-3 print:hidden">
        <button
          type="button"
          disabled={isGeneratingPdf}
          onClick={handleOpenPdf}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-900 hover:bg-black text-white text-xs font-bold transition-colors cursor-pointer shadow-xs disabled:opacity-50"
          title="Open Mail List in standalone PDF viewer"
        >
          {isGeneratingPdf ? <Loader2 size={14} className="animate-spin" /> : <FileText size={14} className="text-amber-400" />}
          <span>Open in PDF</span>
        </button>

        <button
          type="button"
          disabled={isGeneratingPdf}
          onClick={handleDownloadPdf}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-neutral-950 text-xs font-bold transition-colors cursor-pointer shadow-xs disabled:opacity-50"
          title="Download Mail List PDF"
        >
          <Download size={14} />
          <span>Download PDF</span>
        </button>

        <button
          type="button"
          onClick={handlePrint}
          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-[#c92228] text-white hover:bg-[#a01217] text-xs font-bold uppercase tracking-wider shadow-xs cursor-pointer"
        >
          <Printer size={14} />
          <span>Print Mail List</span>
        </button>
      </div>

      {mailListContent}

      <PdfPreviewModal
        isOpen={isPdfModalOpen}
        onClose={() => setIsPdfModalOpen(false)}
        pdfResult={pdfResult}
        docType="maillist"
        title={`Mail Delivery Bill Form M-11: ${destinationOffice}`}
      />
    </div>
  );
};
