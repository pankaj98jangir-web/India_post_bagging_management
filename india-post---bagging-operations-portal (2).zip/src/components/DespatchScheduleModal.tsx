import React, { useState, useEffect } from 'react';
import { DespatchSchedule } from '../types';
import {
  getStoredSchedules,
  addDespatchSchedule,
  updateDespatchSchedule,
  deleteDespatchSchedule,
  resetSchedulesToDefault,
  SCHEDULES_UPDATE_EVENT,
} from '../utils/despatchScheduleStorage';
import { OfficeAutocomplete } from './OfficeAutocomplete';
import {
  Calendar,
  Clock,
  Truck,
  Plus,
  Edit2,
  Trash2,
  Save,
  X,
  RotateCcw,
  Check,
  AlertCircle,
  CheckCircle2,
  Building2,
  MapPin,
  Tag,
} from 'lucide-react';

interface DespatchScheduleModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectSchedule?: (schedule: DespatchSchedule) => void;
  selectedScheduleId?: string;
  initialMode?: 'list' | 'add';
  editScheduleItem?: DespatchSchedule | null;
}

export const DespatchScheduleModal: React.FC<DespatchScheduleModalProps> = ({
  isOpen,
  onClose,
  onSelectSchedule,
  selectedScheduleId,
  initialMode = 'list',
  editScheduleItem = null,
}) => {
  const [schedules, setSchedules] = useState<DespatchSchedule[]>([]);
  const [viewMode, setViewMode] = useState<'list' | 'form'>(initialMode === 'add' ? 'form' : 'list');
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form Fields
  const [formCode, setFormCode] = useState('');
  const [formName, setFormName] = useState('');
  const [formDestOffice, setFormDestOffice] = useState('');
  const [formFinalDestList, setFormFinalDestList] = useState<string[]>([]);
  const [newFinalDestInput, setNewFinalDestInput] = useState('');
  const [formTransitMode, setFormTransitMode] = useState<DespatchSchedule['transitMode']>('Road / MMS');
  const [formDepartureTime, setFormDepartureTime] = useState('10:00');
  const [formCarrier, setFormCarrier] = useState('');
  const [formRemarks, setFormRemarks] = useState('');

  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const reloadSchedules = () => {
    const list = getStoredSchedules();
    setSchedules(list);
  };

  useEffect(() => {
    if (isOpen) {
      reloadSchedules();
      setFeedback(null);
      if (editScheduleItem) {
        populateFormForEdit(editScheduleItem);
      } else if (initialMode === 'add') {
        initNewForm();
      } else {
        setViewMode('list');
      }
    }
  }, [isOpen, initialMode, editScheduleItem]);

  useEffect(() => {
    const handler = () => reloadSchedules();
    window.addEventListener(SCHEDULES_UPDATE_EVENT, handler);
    return () => window.removeEventListener(SCHEDULES_UPDATE_EVENT, handler);
  }, []);

  if (!isOpen) return null;

  const initNewForm = () => {
    setEditingId(null);
    const nextNum = schedules.length + 1;
    setFormCode(`SCH-${String(nextNum).padStart(2, '0')}`);
    setFormName('');
    setFormDestOffice('');
    setFormFinalDestList([]);
    setNewFinalDestInput('');
    setFormTransitMode('Road / MMS');
    setFormDepartureTime('10:30');
    setFormCarrier('MMS Van MP-09-');
    setFormRemarks('');
    setViewMode('form');
    setFeedback(null);
  };

  const populateFormForEdit = (sch: DespatchSchedule) => {
    setEditingId(sch.id);
    setFormCode(sch.scheduleCode);
    setFormName(sch.scheduleName);
    setFormDestOffice(sch.destinationOffice);
    setFormFinalDestList(sch.finalDestinationOffices || []);
    setNewFinalDestInput('');
    setFormTransitMode(sch.transitMode);
    setFormDepartureTime(sch.departureTime || '10:00');
    setFormCarrier(sch.carrierOrVehicle || '');
    setFormRemarks(sch.remarks || '');
    setViewMode('form');
    setFeedback(null);
  };

  const handleAddFinalDestination = () => {
    const trimmed = newFinalDestInput.trim();
    if (!trimmed) return;
    if (formFinalDestList.some((d) => d.toLowerCase() === trimmed.toLowerCase())) {
      setFeedback({ type: 'error', text: `"${trimmed}" is already in the final destinations list.` });
      return;
    }
    setFormFinalDestList([...formFinalDestList, trimmed]);
    setNewFinalDestInput('');
    setFeedback(null);
  };

  const handleRemoveFinalDestination = (destToRemove: string) => {
    setFormFinalDestList(formFinalDestList.filter((d) => d !== destToRemove));
  };

  const handleSaveForm = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);

    const cleanCode = formCode.trim().toUpperCase();
    const cleanName = formName.trim();
    const cleanDest = formDestOffice.trim();

    if (!cleanCode) {
      setFeedback({ type: 'error', text: 'Schedule Code is required (e.g. SCH-01).' });
      return;
    }
    if (!cleanName) {
      setFeedback({ type: 'error', text: 'Schedule Name/Route is required.' });
      return;
    }
    if (!cleanDest) {
      setFeedback({ type: 'error', text: 'Destination Office (Transit Hub) is required.' });
      return;
    }
    if (formFinalDestList.length === 0) {
      setFeedback({
        type: 'error',
        text: 'Please add at least one Final Destination Office under this Destination Office.',
      });
      return;
    }

    if (editingId) {
      const res = updateDespatchSchedule(editingId, {
        scheduleCode: cleanCode,
        scheduleName: cleanName,
        destinationOffice: cleanDest,
        finalDestinationOffices: formFinalDestList,
        transitMode: formTransitMode,
        departureTime: formDepartureTime,
        carrierOrVehicle: formCarrier.trim() || undefined,
        remarks: formRemarks.trim() || undefined,
      });

      if (res.success) {
        setFeedback({ type: 'success', text: res.message });
        reloadSchedules();
        setTimeout(() => {
          setViewMode('list');
          setFeedback(null);
        }, 1000);
      } else {
        setFeedback({ type: 'error', text: res.message });
      }
    } else {
      const newSchedule: DespatchSchedule = {
        id: `sch-${Date.now().toString(36)}`,
        scheduleCode: cleanCode,
        scheduleName: cleanName,
        destinationOffice: cleanDest,
        finalDestinationOffices: formFinalDestList,
        transitMode: formTransitMode,
        departureTime: formDepartureTime,
        carrierOrVehicle: formCarrier.trim() || undefined,
        remarks: formRemarks.trim() || undefined,
        createdAt: new Date().toLocaleString('en-IN'),
      };

      const res = addDespatchSchedule(newSchedule);
      if (res.success) {
        setFeedback({ type: 'success', text: res.message });
        reloadSchedules();
        if (onSelectSchedule) {
          onSelectSchedule(newSchedule);
        }
        setTimeout(() => {
          setViewMode('list');
          setFeedback(null);
        }, 1000);
      } else {
        setFeedback({ type: 'error', text: res.message });
      }
    }
  };

  const handleDelete = (sch: DespatchSchedule) => {
    if (confirm(`Delete schedule "${sch.scheduleCode}: ${sch.scheduleName}"?`)) {
      const res = deleteDespatchSchedule(sch.id);
      if (res.success) {
        setFeedback({ type: 'success', text: res.message });
        reloadSchedules();
      } else {
        setFeedback({ type: 'error', text: res.message });
      }
    }
  };

  const handleResetDefaults = () => {
    if (confirm('Restore standard Indore RMS transit schedules (Bhopal, Mumbai, Delhi, Ujjain, Khandwa, Ratlam)? Any custom changes will be reset.')) {
      resetSchedulesToDefault();
      reloadSchedules();
      setFeedback({ type: 'success', text: 'Schedules restored to default routes.' });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs">
      <div
        id="despatch-schedule-modal"
        className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-neutral-200"
      >
        {/* Header */}
        <div className="bg-[#c92228] text-white px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/10 rounded-lg">
              <Calendar size={22} className="text-white" />
            </div>
            <div>
              <h2 className="text-base font-bold tracking-wide">
                Despatch Schedule Manager & Mail Routes
              </h2>
              <p className="text-xs text-red-100 font-medium mt-0.5">
                Configure schedules, transit Destination Offices, and bifurcated Final Destination Offices
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-white/20 rounded-lg text-white/90 hover:text-white transition-colors cursor-pointer"
            title="Close"
          >
            <X size={20} />
          </button>
        </div>

        {/* Action Tabs Header */}
        <div className="bg-neutral-100 px-5 pt-3 border-b border-neutral-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setViewMode('list');
                setFeedback(null);
              }}
              className={`px-4 py-2 rounded-t-lg font-bold text-xs flex items-center gap-1.5 cursor-pointer border-t border-x transition-colors ${
                viewMode === 'list'
                  ? 'bg-white text-neutral-900 border-neutral-300 -mb-px shadow-2xs'
                  : 'bg-transparent text-neutral-600 hover:text-neutral-900 border-transparent'
              }`}
            >
              <Truck size={14} />
              <span>Available Schedules ({schedules.length})</span>
            </button>
            <button
              onClick={() => initNewForm()}
              className={`px-4 py-2 rounded-t-lg font-bold text-xs flex items-center gap-1.5 cursor-pointer border-t border-x transition-colors ${
                viewMode === 'form' && !editingId
                  ? 'bg-white text-[#c92228] border-neutral-300 -mb-px shadow-2xs'
                  : 'bg-transparent text-neutral-600 hover:text-neutral-900 border-transparent'
              }`}
            >
              <Plus size={14} />
              <span>+ Create New Schedule</span>
            </button>
            {editingId && viewMode === 'form' && (
              <span className="px-3 py-1.5 bg-amber-100 text-amber-900 font-bold text-xs rounded-t border-t border-x border-amber-300 -mb-px">
                Editing: {formCode}
              </span>
            )}
          </div>

          <button
            onClick={handleResetDefaults}
            className="text-[11px] text-neutral-500 hover:text-red-700 font-semibold flex items-center gap-1 mb-2 cursor-pointer transition-colors"
            title="Restore factory default schedules"
          >
            <RotateCcw size={12} />
            <span className="hidden sm:inline">Reset Defaults</span>
          </button>
        </div>

        {/* Feedback Alert */}
        {feedback && (
          <div
            className={`px-5 py-2.5 text-xs font-semibold flex items-center gap-2 ${
              feedback.type === 'success'
                ? 'bg-emerald-50 text-emerald-800 border-b border-emerald-200'
                : 'bg-red-50 text-red-800 border-b border-red-200'
            }`}
          >
            {feedback.type === 'success' ? (
              <CheckCircle2 size={16} className="text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle size={16} className="text-red-600 shrink-0" />
            )}
            <span>{feedback.text}</span>
          </div>
        )}

        {/* View 1: Schedules List */}
        {viewMode === 'list' && (
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-neutral-50/60">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {schedules.map((sch) => {
                const isCurrent = selectedScheduleId === sch.id;
                return (
                  <div
                    key={sch.id}
                    className={`bg-white rounded-xl border p-4 shadow-2xs transition-all relative group flex flex-col justify-between ${
                      isCurrent
                        ? 'border-[#c92228] ring-2 ring-red-100 bg-red-50/15'
                        : 'border-neutral-200 hover:border-neutral-300'
                    }`}
                  >
                    <div>
                      {/* Top Code & Action Badges */}
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <span className="px-2.5 py-1 bg-neutral-900 text-white rounded font-mono font-bold text-xs">
                            {sch.scheduleCode}
                          </span>
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-neutral-100 text-neutral-700">
                            {sch.transitMode}
                          </span>
                          {sch.departureTime && (
                            <span className="flex items-center gap-1 text-[11px] font-mono font-bold text-neutral-600">
                              <Clock size={12} className="text-[#c92228]" />
                              {sch.departureTime}
                            </span>
                          )}
                        </div>

                        {/* Edit & Delete Action Buttons */}
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => populateFormForEdit(sch)}
                            className="p-1.5 text-neutral-500 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors cursor-pointer"
                            title="Edit this schedule"
                          >
                            <Edit2 size={14} />
                          </button>
                          <button
                            onClick={() => handleDelete(sch)}
                            className="p-1.5 text-neutral-500 hover:text-red-600 hover:bg-red-50 rounded transition-colors cursor-pointer"
                            title="Delete this schedule"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </div>

                      {/* Route Name */}
                      <h3 className="font-bold text-neutral-900 text-sm mb-2">
                        {sch.scheduleName}
                      </h3>

                      {/* Destination Office Header */}
                      <div className="bg-red-50/70 border border-red-200 rounded-lg p-2.5 mb-2.5">
                        <div className="text-[10px] font-bold uppercase text-neutral-500 mb-0.5">
                          Destination Office (Transit Hub)
                        </div>
                        <div className="font-bold text-xs text-[#c92228] flex items-center gap-1.5">
                          <Building2 size={14} />
                          <span>{sch.destinationOffice}</span>
                        </div>
                      </div>

                      {/* Final Destination Offices Bifurcation Preview */}
                      <div>
                        <div className="text-[10px] font-bold uppercase text-neutral-500 mb-1.5 flex items-center justify-between">
                          <span>Final Destinations Under this Destination ({sch.finalDestinationOffices?.length || 0}):</span>
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {sch.finalDestinationOffices?.slice(0, 6).map((dest) => (
                            <span
                              key={dest}
                              className="px-2 py-0.5 bg-neutral-100 border border-neutral-200 rounded text-[10px] font-medium text-neutral-700"
                            >
                              {dest}
                            </span>
                          ))}
                          {(sch.finalDestinationOffices?.length || 0) > 6 && (
                            <span className="px-1.5 py-0.5 bg-neutral-200 text-neutral-600 rounded text-[9px] font-bold">
                              +{sch.finalDestinationOffices.length - 6} more
                            </span>
                          )}
                        </div>
                      </div>

                      {sch.carrierOrVehicle && (
                        <p className="text-[11px] text-neutral-500 mt-2 font-mono">
                          Vehicle / Train: {sch.carrierOrVehicle}
                        </p>
                      )}
                    </div>

                    {/* Footer / Select Button */}
                    <div className="mt-4 pt-3 border-t border-neutral-100 flex items-center justify-between">
                      <span className="text-[10px] text-neutral-400">
                        {sch.isSystemDefault ? 'India Post Indore RMS Route' : 'Custom Route'}
                      </span>
                      {onSelectSchedule && (
                        <button
                          onClick={() => {
                            onSelectSchedule(sch);
                            onClose();
                          }}
                          className={`px-3.5 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-all flex items-center gap-1.5 ${
                            isCurrent
                              ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                              : 'bg-[#c92228] text-white hover:bg-[#a01217]'
                          }`}
                        >
                          <Check size={14} />
                          <span>{isCurrent ? 'Active Route' : 'Use This Schedule'}</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* View 2: Add / Edit Form */}
        {viewMode === 'form' && (
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-neutral-50/60">
            <form onSubmit={handleSaveForm} className="max-w-2xl mx-auto bg-white p-6 rounded-xl border border-neutral-200 shadow-xs space-y-5">
              <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
                <h3 className="font-bold text-neutral-900 text-sm flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#c92228]" />
                  {editingId ? `Edit Schedule: ${formCode}` : 'Create New Despatch Schedule'}
                </h3>
                <button
                  type="button"
                  onClick={() => setViewMode('list')}
                  className="text-xs text-neutral-500 hover:text-neutral-800 font-semibold cursor-pointer"
                >
                  Back to List
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Schedule Code */}
                <div>
                  <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                    Schedule Code *
                  </label>
                  <input
                    type="text"
                    required
                    value={formCode}
                    onChange={(e) => setFormCode(e.target.value.toUpperCase())}
                    placeholder="e.g. SCH-01, SCH-AIR-02"
                    className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-xs font-mono font-bold uppercase text-neutral-900 focus:ring-2 focus:ring-[#c92228] focus:bg-white focus:outline-hidden"
                  />
                </div>

                {/* Departure Time */}
                <div>
                  <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                    Scheduled Departure Time
                  </label>
                  <input
                    type="time"
                    value={formDepartureTime}
                    onChange={(e) => setFormDepartureTime(e.target.value)}
                    className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-xs font-mono font-bold text-neutral-900 focus:ring-2 focus:ring-[#c92228] focus:bg-white focus:outline-hidden"
                  />
                </div>

                {/* Schedule Route Name */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                    Schedule Name / Route Description *
                  </label>
                  <input
                    type="text"
                    required
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    placeholder="e.g. Indore RMS - Bhopal NSH Morning Transit"
                    className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-xs font-bold text-neutral-900 focus:ring-2 focus:ring-[#c92228] focus:bg-white focus:outline-hidden"
                  />
                </div>

                {/* Destination Office (Transit Hub) */}
                <div className="sm:col-span-2">
                  <OfficeAutocomplete
                    id="schedule-destination-office"
                    label="Destination Office (Primary Transit Hub / Section) *"
                    value={formDestOffice}
                    onChange={setFormDestOffice}
                    placeholder="Search or pick Destination Office (e.g. Bhopal NSH, Mumbai NSH)..."
                    required
                  />
                  <p className="text-[11px] text-neutral-500 mt-1">
                    This is the destination office under this schedule where bags are despatched for bifurcation.
                  </p>
                </div>

                {/* Final Destination Offices Under this Destination */}
                <div className="sm:col-span-2 bg-neutral-50 p-4 rounded-xl border border-neutral-200">
                  <div className="flex items-center justify-between mb-2">
                    <label className="block text-xs font-bold text-neutral-800 uppercase tracking-wider">
                      Final Destination Offices (Under {formDestOffice || 'Destination Office'}) *
                    </label>
                    <span className="text-[11px] font-bold text-[#c92228]">
                      {formFinalDestList.length} configured
                    </span>
                  </div>
                  <p className="text-[11px] text-neutral-500 mb-3">
                    Bags despatched under this schedule will be bifurcated across these final destination offices in the mail list.
                  </p>

                  {/* Add Final Destination Input Box */}
                  <div className="flex gap-2 mb-3">
                    <input
                      type="text"
                      value={newFinalDestInput}
                      onChange={(e) => setNewFinalDestInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleAddFinalDestination();
                        }
                      }}
                      placeholder="Type final destination office name & PIN (e.g. Bhopal GPO 462001)..."
                      className="flex-1 px-3 py-2 bg-white border border-neutral-300 rounded-lg text-xs font-semibold text-neutral-900 focus:ring-2 focus:ring-[#c92228] focus:outline-hidden"
                    />
                    <button
                      type="button"
                      onClick={handleAddFinalDestination}
                      className="px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-white rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer shrink-0"
                    >
                      <Plus size={14} />
                      <span>Add Office</span>
                    </button>
                  </div>

                  {/* Quick suggestions if destination office is chosen */}
                  {formDestOffice.toLowerCase().includes('bhopal') && formFinalDestList.length === 0 && (
                    <div className="text-[11px] text-neutral-500 mb-3">
                      <span>Quick add Bhopal sub-offices: </span>
                      {['Bhopal GPO (462001)', 'Hoshangabad HO (461001)', 'Itarsi RMS TMO (461111)', 'Sehore HO (466001)'].map((s) => (
                        <button
                          key={s}
                          type="button"
                          onClick={() => setFormFinalDestList((prev) => [...prev, s])}
                          className="text-[#c92228] hover:underline mr-2 font-bold cursor-pointer"
                        >
                          + {s}
                        </button>
                      ))}
                    </div>
                  )}

                  {/* List of configured final destination offices */}
                  <div className="flex flex-wrap gap-2 min-h-[48px] p-2 bg-white rounded-lg border border-neutral-200">
                    {formFinalDestList.length === 0 ? (
                      <span className="text-xs text-neutral-400 italic p-1">
                        No final destination offices added yet. Type an office above and click "Add Office".
                      </span>
                    ) : (
                      formFinalDestList.map((dest) => (
                        <span
                          key={dest}
                          className="inline-flex items-center gap-1 px-2.5 py-1 bg-red-50 border border-red-200 text-neutral-800 rounded-lg text-xs font-semibold"
                        >
                          <Building2 size={12} className="text-[#c92228]" />
                          <span>{dest}</span>
                          <button
                            type="button"
                            onClick={() => handleRemoveFinalDestination(dest)}
                            className="text-neutral-400 hover:text-red-700 p-0.5 rounded cursor-pointer"
                            title="Remove"
                          >
                            <X size={12} />
                          </button>
                        </span>
                      ))
                    )}
                  </div>
                </div>

                {/* Transit Mode */}
                <div>
                  <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                    Transit Mode *
                  </label>
                  <select
                    value={formTransitMode}
                    onChange={(e) => setFormTransitMode(e.target.value as any)}
                    className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-xs font-bold text-neutral-900 focus:ring-2 focus:ring-[#c92228] focus:bg-white focus:outline-hidden"
                  >
                    <option value="Road / MMS">Road / MMS (Motor Mail Service)</option>
                    <option value="Train / RMS">Train / RMS (Railway Mail Service)</option>
                    <option value="Air Mail">Air Mail (Airport Sorting Hub)</option>
                    <option value="Special Van">Special Postal Van / Feeder</option>
                  </select>
                </div>

                {/* Carrier / Vehicle / Train */}
                <div>
                  <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                    Carrier / Train / Vehicle No.
                  </label>
                  <input
                    type="text"
                    value={formCarrier}
                    onChange={(e) => setFormCarrier(e.target.value)}
                    placeholder="e.g. MMS Van MP-09-AB-1234 or 12962 Avantika Exp"
                    className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-xs font-mono font-bold text-neutral-900 focus:ring-2 focus:ring-[#c92228] focus:bg-white focus:outline-hidden"
                  />
                </div>

                {/* Remarks */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                    Route Notes / Handover Instructions
                  </label>
                  <input
                    type="text"
                    value={formRemarks}
                    onChange={(e) => setFormRemarks(e.target.value)}
                    placeholder="e.g. Handover to Mail Guard at Platform 1. Connects Malwa line."
                    className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-xs font-semibold text-neutral-900 focus:ring-2 focus:ring-[#c92228] focus:bg-white focus:outline-hidden"
                  />
                </div>
              </div>

              {/* Form Buttons */}
              <div className="pt-4 border-t border-neutral-200 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setViewMode('list')}
                  className="px-4 py-2 bg-neutral-100 hover:bg-neutral-200 text-neutral-700 rounded-lg text-xs font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#c92228] hover:bg-[#a01217] text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Save size={15} />
                  <span>{editingId ? 'Save Schedule Changes' : 'Save & Register Schedule'}</span>
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Modal Footer */}
        <div className="bg-neutral-100 border-t border-neutral-200 px-5 py-3 flex items-center justify-between text-xs text-neutral-600 font-medium">
          <span>
            {schedules.length} schedules saved in local database for automated bag bifurcation
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-neutral-800 hover:bg-neutral-900 text-white rounded-lg font-bold transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
