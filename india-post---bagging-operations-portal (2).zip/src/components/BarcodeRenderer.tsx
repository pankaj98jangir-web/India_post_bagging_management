import React, { useEffect, useRef } from 'react';
import JsBarcode from 'jsbarcode';

interface BarcodeRendererProps {
  value: string;
  width?: number;
  height?: number;
  displayValue?: boolean;
  fontSize?: number;
  className?: string;
  format?: 'CODE128';
}

export const BarcodeRenderer: React.FC<BarcodeRendererProps> = ({
  value,
  width = 2,
  height = 55,
  displayValue = true,
  fontSize = 15,
  className = '',
  format = 'CODE128',
}) => {
  const svgRef = useRef<SVGSVGElement | null>(null);

  useEffect(() => {
    if (svgRef.current && value) {
      try {
        JsBarcode(svgRef.current, value, {
          format,
          width,
          height,
          displayValue,
          font: 'monospace',
          fontSize,
          textMargin: 4,
          margin: 6,
          background: '#ffffff',
          lineColor: '#000000',
        });
      } catch (err) {
        console.warn('Barcode rendering warning for', value, err);
      }
    }
  }, [value, width, height, displayValue, fontSize, format]);

  if (!value) return null;

  return (
    <div className={`inline-flex flex-col items-center justify-center ${className}`}>
      <svg ref={svgRef} className="max-w-full" />
    </div>
  );
};
