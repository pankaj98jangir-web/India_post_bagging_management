import React, { useState } from 'react';
import { ShiftRecord } from '../types';
import { formatIndianDate, deleteSavedShift } from '../utils/shiftStorage';
import {
  Archive,
  Calendar,
  Clock,
  Building,
  Layers,
  UserCheck,
  FileSpreadsheet,
  Download,
  Trash2,
  Eye,
  X,
  Package,
  RotateCcw,
  CheckCircle2,
  Search,
} from 'lucide-react';

interface ShiftHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  savedShifts: ShiftRecord[];
  onRefreshShifts: () => void;
  onRestoreShift: (shift: ShiftRecord) => void;
}

export const ShiftHistoryModal: React.FC<ShiftHistoryModalProps> = ({
  isOpen,
  onClose,
  savedShifts,
  onRefreshShifts,
  onRestoreShift,
}) => {
  const [selectedShift, setSelectedShift] = useState<ShiftRecord | null>(null);
  const [searchTerm, setSearchTerm] = useState<string>('');

  if (!isOpen) return null;

  const filteredShifts = savedShifts.filter((s) => {
    const term = searchTerm.toLowerCase();
    return (
      s.shiftDate.includes(term) ||
      s.id.toLowerCase().includes(term) ||
      s.officeName.toLowerCase().includes(term) ||
      s.setName.toLowerCase().includes(term) ||
      s.userId.includes(term)
    );
  });

  const handleDelete = (shiftId: string) => {
    if (window.confirm(`Are you sure you want to delete shift record ${shiftId} from local storage?`)) {
      deleteSavedShift(shiftId);
      onRefreshShifts();
      if (selectedShift?.id === shiftId) {
        setSelectedShift(null);
      }
    }
  };

  const handleExportJson = (shift: ShiftRecord) => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(shift, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `DOP_Shift_${shift.shiftDate}_${shift.setName.replace('/', '')}_${shift.id}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-3 sm:p-5 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-5xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-neutral-200 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-neutral-900 text-white px-6 py-4 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-red-600 rounded-xl">
              <Archive size={22} className="text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base leading-tight">
                  Saved Shifts & Local Storage Archive
                </h3>
                <span className="text-[10px] font-bold bg-amber-400 text-neutral-950 px-2 py-0.5 rounded font-mono">
                  {savedShifts.length} Saved {savedShifts.length === 1 ? 'Shift' : 'Shifts'}
                </span>
              </div>
              <p className="text-xs text-neutral-400 mt-0.5">
                Review, export, or reload past Department of Posts shifts saved on this workstation
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 hover:bg-neutral-800 rounded-lg text-neutral-400 hover:text-white transition-colors cursor-pointer"
          >
            <X size={20} />
          </button>
        </div>

        {/* Search Bar */}
        <div className="bg-neutral-100 border-b border-neutral-200 px-6 py-3 flex items-center justify-between gap-4 shrink-0">
          <div className="relative flex-1 max-w-md">
            <Search size={16} className="absolute left-3 top-2.5 text-neutral-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by date (YYYY-MM-DD), set, office, or user ID..."
              className="w-full pl-9 pr-4 py-1.5 bg-white border border-neutral-300 rounded-lg text-xs text-neutral-900 placeholder:text-neutral-400 focus:outline-hidden focus:ring-2 focus:ring-[#c92228]"
            />
          </div>
          <span className="text-xs text-neutral-500 font-medium">
            Persistent in browser LocalStorage
          </span>
        </div>

        {/* Main Body */}
        <div className="flex-1 overflow-y-auto p-6">
          {savedShifts.length === 0 ? (
            <div className="text-center py-12 px-4">
              <div className="w-16 h-16 bg-neutral-100 rounded-full flex items-center justify-center mx-auto mb-3 text-neutral-400">
                <Archive size={28} />
              </div>
              <h4 className="text-sm font-bold text-neutral-800 mb-1">No Saved Shifts Found</h4>
              <p className="text-xs text-neutral-500 max-w-md mx-auto mb-4">
                When you click <strong>"Shift End"</strong>, your shift records, bag manifests, and statistics are automatically stored here in local storage for future reference.
              </p>
            </div>
          ) : filteredShifts.length === 0 ? (
            <div className="text-center py-10 text-neutral-500 text-xs">
              No shifts match your search term "{searchTerm}".
            </div>
          ) : (
            <div className="space-y-4">
              {filteredShifts.map((shift) => {
                const isSelected = selectedShift?.id === shift.id;
                return (
                  <div
                    key={shift.id}
                    className={`rounded-xl border transition-all ${
                      isSelected
                        ? 'border-[#c92228] bg-red-50/20 shadow-xs'
                        : 'border-neutral-200 bg-white hover:border-neutral-300 hover:shadow-xs'
                    }`}
                  >
                    <div className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
                      {/* Left: Summary Info */}
                      <div className="space-y-2">
                        <div className="flex items-center flex-wrap gap-2">
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-neutral-900 text-white font-mono text-xs font-bold">
                            <Calendar size={13} className="text-amber-400" />
                            <span>{formatIndianDate(shift.shiftDate)}</span>
                          </span>

                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-amber-100 text-amber-900 font-bold text-xs">
                            <Layers size={12} />
                            <span>{shift.setName}</span>
                          </span>

                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-neutral-100 text-neutral-800 font-semibold text-xs">
                            <Building size={12} className="text-[#c92228]" />
                            <span>{shift.officeName}</span>
                          </span>

                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-neutral-100 text-neutral-700 font-mono text-xs">
                            <UserCheck size={12} className="text-emerald-600" />
                            <span>ID: {shift.userId}</span>
                          </span>

                          <span className="text-[10px] font-mono text-neutral-400">
                            {shift.id}
                          </span>
                        </div>

                        {/* Timing */}
                        <div className="flex items-center gap-2 text-xs text-neutral-500 flex-wrap">
                          <Clock size={13} className="text-neutral-400" />
                          <span>Started: <strong>{shift.startTime}</strong></span>
                          <span>•</span>
                          <span>Ended: <strong>{shift.endTime || 'Completed'}</strong></span>
                        </div>

                        {/* Badges Matrix */}
                        <div className="flex items-center flex-wrap gap-2 text-xs">
                          <span className="bg-blue-50 text-blue-800 px-2 py-0.5 rounded font-semibold border border-blue-100">
                            Bags Recv: <strong>{shift.summary.totalBagsReceived}</strong>
                          </span>
                          <span className="bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded font-semibold border border-emerald-100">
                            Bags Opened: <strong>{shift.summary.totalBagsOpened}</strong>
                          </span>
                          <span className="bg-amber-50 text-amber-800 px-2 py-0.5 rounded font-semibold border border-amber-100">
                            Bags Closed: <strong>{shift.summary.totalBagsClosed}</strong>
                          </span>
                          <span className="bg-red-50 text-red-800 px-2 py-0.5 rounded font-semibold border border-red-100">
                            Despatched: <strong>{shift.summary.totalBagsDespatched}</strong>
                          </span>
                          <span className="bg-neutral-100 text-neutral-800 px-2 py-0.5 rounded font-semibold">
                            Total Articles: <strong>{shift.summary.totalArticlesProcessed}</strong>
                          </span>
                          <span className="bg-neutral-100 text-neutral-800 px-2 py-0.5 rounded font-semibold">
                            Weight: <strong>{shift.summary.totalWeightKg} kg</strong>
                          </span>
                        </div>
                      </div>

                      {/* Right: Actions */}
                      <div className="flex items-center gap-2 shrink-0 self-start md:self-center">
                        <button
                          type="button"
                          onClick={() => setSelectedShift(isSelected ? null : shift)}
                          className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer border ${
                            isSelected
                              ? 'bg-neutral-900 text-white border-neutral-900'
                              : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                          }`}
                        >
                          <Eye size={14} />
                          <span>{isSelected ? 'Hide Details' : 'View Details'}</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => onRestoreShift(shift)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer shadow-2xs"
                          title="Restore this shift's bags into your active workspace"
                        >
                          <RotateCcw size={13} />
                          <span>Load / Restore</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleExportJson(shift)}
                          className="p-1.5 text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 rounded-lg border border-neutral-300 transition-colors cursor-pointer"
                          title="Export Shift Backup (JSON)"
                        >
                          <Download size={15} />
                        </button>

                        <button
                          type="button"
                          onClick={() => handleDelete(shift.id)}
                          className="p-1.5 text-red-600 hover:text-red-700 hover:bg-red-50 rounded-lg border border-red-200 transition-colors cursor-pointer"
                          title="Delete from Local Storage"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </div>

                    {/* Detailed Expanded Inspector */}
                    {isSelected && (
                      <div className="border-t border-neutral-200 bg-neutral-50/70 p-4 rounded-b-xl space-y-3 animate-in fade-in duration-100">
                        <div className="flex items-center justify-between">
                          <h5 className="text-xs font-bold text-neutral-800 uppercase tracking-wider flex items-center gap-1.5">
                            <Package size={14} className="text-[#c92228]" />
                            <span>Shift Bags Snapshot ({shift.bags.length} Bags Recorded)</span>
                          </h5>
                          {shift.handoverRemarks && (
                            <span className="text-[11px] text-neutral-600 italic">
                              "{shift.handoverRemarks}"
                            </span>
                          )}
                        </div>

                        {shift.bags.length === 0 ? (
                          <div className="text-xs text-neutral-500 italic py-2">
                            No bags were processed during this shift.
                          </div>
                        ) : (
                          <div className="overflow-x-auto max-h-48 border border-neutral-200 rounded-lg bg-white">
                            <table className="w-full text-[11px] text-left">
                              <thead className="bg-neutral-100 text-neutral-700 font-bold border-b border-neutral-200 sticky top-0">
                                <tr>
                                  <th className="p-2">#</th>
                                  <th className="p-2">Bag Barcode</th>
                                  <th className="p-2">Status</th>
                                  <th className="p-2">Origin</th>
                                  <th className="p-2">Destination</th>
                                  <th className="p-2 text-right">Articles</th>
                                  <th className="p-2 text-right">Weight (Kg)</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-neutral-100">
                                {shift.bags.map((b, idx) => (
                                  <tr key={b.id || idx} className="hover:bg-neutral-50">
                                    <td className="p-2 text-neutral-400 font-mono">{idx + 1}</td>
                                    <td className="p-2 font-mono font-bold text-neutral-900">{b.bagBarcode}</td>
                                    <td className="p-2">
                                      <span className="px-1.5 py-0.5 rounded text-[10px] font-bold uppercase bg-neutral-100 text-neutral-700">
                                        {b.bagStatus}
                                      </span>
                                    </td>
                                    <td className="p-2 text-neutral-600">{b.sourceOffice}</td>
                                    <td className="p-2 text-neutral-600">{b.destinationOffice}</td>
                                    <td className="p-2 text-right font-mono font-bold">{b.totalArticlesCount}</td>
                                    <td className="p-2 text-right font-mono">{b.bagWeightKg || 0}</td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-neutral-100 border-t border-neutral-200 px-6 py-3 flex items-center justify-between shrink-0">
          <span className="text-[11px] text-neutral-500">
            Shifts are persisted across browser sessions in standard LocalStorage.
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-neutral-800 hover:bg-neutral-900 text-white font-semibold rounded-lg text-xs cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
