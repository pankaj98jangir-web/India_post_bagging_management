import React, { useState, useEffect, useRef } from 'react';
import { ArticleItem, ArticleType, BagRecord, UserSession, ActionSuccessDetails } from '../../types';
import { validateArticleBarcode, generateRandomArticleBarcode } from '../../utils/barcode';
import { playScanSuccess, playScanError, playActionChime } from '../../utils/sound';
import { PackageOpen, Barcode, CheckCircle2, AlertCircle, Scan, Trash2, ShieldCheck, Sparkles } from 'lucide-react';

interface BagOpenTabProps {
  session: UserSession;
  bags: BagRecord[];
  onUpdateBag: (updatedBag: BagRecord) => void;
  onActionSuccess?: (details: ActionSuccessDetails) => void;
}

export const BagOpenTab: React.FC<BagOpenTabProps> = ({
  session,
  bags,
  onUpdateBag,
  onActionSuccess,
}) => {
  const [bagBarcode, setBagBarcode] = useState('');
  const [activeBag, setActiveBag] = useState<BagRecord | null>(null);

  // Article Type: Speed Post for Indore NSH, Parcel for Indore PH by default
  const defaultArticleType: ArticleType = session.officeName === 'Indore PH' ? 'Parcel' : 'Speed Post';
  const [articleType, setArticleType] = useState<ArticleType>(defaultArticleType);

  const [articleBarcode, setArticleBarcode] = useState('');
  const [isArticleInsured, setIsArticleInsured] = useState(false);
  const [scannedArticles, setScannedArticles] = useState<ArticleItem[]>([]);

  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const articleInputRef = useRef<HTMLInputElement | null>(null);
  const bagInputRef = useRef<HTMLInputElement | null>(null);

  // Update default article type when office changes
  useEffect(() => {
    setArticleType(session.officeName === 'Indore PH' ? 'Parcel' : 'Speed Post');
  }, [session.officeName]);

  // When bag barcode is entered or chosen, fetch bag details
  const handleFetchBag = (codeToFetch?: string) => {
    const code = (codeToFetch || bagBarcode).trim().toUpperCase();
    if (!code) {
      setErrorMsg('Please enter or scan a bag barcode to open.');
      return;
    }

    const found = bags.find((b) => b.bagBarcode.toUpperCase() === code);
    if (!found) {
      playScanError();
      setErrorMsg(`Bag ${code} was not found in received bags! Please receive it first in Sub Tab 1.`);
      setActiveBag(null);
      return;
    }

    if (found.bagStatus === 'opened') {
      playScanError();
      setErrorMsg(`Bag ${code} has ALREADY been opened!`);
    } else {
      playScanSuccess();
      setErrorMsg(null);
    }

    setActiveBag(found);
    setScannedArticles(found.articles || []);
    setSuccessMsg(`Fetched Bag ${code} from source: ${found.sourceOffice}`);

    // Auto-focus the article barcode scanner box
    setTimeout(() => {
      if (articleInputRef.current) {
        articleInputRef.current.focus();
      }
    }, 100);
  };

  // Auto-fetch bag barcode when 13 chars scanned
  const handleBagBarcodeChange = (val: string) => {
    const code = val.toUpperCase();
    setBagBarcode(code);
    if (code.length === 13) {
      setTimeout(() => {
        handleFetchBag(code);
      }, 50);
    }
  };

  // Add an article by code with insured flag auto-removal
  const addArticleByCode = (rawCode: string, insuredFlag: boolean) => {
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!activeBag) {
      playScanError();
      setErrorMsg('Please select or fetch a received bag before scanning articles.');
      return;
    }

    const codeClean = rawCode.trim().toUpperCase();
    if (!codeClean) {
      return;
    }

    const validation = validateArticleBarcode(codeClean);
    if (!validation.isValid) {
      playScanError();
      setErrorMsg(validation.error || 'Invalid 13-character article barcode.');
      return;
    }

    // Duplicate Check
    const exists = scannedArticles.some((a) => a.articleNumber.toUpperCase() === codeClean);
    if (exists) {
      playScanError();
      setErrorMsg(`DUPLICATE ARTICLE! Article ${codeClean} is already scanned in this bag.`);
      setArticleBarcode('');
      return;
    }

    const newArticle: ArticleItem = {
      id: `art-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      articleNumber: codeClean,
      articleType,
      isInsured: insuredFlag,
      scannedAt: new Date().toLocaleString('en-IN'),
      bagBarcode: activeBag.bagBarcode,
      destinationOffice: session.officeName,
    };

    setScannedArticles((prev) => [newArticle, ...prev]);
    setArticleBarcode('');

    // Crucial requirement: Insured article tick mark automatically removed after one article is scanned!
    setIsArticleInsured(false);

    playScanSuccess();
    setSuccessMsg(`Article ${codeClean} scanned successfully!${insuredFlag ? ' (Insured ✓)' : ''}`);

    // Refocus scanner input
    if (articleInputRef.current) {
      articleInputRef.current.focus();
    }
  };

  // Scanner onChange: automatically add article when barcode length reaches 13 characters
  const handleArticleInputChange = (val: string) => {
    const uppercaseVal = val.toUpperCase();
    setArticleBarcode(uppercaseVal);

    if (uppercaseVal.length === 13) {
      setTimeout(() => {
        addArticleByCode(uppercaseVal, isArticleInsured);
      }, 40);
    }
  };

  const handleScanArticleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addArticleByCode(articleBarcode, isArticleInsured);
  };

  const handleRemoveArticle = (id: string) => {
    setScannedArticles((prev) => prev.filter((a) => a.id !== id));
  };

  // Quick sample article
  const handleQuickAddSampleArticle = () => {
    const code = generateRandomArticleBarcode(articleType);
    setArticleBarcode(code);
    setTimeout(() => {
      addArticleByCode(code, isArticleInsured);
    }, 100);
  };

  // Complete Bag Open
  const handleCompleteBagOpen = () => {
    if (!activeBag) return;

    const updated: BagRecord = {
      ...activeBag,
      bagStatus: 'opened',
      openedAt: new Date().toLocaleString('en-IN'),
      articles: scannedArticles,
      totalArticlesCount: Math.max(activeBag.totalArticlesCount, scannedArticles.length),
    };

    onUpdateBag(updated);
    setActiveBag(updated);
    setSuccessMsg(`Bag ${activeBag.bagBarcode} successfully opened! ${scannedArticles.length} articles verified.`);

    // Trigger popup on every action done successfully
    if (onActionSuccess) {
      onActionSuccess({
        title: 'Bag Opened Successfully',
        subtitle: `Enclosed articles verified at ${session.officeName}`,
        badge: 'BAG OPENED',
        barcode: activeBag.bagBarcode,
        actionType: 'open',
        bag: updated,
        details: [
          { label: 'Origin Office', value: activeBag.sourceOffice },
          { label: 'Verified Articles Count', value: scannedArticles.length },
          { label: 'Expected Articles', value: activeBag.totalArticlesCount },
          { label: 'Insured Articles', value: scannedArticles.filter((a) => a.isInsured).length },
          { label: 'Duty Set / Office', value: `${session.setName} (${session.officeName})` },
          { label: 'Time Opened', value: updated.openedAt || new Date().toLocaleString('en-IN') },
        ],
      });
    }
  };

  // Keyboard shortcut listener for Bag Open Complete (Alt + O)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.altKey && (e.key === 'o' || e.key === 'O')) {
        e.preventDefault();
        if (activeBag && activeBag.bagStatus !== 'opened') {
          handleCompleteBagOpen();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeBag, scannedArticles]);

  const availableBags = bags.filter((b) => b.bagStatus === 'received for open');

  return (
    <div className="space-y-6">
      {/* Tab Header */}
      <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-neutral-900 flex items-center gap-2">
            <PackageOpen className="text-[#c92228]" size={22} />
            <span>Sub Tab 3: Bag Open</span>
            <span
              className="text-[11px] font-mono bg-neutral-100 text-neutral-600 px-2 py-0.5 rounded border border-neutral-200"
              title="Shortcut key for this tab: Alt + 3"
            >
              Alt+3
            </span>
          </h2>
          <p className="text-xs text-neutral-500 mt-0.5">
            Auto-scan bag labels & enclosed articles hands-free without manual button clicks
          </p>
        </div>
        <span className="text-xs font-semibold bg-emerald-50 text-emerald-800 px-3 py-1.5 rounded-full border border-emerald-200">
          Ready for Opening: {availableBags.length} Bags
        </span>
      </div>

      {errorMsg && (
        <div className="p-3.5 bg-red-50 border-l-4 border-red-600 rounded-r-lg flex items-center gap-3 text-red-800 text-xs font-semibold animate-in fade-in duration-100">
          <AlertCircle size={18} className="shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {successMsg && (
        <div className="p-3.5 bg-emerald-50 border-l-4 border-emerald-600 rounded-r-lg flex items-center gap-3 text-emerald-800 text-xs font-semibold animate-in fade-in duration-100">
          <CheckCircle2 size={18} className="shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Bag Selection & Details Fetch Bar */}
      <div className="bg-white p-6 rounded-xl border border-neutral-200 shadow-xs space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Barcode Scan Box: Auto-fetches when scanned */}
          <div className="md:col-span-2">
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider">
                Barcode (Bag Label) Scan Box *
              </label>
              <span className="text-[10px] text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                ⚡ Auto-Fetches on 13 Chars or Scanner Enter
              </span>
            </div>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <input
                  ref={bagInputRef}
                  type="text"
                  value={bagBarcode}
                  maxLength={13}
                  onChange={(e) => handleBagBarcodeChange(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleFetchBag();
                    }
                  }}
                  placeholder="Scan bag barcode (auto-fetches without clicking)..."
                  className="pc-scanner-input w-full pl-9 pr-4 py-2.5 bg-neutral-50 border-2 border-neutral-300 focus:border-[#c92228] rounded-lg text-sm font-mono font-bold uppercase text-neutral-900 focus:outline-hidden"
                  title="Scan bag label barcode (Shortcut: Auto-fetch on scan or Enter)"
                />
                <Barcode size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
              </div>
              <button
                type="button"
                onClick={() => handleFetchBag()}
                className="px-5 py-2.5 bg-[#c92228] hover:bg-[#a01217] text-white font-bold rounded-lg text-xs uppercase tracking-wider cursor-pointer transition-colors shadow-xs"
                title="Fetch Bag Details (Auto-fetches on scan)"
              >
                Fetch Bag
              </button>
            </div>
          </div>

          {/* Source Office: Auto-Fetched */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
              Source Office (Fetched from Bag)
            </label>
            <input
              type="text"
              readOnly
              value={activeBag?.sourceOffice || '— Pending Bag Scan —'}
              className="w-full px-3 py-2.5 bg-neutral-100 border border-neutral-300 rounded-lg text-sm font-bold text-neutral-800 cursor-not-allowed"
            />
          </div>
        </div>

        {/* Quick picker pills if bags exist */}
        {availableBags.length > 0 && (
          <div className="pt-2 border-t border-neutral-100 flex items-center gap-2 flex-wrap">
            <span className="text-[11px] font-bold text-neutral-500 uppercase">Quick Pick Bag:</span>
            {availableBags.slice(0, 5).map((b) => (
              <button
                key={b.id}
                type="button"
                onClick={() => {
                  setBagBarcode(b.bagBarcode);
                  handleFetchBag(b.bagBarcode);
                }}
                className={`px-2.5 py-1 rounded text-xs font-mono font-bold border transition-colors cursor-pointer ${
                  activeBag?.bagBarcode === b.bagBarcode
                    ? 'bg-[#c92228] text-white border-[#c92228]'
                    : 'bg-neutral-50 text-neutral-800 border-neutral-200 hover:bg-neutral-100'
                }`}
              >
                {b.bagBarcode} ({b.sourceOffice})
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Article Scanning Section (active only if bag is chosen) */}
      {activeBag && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Box: Scanned Articles List Box */}
          <div className="lg:col-span-7 bg-white rounded-xl border border-neutral-200 shadow-xs overflow-hidden flex flex-col">
            <div className="p-4 bg-neutral-50 border-b border-neutral-200 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-neutral-900 text-sm flex items-center gap-2">
                  <Scan size={16} className="text-[#c92228]" />
                  <span>Scanned Articles List Box ({scannedArticles.length})</span>
                </h3>
                <p className="text-xs text-neutral-500">
                  Enclosed articles verified inside bag {activeBag.bagBarcode}
                </p>
              </div>

              {/* Progress pill */}
              <div className="text-right">
                <span className="text-xs font-bold font-mono px-2.5 py-1 rounded-full bg-neutral-200 text-neutral-800">
                  {scannedArticles.length} / {activeBag.totalArticlesCount} Expected
                </span>
              </div>
            </div>

            {/* List */}
            <div className="p-4 flex-1 overflow-y-auto max-h-96 space-y-2">
              {scannedArticles.length === 0 ? (
                <div className="py-12 text-center text-neutral-400 text-xs italic">
                  No articles scanned yet. Just point your barcode scanner at the parcel/envelope barcode — it will automatically add without clicking!
                </div>
              ) : (
                scannedArticles.map((art, idx) => (
                  <div
                    key={art.id}
                    className="p-3 bg-neutral-50 border border-neutral-200 rounded-lg flex items-center justify-between hover:bg-neutral-100/70 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-xs font-bold text-neutral-400 w-6 text-center">{idx + 1}</span>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-neutral-900 text-sm">
                            {art.articleNumber}
                          </span>
                          {art.isInsured && (
                            <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-300">
                              <ShieldCheck size={11} /> INSURED
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-neutral-500">
                          {art.articleType} • Scanned: {art.scannedAt}
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleRemoveArticle(art.id)}
                      className="text-neutral-400 hover:text-red-600 p-1.5 rounded transition-colors cursor-pointer"
                      title="Remove Article"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Right Box: Scanner Controls & Expected Articles Details */}
          <div className="lg:col-span-5 space-y-5">
            {/* Scan Article Form */}
            <form onSubmit={handleScanArticleFormSubmit} className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-neutral-100">
                <h3 className="font-bold text-neutral-800 text-sm uppercase tracking-wider">
                  Scan Enclosed Article
                </h3>
                <span className="text-[10px] text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  ⚡ Auto-Adds on Scan
                </span>
              </div>

              {/* Article Barcode Scan Box */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider">
                    Article Barcode Scan Box (13 Chars) *
                  </label>
                  <button
                    type="button"
                    onClick={handleQuickAddSampleArticle}
                    className="text-[11px] font-semibold text-[#c92228] hover:underline cursor-pointer"
                    title="Generate and scan a sample article"
                  >
                    + Auto-Scan Sample
                  </button>
                </div>
                <div className="relative">
                  <input
                    ref={articleInputRef}
                    type="text"
                    value={articleBarcode}
                    maxLength={13}
                    onChange={(e) => handleArticleInputChange(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        addArticleByCode(articleBarcode, isArticleInsured);
                      }
                    }}
                    placeholder="Scan article with barcode scanner..."
                    className="pc-scanner-input w-full pl-9 pr-4 py-2.5 bg-neutral-50 border-2 border-neutral-300 focus:border-[#c92228] rounded-lg text-sm font-mono font-bold uppercase text-neutral-900 focus:outline-hidden"
                    title="Scan article barcode with scanner (Auto-adds on 13 characters or Enter)"
                    autoFocus
                  />
                  <Barcode size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
                </div>
                <p className="text-[10px] text-neutral-500 mt-1">
                  Scanner auto-adds immediately on scan. No button click required.
                </p>
              </div>

              {/* Article Type Selector & Insured Article Auto-Reset Checkbox */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                    Article Type
                  </label>
                  <select
                    value={articleType}
                    onChange={(e) => setArticleType(e.target.value as ArticleType)}
                    className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-xs font-bold text-neutral-900 cursor-pointer"
                  >
                    <option value="Speed Post">Speed Post (NSH)</option>
                    <option value="Parcel">Parcel (PH)</option>
                    <option value="Registered">Registered</option>
                  </select>
                </div>

                {/* Insured Article Tick Mark (Auto-resets after scanning one article!) */}
                <div className="flex flex-col justify-end">
                  <label
                    className={`flex items-center gap-2 p-2 rounded-lg text-xs font-bold border transition-all cursor-pointer select-none ${
                      isArticleInsured
                        ? 'bg-amber-100 border-amber-400 text-amber-950 shadow-xs'
                        : 'bg-neutral-50 border-neutral-300 text-neutral-700 hover:bg-neutral-100'
                    }`}
                    title="Tick first then scan barcode. Automatically removes tick mark after one article is scanned."
                  >
                    <input
                      type="checkbox"
                      checked={isArticleInsured}
                      onChange={(e) => setIsArticleInsured(e.target.checked)}
                      className="rounded text-[#c92228] focus:ring-[#c92228] cursor-pointer"
                    />
                    <span className="flex items-center gap-1">
                      <ShieldCheck size={14} className={isArticleInsured ? 'text-amber-700' : 'text-neutral-400'} />
                      <span>{isArticleInsured ? '✓ Insured Active' : 'Insured Article'}</span>
                    </span>
                  </label>
                </div>
              </div>

              {/* Optional manual add button with auto-scan indicator */}
              <button
                type="submit"
                className="w-full py-2.5 bg-neutral-900 hover:bg-black text-white font-bold rounded-lg text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer transition-colors shadow-xs"
                title="Add Scanned Article (Auto-adds on barcode scan or Enter)"
              >
                <Scan size={16} />
                <span>Add Scanned Article</span>
                <span className="text-[10px] font-mono bg-white/20 px-1.5 py-0.5 rounded text-neutral-300">
                  Auto-Scan On
                </span>
              </button>
            </form>

            {/* Expected Articles & Bag Details Summary (Fetched from received bags) */}
            <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs space-y-3">
              <h3 className="font-bold text-neutral-800 text-xs uppercase tracking-wider pb-2 border-b border-neutral-100">
                Expected Articles & Bag Verification
              </h3>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between py-1 border-b border-neutral-100">
                  <span className="text-neutral-500">Origin / Source Office:</span>
                  <span className="font-bold text-neutral-900">{activeBag.sourceOffice}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-neutral-100">
                  <span className="text-neutral-500">Expected Speed Post Articles:</span>
                  <span className="font-bold text-neutral-900">{activeBag.speedPostCount}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-neutral-100">
                  <span className="text-neutral-500">Expected Insured Articles:</span>
                  <span className="font-bold text-amber-700">{activeBag.insuredCount}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-neutral-100">
                  <span className="text-neutral-500">Total Expected Articles:</span>
                  <span className="font-bold text-neutral-900">{activeBag.totalArticlesCount}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-neutral-500">Current Status:</span>
                  <span className="font-bold uppercase text-blue-700">{activeBag.bagStatus}</span>
                </div>
              </div>

              {/* Complete Bag Open Button with Hover Shortcut & Visual Key Badge */}
              <div className="pt-3">
                <button
                  type="button"
                  onClick={handleCompleteBagOpen}
                  disabled={activeBag.bagStatus === 'opened'}
                  className={`group relative w-full py-3 px-4 rounded-lg font-bold text-sm uppercase tracking-wide flex items-center justify-center gap-2 cursor-pointer transition-colors shadow-sm ${
                    activeBag.bagStatus === 'opened'
                      ? 'bg-neutral-200 text-neutral-500 cursor-not-allowed'
                      : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                  }`}
                  title="Complete Bag Open (Shortcut: Alt + O)"
                >
                  <CheckCircle2 size={18} />
                  <span>
                    {activeBag.bagStatus === 'opened' ? 'Bag Already Opened' : 'Bag Open (Complete)'}
                  </span>
                  {activeBag.bagStatus !== 'opened' && (
                    <kbd className="ml-2 px-1.5 py-0.5 rounded bg-emerald-800/60 text-white text-[10px] font-mono uppercase tracking-normal">
                      Alt+O
                    </kbd>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
