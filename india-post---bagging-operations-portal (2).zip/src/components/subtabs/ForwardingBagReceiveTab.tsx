import React, { useState, useEffect, useRef } from 'react';
import { BagRecord, UserSession, ActionSuccessDetails } from '../../types';
import { OfficeAutocomplete } from '../OfficeAutocomplete';
import { OfficeDirectoryModal } from '../OfficeDirectoryModal';
import { validateBagBarcode } from '../../utils/barcode';
import { ArrowRightLeft, Barcode, CheckCircle2, AlertCircle, PlusCircle, Building2 } from 'lucide-react';

interface ForwardingBagReceiveTabProps {
  session: UserSession;
  bags: BagRecord[];
  onReceiveForwardingBag: (newBag: BagRecord) => void;
  onDeleteBag?: (bagId: string) => void;
  onActionSuccess?: (details: ActionSuccessDetails) => void;
}

export const ForwardingBagReceiveTab: React.FC<ForwardingBagReceiveTabProps> = ({
  session,
  bags,
  onReceiveForwardingBag,
  onDeleteBag,
  onActionSuccess,
}) => {
  const [bagBarcode, setBagBarcode] = useState('');
  // Source Office (by default: office in which working, but editable)
  const [sourceOffice, setSourceOffice] = useState(session.officeName);
  const [destinationOffice, setDestinationOffice] = useState('Bhopal NSH');
  const [bagStatus, setBagStatus] = useState<'received for forwarding'>('received for forwarding');
  const [weightKg, setWeightKg] = useState<string>('3.800');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [isDirModalOpen, setIsDirModalOpen] = useState(false);
  const inputRef = useRef<HTMLInputElement | null>(null);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const barcodeClean = bagBarcode.trim().toUpperCase();
    if (!barcodeClean) {
      setErrorMsg('Please scan or enter a 13-character bag barcode.');
      return;
    }

    const validation = validateBagBarcode(barcodeClean);
    if (!validation.isValid) {
      setErrorMsg(validation.error || 'Invalid 13-character bag barcode.');
      return;
    }

    // Duplicate Check
    const duplicate = bags.find((b) => b.bagBarcode.toUpperCase() === barcodeClean);
    if (duplicate) {
      setErrorMsg(`DUPLICATE ENTRY! Bag ${barcodeClean} is already registered in the system.`);
      return;
    }

    if (!sourceOffice.trim()) {
      setErrorMsg('Please specify the source office.');
      return;
    }

    if (!destinationOffice.trim()) {
      setErrorMsg('Please specify the destination office.');
      return;
    }

    const newBag: BagRecord = {
      id: `bag-fwd-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      bagBarcode: barcodeClean,
      sourceOffice: sourceOffice.trim(),
      destinationOffice: destinationOffice.trim(),
      bagStatus: 'received for forwarding',
      speedPostCount: 0,
      insuredCount: 0,
      totalArticlesCount: 0,
      setName: session.setName,
      officeName: session.officeName,
      receivedAt: new Date().toLocaleString('en-IN'),
      bagWeightKg: parseFloat(weightKg) || 3.5,
      articles: [],
    };

    onReceiveForwardingBag(newBag);
    setSuccessMsg(`Forwarding Bag ${barcodeClean} successfully recorded for transit to ${destinationOffice.trim()}!`);

    if (onActionSuccess) {
      onActionSuccess({
        title: 'Forwarding Bag Received Successfully',
        subtitle: `Registered in transit to ${destinationOffice.trim()}`,
        badge: 'FORWARDING BAG',
        barcode: barcodeClean,
        actionType: 'forward_receive',
        bag: newBag,
        details: [
          { label: 'Origin Office', value: sourceOffice.trim() },
          { label: 'Destination Office', value: destinationOffice.trim() },
          { label: 'Bag Weight', value: `${newBag.bagWeightKg?.toFixed(3)} KG` },
          { label: 'Duty Set / Office', value: `${session.setName} (${session.officeName})` },
          { label: 'Status', value: 'Received for Forwarding' },
          { label: 'Time Received', value: newBag.receivedAt || new Date().toLocaleString('en-IN') },
        ],
      });
    }

    setBagBarcode('');
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  // Keyboard shortcut (Alt + F)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.altKey && (e.key === 'f' || e.key === 'F')) {
        e.preventDefault();
        handleSubmit();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [bagBarcode, sourceOffice, destinationOffice, weightKg, bags]);

  const handleFillSample = () => {
    const randomDigits = Math.floor(1000000000 + Math.random() * 9000000000);
    setBagBarcode(`LBI${randomDigits}`);
  };

  const forwardingBags = bags.filter((b) => b.bagStatus === 'received for forwarding');

  return (
    <div className="space-y-6">
      {/* Tab Header */}
      <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-neutral-900 flex items-center gap-2">
            <ArrowRightLeft className="text-[#c92228]" size={22} />
            <span>Sub Tab 2: Forwarding Bag Receive</span>
            <span
              className="text-[11px] font-mono bg-neutral-100 text-neutral-600 px-2 py-0.5 rounded border border-neutral-200"
              title="Shortcut key for this tab: Alt + 2"
            >
              Alt+2
            </span>
          </h2>
          <p className="text-xs text-neutral-500 mt-0.5">
            Log transit / closed bags received for onward transmission without opening
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setIsDirModalOpen(true)}
            className="px-3 py-1.5 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer border border-neutral-300"
            title="Manage and update source/destination offices and PIN codes"
          >
            <Building2 size={14} className="text-[#c92228]" />
            <span>Office & PIN Directory</span>
          </button>
          <span className="text-xs font-semibold bg-purple-50 text-purple-700 px-3 py-1.5 rounded-full border border-purple-200">
            Forwarding Bags: {forwardingBags.length}
          </span>
        </div>
      </div>

      {errorMsg && (
        <div className="p-3.5 bg-red-50 border-l-4 border-red-600 rounded-r-lg flex items-center gap-3 text-red-800 text-xs font-semibold">
          <AlertCircle size={18} className="shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {successMsg && (
        <div className="p-3.5 bg-emerald-50 border-l-4 border-emerald-600 rounded-r-lg flex items-center gap-3 text-emerald-800 text-xs font-semibold">
          <CheckCircle2 size={18} className="shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Main Receiving Form */}
      <form onSubmit={handleSubmit} className="bg-white p-6 rounded-xl border border-neutral-200 shadow-xs space-y-5">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Barcode Scan Box */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider">
                Barcode (Bag Label) Scan Box *
              </label>
              <button
                type="button"
                onClick={handleFillSample}
                className="text-[11px] font-semibold text-[#c92228] hover:underline"
              >
                + Generate Sample
              </button>
            </div>
            <div className="relative">
              <input
                ref={inputRef}
                type="text"
                value={bagBarcode}
                maxLength={13}
                onChange={(e) => setBagBarcode(e.target.value.toUpperCase())}
                placeholder="Scan 13-character forwarding bag label..."
                className="w-full pl-9 pr-4 py-2.5 bg-neutral-50 border-2 border-neutral-300 focus:border-[#c92228] rounded-lg text-sm font-mono font-bold uppercase text-neutral-900 focus:outline-hidden"
                autoFocus
              />
              <Barcode size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
            </div>
            <p className="text-[10px] text-neutral-500 mt-1">
              Must be 13 characters (3 letters + 10 digits).
            </p>
          </div>

          {/* Bag Status (Default: received for forwarding) */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
              Bag Status (Default)
            </label>
            <input
              type="text"
              readOnly
              value={bagStatus}
              className="w-full px-3 py-2.5 bg-neutral-100 border border-neutral-300 rounded-lg text-xs font-bold text-purple-900 cursor-not-allowed uppercase"
            />
            <p className="text-[10px] text-neutral-500 mt-1">
              Set automatically to "received for forwarding".
            </p>
          </div>
        </div>

        {/* Source and Destination Offices */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-1">
          {/* Source Office (Default: working office, editable) */}
          <OfficeAutocomplete
            id="fwd-source-office"
            label="Source Office (Default: Working Office, Editable) *"
            value={sourceOffice}
            onChange={setSourceOffice}
            placeholder="Search or edit source office..."
            required
          />

          {/* Destination Office */}
          <OfficeAutocomplete
            id="fwd-dest-office"
            label="Destination Office (Where Bag is Routed) *"
            value={destinationOffice}
            onChange={setDestinationOffice}
            placeholder="Search destination Sub Post Office, NSH, PH..."
            required
          />
        </div>

        {/* Bag Weight */}
        <div className="w-full sm:w-1/3">
          <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
            Forwarding Bag Weight (KG)
          </label>
          <input
            type="number"
            step="0.005"
            min={0.1}
            value={weightKg}
            onChange={(e) => setWeightKg(e.target.value)}
            className="w-full px-3 py-2.5 bg-neutral-50 border border-neutral-300 rounded-lg text-sm font-bold text-neutral-900 focus:ring-2 focus:ring-[#c92228] focus:outline-hidden"
          />
        </div>

        {/* Submit */}
        <div className="flex items-center justify-end pt-4 border-t border-neutral-200">
          <button
            type="submit"
            className="px-6 py-2.5 bg-[#c92228] hover:bg-[#a01217] text-white font-bold rounded-lg shadow-sm text-sm uppercase tracking-wide flex items-center gap-2 cursor-pointer transition-colors"
            title="Receive Forwarding Bag (Shortcut: Alt + F)"
          >
            <PlusCircle size={17} />
            <span>Receive Bags</span>
            <kbd className="ml-1.5 px-1.5 py-0.5 rounded bg-red-900/60 text-white text-[10px] font-mono tracking-normal">
              Alt+F
            </kbd>
          </button>
        </div>
      </form>

      {/* Forwarding Bags Table */}
      <div className="bg-white rounded-xl border border-neutral-200 shadow-xs overflow-hidden">
        <div className="px-5 py-4 border-b border-neutral-200 bg-neutral-50">
          <h3 className="font-bold text-neutral-800 text-sm">
            Forwarding Bags in Current Duty Set ({forwardingBags.length})
          </h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-neutral-100 text-neutral-700 font-bold border-b border-neutral-200 uppercase tracking-wider">
              <tr>
                <th className="py-3 px-4">Bag Barcode</th>
                <th className="py-3 px-4">Source Office</th>
                <th className="py-3 px-4">Destination Office</th>
                <th className="py-3 px-4">Weight (KG)</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Received Time</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-200">
              {forwardingBags.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-neutral-500 italic">
                    No forwarding bags received in this set yet.
                  </td>
                </tr>
              ) : (
                forwardingBags.map((bag) => (
                  <tr key={bag.id} className="hover:bg-neutral-50">
                    <td className="py-3 px-4 font-mono font-bold text-neutral-900">
                      {bag.bagBarcode}
                    </td>
                    <td className="py-3 px-4 font-medium text-neutral-800">
                      {bag.sourceOffice}
                    </td>
                    <td className="py-3 px-4 font-bold text-[#c92228]">
                      {bag.destinationOffice}
                    </td>
                    <td className="py-3 px-4 font-semibold text-neutral-700">
                      {bag.bagWeightKg ? `${bag.bagWeightKg.toFixed(3)}` : '—'}
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 text-purple-800 uppercase">
                        {bag.bagStatus}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-neutral-500 font-mono text-[11px]">
                      {bag.receivedAt || '—'}
                    </td>
                    <td className="py-3 px-4 text-right">
                      {onDeleteBag && (
                        <button
                          onClick={() => onDeleteBag(bag.id)}
                          className="p-1 text-neutral-400 hover:text-red-600 rounded text-xs font-semibold"
                        >
                          Delete
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Office & PIN Directory Manager Modal */}
      <OfficeDirectoryModal
        isOpen={isDirModalOpen}
        onClose={() => setIsDirModalOpen(false)}
        selectedOffice={destinationOffice}
        onSelectOffice={(officeName) => {
          setDestinationOffice(officeName);
          setIsDirModalOpen(false);
        }}
      />
    </div>
  );
};
