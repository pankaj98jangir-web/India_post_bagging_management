import React, { useState, useEffect } from 'react';
import { UserSession, ManualBagAbstractRow, ManualArticleAbstractRow, ManualConsolidatedAbstractData } from '../../types';
import {
  FileSpreadsheet,
  Plus,
  Trash2,
  Save,
  RotateCcw,
  Printer,
  FileDown,
  Copy,
  Users,
  PackageCheck,
  Mail,
  CheckCircle2,
  AlertCircle,
  Clock,
  Sparkles,
  Calendar,
} from 'lucide-react';
import { getTodayDateString, formatIndianDate } from '../../utils/shiftStorage';
import { printIsolatedElement } from '../../utils/pdfGenerator';

interface CreateConsolidatedAbstractTabProps {
  session: UserSession | null;
}

const STORAGE_KEY = 'dop_manual_consolidated_abstract_v1';
const HISTORY_STORAGE_KEY = 'dop_manual_abstract_history_v1';

export const CreateConsolidatedAbstractTab: React.FC<CreateConsolidatedAbstractTabProps> = ({ session }) => {
  const today = getTodayDateString();

  // Abstract Metadata
  const [abstractDate, setAbstractDate] = useState<string>(today);
  const [officeName, setOfficeName] = useState<string>(session?.officeName || 'Indore NSH');
  const [setName, setSetName] = useState<string>(session?.setName || 'SET/1');
  const [supervisorName, setSupervisorName] = useState<string>('Duty Supervisor');
  const [notes, setNotes] = useState<string>('');
  const [saveStatus, setSaveStatus] = useState<string | null>(null);

  // Table 1: Bag Details (Employee ID, Employee Name, Bag Received, Bag Closed, Bag Dispatched)
  // All manually filled, not fetched from set data.
  const [bagRows, setBagRows] = useState<ManualBagAbstractRow[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed.bagRows) && parsed.bagRows.length > 0) {
          return parsed.bagRows;
        }
      } catch {
        // fallback
      }
    }
    return [
      { id: 'b-row-1', employeeId: '10048219', employeeName: 'R. K. Sharma', bagReceived: '', bagClosed: '', bagDispatched: '' },
      { id: 'b-row-2', employeeId: '10048220', employeeName: 'M. P. Verma', bagReceived: '', bagClosed: '', bagDispatched: '' },
      { id: 'b-row-3', employeeId: '10048225', employeeName: 'S. K. Patel', bagReceived: '', bagClosed: '', bagDispatched: '' },
    ];
  });

  // Table 2: Article Details (Employee ID, Employee Name, Article Closed, Insured Article Closed, Total Article Closed)
  // All manually filled, not fetched from set data.
  const [articleRows, setArticleRows] = useState<ManualArticleAbstractRow[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed.articleRows) && parsed.articleRows.length > 0) {
          return parsed.articleRows;
        }
      } catch {
        // fallback
      }
    }
    return [
      { id: 'a-row-1', employeeId: '10048219', employeeName: 'R. K. Sharma', articleClosed: '', insuredArticleClosed: '', totalArticleClosed: '' },
      { id: 'a-row-2', employeeId: '10048220', employeeName: 'M. P. Verma', articleClosed: '', insuredArticleClosed: '', totalArticleClosed: '' },
      { id: 'a-row-3', employeeId: '10048225', employeeName: 'S. K. Patel', articleClosed: '', insuredArticleClosed: '', totalArticleClosed: '' },
    ];
  });

  // Auto-save work in progress to local storage
  useEffect(() => {
    const payload: ManualConsolidatedAbstractData = {
      id: `MCA-${abstractDate.replace(/-/g, '')}-${setName.replace(/[/]/g, '')}`,
      date: abstractDate,
      officeName,
      setName,
      supervisorName,
      notes,
      bagRows,
      articleRows,
      savedAt: new Date().toISOString(),
    };
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
    } catch (e) {
      console.error('Failed to save manual abstract state', e);
    }
  }, [abstractDate, officeName, setName, supervisorName, notes, bagRows, articleRows]);

  // --- Table 1 Row Handlers ---
  const handleAddBagRow = () => {
    const newRow: ManualBagAbstractRow = {
      id: `b-row-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      employeeId: '',
      employeeName: '',
      bagReceived: '',
      bagClosed: '',
      bagDispatched: '',
    };
    setBagRows((prev) => [...prev, newRow]);
  };

  const handleUpdateBagRow = (id: string, field: keyof ManualBagAbstractRow, value: string) => {
    setBagRows((prev) =>
      prev.map((row) => {
        if (row.id !== id) return row;
        if (field === 'bagReceived' || field === 'bagClosed' || field === 'bagDispatched') {
          const num = value === '' ? '' : Math.max(0, parseInt(value, 10) || 0);
          return { ...row, [field]: num };
        }
        return { ...row, [field]: value };
      })
    );
  };

  const handleDeleteBagRow = (id: string) => {
    if (bagRows.length <= 1) {
      // Keep at least one empty row
      setBagRows([{ id: `b-row-${Date.now()}`, employeeId: '', employeeName: '', bagReceived: '', bagClosed: '', bagDispatched: '' }]);
      return;
    }
    setBagRows((prev) => prev.filter((r) => r.id !== id));
  };

  // --- Table 2 Row Handlers ---
  const handleAddArticleRow = () => {
    const newRow: ManualArticleAbstractRow = {
      id: `a-row-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      employeeId: '',
      employeeName: '',
      articleClosed: '',
      insuredArticleClosed: '',
      totalArticleClosed: '',
    };
    setArticleRows((prev) => [...prev, newRow]);
  };

  const handleUpdateArticleRow = (id: string, field: keyof ManualArticleAbstractRow, value: string) => {
    setArticleRows((prev) =>
      prev.map((row) => {
        if (row.id !== id) return row;
        if (field === 'articleClosed' || field === 'insuredArticleClosed') {
          const num = value === '' ? '' : Math.max(0, parseInt(value, 10) || 0);
          const otherField = field === 'articleClosed' ? row.insuredArticleClosed : row.articleClosed;
          const artClosed = field === 'articleClosed' ? (num === '' ? 0 : num) : (row.articleClosed === '' ? 0 : row.articleClosed);
          const insClosed = field === 'insuredArticleClosed' ? (num === '' ? 0 : num) : (row.insuredArticleClosed === '' ? 0 : row.insuredArticleClosed);
          const autoTotal = artClosed + insClosed;
          return {
            ...row,
            [field]: num,
            totalArticleClosed: autoTotal > 0 ? autoTotal : (row.totalArticleClosed !== '' && row.totalArticleClosed !== 0 ? row.totalArticleClosed : ''),
          };
        }
        if (field === 'totalArticleClosed') {
          const num = value === '' ? '' : Math.max(0, parseInt(value, 10) || 0);
          return { ...row, totalArticleClosed: num };
        }
        return { ...row, [field]: value };
      })
    );
  };

  const handleDeleteArticleRow = (id: string) => {
    if (articleRows.length <= 1) {
      setArticleRows([{ id: `a-row-${Date.now()}`, employeeId: '', employeeName: '', articleClosed: '', insuredArticleClosed: '', totalArticleClosed: '' }]);
      return;
    }
    setArticleRows((prev) => prev.filter((r) => r.id !== id));
  };

  // Copy employee roster from Table 1 into Table 2
  const handleCopyEmployeesFromTable1 = () => {
    const newArticleRows = bagRows.map((bRow, idx) => {
      const existing = articleRows[idx];
      return {
        id: existing?.id || `a-row-${Date.now()}-${idx}`,
        employeeId: bRow.employeeId,
        employeeName: bRow.employeeName,
        articleClosed: existing?.articleClosed ?? '',
        insuredArticleClosed: existing?.insuredArticleClosed ?? '',
        totalArticleClosed: existing?.totalArticleClosed ?? '',
      };
    });
    setArticleRows(newArticleRows);
    setSaveStatus('Employee list synchronized from Table 1 to Table 2!');
    setTimeout(() => setSaveStatus(null), 3000);
  };

  // Reset entire form
  const handleReset = () => {
    if (window.confirm('Clear all manual entries in both tables?')) {
      setBagRows([
        { id: `b-row-${Date.now()}-1`, employeeId: '', employeeName: '', bagReceived: '', bagClosed: '', bagDispatched: '' },
        { id: `b-row-${Date.now()}-2`, employeeId: '', employeeName: '', bagReceived: '', bagClosed: '', bagDispatched: '' },
      ]);
      setArticleRows([
        { id: `a-row-${Date.now()}-1`, employeeId: '', employeeName: '', articleClosed: '', insuredArticleClosed: '', totalArticleClosed: '' },
        { id: `a-row-${Date.now()}-2`, employeeId: '', employeeName: '', articleClosed: '', insuredArticleClosed: '', totalArticleClosed: '' },
      ]);
      setNotes('');
      setSaveStatus('Tables cleared for fresh manual entry.');
      setTimeout(() => setSaveStatus(null), 2500);
    }
  };

  // Save as permanent snapshot in history
  const handleSaveToArchive = () => {
    const record: ManualConsolidatedAbstractData = {
      id: `MCA-${abstractDate.replace(/-/g, '')}-${Date.now().toString().slice(-4)}`,
      date: abstractDate,
      officeName,
      setName,
      supervisorName,
      notes,
      bagRows,
      articleRows,
      savedAt: new Date().toISOString(),
    };

    try {
      const existingRaw = localStorage.getItem(HISTORY_STORAGE_KEY);
      const existing: ManualConsolidatedAbstractData[] = existingRaw ? JSON.parse(existingRaw) : [];
      const updated = [record, ...existing.slice(0, 49)];
      localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(updated));
      setSaveStatus(`Abstract saved to local storage archive (ID: ${record.id})`);
      setTimeout(() => setSaveStatus(null), 3500);
    } catch (e) {
      console.error('Failed to save to history', e);
      setSaveStatus('Saved locally to browser storage.');
      setTimeout(() => setSaveStatus(null), 3000);
    }
  };

  // Print Isolated View
  const handlePrint = () => {
    printIsolatedElement('printable-manual-consolidated-abstract', `Consolidated Abstract - ${abstractDate} - ${officeName}`);
  };

  // Export as CSV
  const handleExportCSV = () => {
    let csv = `DEPARTMENT OF POSTS - CONSOLIDATED ABSTRACT (MANUAL ENTRY)\n`;
    csv += `Date: ${abstractDate}, Office: ${officeName}, Set: ${setName}, Supervisor: ${supervisorName}\n\n`;

    csv += `TABLE 1: BAG DETAILS\n`;
    csv += `Employee ID,Employee Name,Bag Received,Bag Closed,Bag Dispatched\n`;
    bagRows.forEach((r) => {
      csv += `"${r.employeeId}","${r.employeeName}",${r.bagReceived || 0},${r.bagClosed || 0},${r.bagDispatched || 0}\n`;
    });
    csv += `TOTALS,,${totalBagsReceived},${totalBagsClosed},${totalBagsDispatched}\n\n`;

    csv += `TABLE 2: ARTICLE DETAILS\n`;
    csv += `Employee ID,Employee Name,Article Closed,Insured Article Closed,Total Article Closed\n`;
    articleRows.forEach((r) => {
      csv += `"${r.employeeId}","${r.employeeName}",${r.articleClosed || 0},${r.insuredArticleClosed || 0},${r.totalArticleClosed || 0}\n`;
    });
    csv += `TOTALS,,${totalArticleClosed},${totalInsuredArticleClosed},${grandTotalArticlesClosed}\n`;

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `Consolidated_Abstract_${abstractDate}_${setName}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Table 1 Calculations
  const totalBagsReceived = bagRows.reduce((acc, r) => acc + (typeof r.bagReceived === 'number' ? r.bagReceived : 0), 0);
  const totalBagsClosed = bagRows.reduce((acc, r) => acc + (typeof r.bagClosed === 'number' ? r.bagClosed : 0), 0);
  const totalBagsDispatched = bagRows.reduce((acc, r) => acc + (typeof r.bagDispatched === 'number' ? r.bagDispatched : 0), 0);
  const grandTotalBags = totalBagsReceived + totalBagsClosed + totalBagsDispatched;

  // Table 2 Calculations
  const totalArticleClosed = articleRows.reduce((acc, r) => acc + (typeof r.articleClosed === 'number' ? r.articleClosed : 0), 0);
  const totalInsuredArticleClosed = articleRows.reduce((acc, r) => acc + (typeof r.insuredArticleClosed === 'number' ? r.insuredArticleClosed : 0), 0);
  const grandTotalArticlesClosed = articleRows.reduce((acc, r) => acc + (typeof r.totalArticleClosed === 'number' ? r.totalArticleClosed : 0), 0);

  return (
    <div className="space-y-6">
      {/* Top Banner & Configuration Bar */}
      <div className="bg-white rounded-xl border border-neutral-200 p-5 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-neutral-200 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-[#c92228] text-white rounded-xl shadow-xs">
              <FileSpreadsheet size={24} />
            </div>
            <div>
              <h2 className="text-base font-black uppercase tracking-wide text-neutral-900 flex items-center gap-2">
                <span>Create Consolidated Abstract</span>
                <span className="text-[10px] font-mono bg-neutral-100 text-neutral-700 px-2 py-0.5 rounded border border-neutral-300">
                  SUB TAB 11 • MANUAL ENTRY
                </span>
              </h2>
              <p className="text-xs text-neutral-600 mt-0.5">
                Staff duty performance entry for Bags and Articles. Entries are completely manually entered and decoupled from automated sets.
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 flex-wrap">
            <button
              type="button"
              onClick={handleSaveToArchive}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-[#1b5e20] hover:bg-[#144717] text-white rounded-lg text-xs font-bold transition-colors cursor-pointer shadow-2xs"
              title="Save manual abstract to local storage"
            >
              <Save size={14} />
              <span>Save Abstract</span>
            </button>

            <button
              type="button"
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-neutral-900 hover:bg-black text-white rounded-lg text-xs font-bold transition-colors cursor-pointer shadow-2xs"
              title="Print abstract"
            >
              <Printer size={14} />
              <span>Print Form</span>
            </button>

            <button
              type="button"
              onClick={handleExportCSV}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-neutral-50 text-neutral-700 rounded-lg text-xs font-semibold border border-neutral-300 transition-colors cursor-pointer shadow-2xs"
              title="Export as CSV spreadsheet"
            >
              <FileDown size={14} />
              <span>Export CSV</span>
            </button>

            <button
              type="button"
              onClick={handleReset}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 bg-neutral-100 hover:bg-neutral-200 text-neutral-700 rounded-lg text-xs font-medium border border-neutral-300 transition-colors cursor-pointer"
              title="Reset all values to blank"
            >
              <RotateCcw size={13} />
              <span>Clear</span>
            </button>
          </div>
        </div>

        {/* Status Notification */}
        {saveStatus && (
          <div className="mt-3 p-2 bg-emerald-50 border border-emerald-300 rounded-lg text-xs font-semibold text-emerald-800 flex items-center gap-2">
            <CheckCircle2 size={14} className="text-emerald-600 shrink-0" />
            <span>{saveStatus}</span>
          </div>
        )}

        {/* Abstract Parameters Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-4 text-xs">
          <div>
            <label className="block text-[11px] font-bold text-neutral-600 mb-1">
              Duty / Shift Date
            </label>
            <div className="relative">
              <input
                type="date"
                value={abstractDate}
                onChange={(e) => setAbstractDate(e.target.value)}
                className="w-full bg-neutral-50 border border-neutral-300 rounded-lg px-2.5 py-1.5 text-xs font-medium text-neutral-900 focus:bg-white focus:border-[#c92228] focus:ring-1 focus:ring-[#c92228] outline-hidden"
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-neutral-600 mb-1">
              Working Office
            </label>
            <input
              type="text"
              value={officeName}
              onChange={(e) => setOfficeName(e.target.value)}
              placeholder="e.g. Indore NSH"
              className="w-full bg-neutral-50 border border-neutral-300 rounded-lg px-2.5 py-1.5 text-xs font-medium text-neutral-900 focus:bg-white focus:border-[#c92228] focus:ring-1 focus:ring-[#c92228] outline-hidden"
            />
          </div>

          <div>
            <label className="block text-[11px] font-bold text-neutral-600 mb-1">
              Duty Set
            </label>
            <input
              type="text"
              value={setName}
              onChange={(e) => setSetName(e.target.value)}
              placeholder="e.g. SET/1"
              className="w-full bg-neutral-50 border border-neutral-300 rounded-lg px-2.5 py-1.5 text-xs font-medium text-neutral-900 focus:bg-white focus:border-[#c92228] focus:ring-1 focus:ring-[#c92228] outline-hidden"
            />
          </div>

          <div>
            <label className="block text-[11px] font-bold text-neutral-600 mb-1">
              Supervisor / Verifier
            </label>
            <input
              type="text"
              value={supervisorName}
              onChange={(e) => setSupervisorName(e.target.value)}
              placeholder="Supervisor Name"
              className="w-full bg-neutral-50 border border-neutral-300 rounded-lg px-2.5 py-1.5 text-xs font-medium text-neutral-900 focus:bg-white focus:border-[#c92228] focus:ring-1 focus:ring-[#c92228] outline-hidden"
            />
          </div>
        </div>
      </div>

      {/* Summary Metrics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-white p-3.5 rounded-xl border border-neutral-200 shadow-2xs">
          <div className="flex items-center justify-between text-neutral-500 text-xs font-semibold">
            <span>Staff Count</span>
            <Users size={16} className="text-neutral-400" />
          </div>
          <div className="text-2xl font-black text-neutral-900 mt-1">
            {Math.max(bagRows.length, articleRows.length)}
          </div>
          <p className="text-[11px] text-neutral-500 mt-0.5">Staff on duty in abstract</p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-neutral-200 shadow-2xs">
          <div className="flex items-center justify-between text-neutral-500 text-xs font-semibold">
            <span>Total Bags Handled</span>
            <PackageCheck size={16} className="text-[#c92228]" />
          </div>
          <div className="text-2xl font-black text-[#c92228] mt-1 font-mono">
            {grandTotalBags}
          </div>
          <p className="text-[11px] text-neutral-500 mt-0.5">
            Recv: {totalBagsReceived} • Clsd: {totalBagsClosed} • Disp: {totalBagsDispatched}
          </p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-neutral-200 shadow-2xs">
          <div className="flex items-center justify-between text-neutral-500 text-xs font-semibold">
            <span>Total Articles Closed</span>
            <Mail size={16} className="text-blue-600" />
          </div>
          <div className="text-2xl font-black text-blue-700 mt-1 font-mono">
            {grandTotalArticlesClosed}
          </div>
          <p className="text-[11px] text-neutral-500 mt-0.5">
            Ordinary: {totalArticleClosed} • Insured: {totalInsuredArticleClosed}
          </p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-neutral-200 shadow-2xs">
          <div className="flex items-center justify-between text-neutral-500 text-xs font-semibold">
            <span>Data Source</span>
            <Sparkles size={16} className="text-amber-500" />
          </div>
          <div className="text-sm font-bold text-neutral-800 mt-2">
            Manual Operator Input
          </div>
          <p className="text-[11px] text-emerald-700 font-semibold mt-0.5 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            Independent of set queue
          </p>
        </div>
      </div>

      {/* TABLE 1: BAG DETAILS */}
      <div className="bg-white rounded-xl border border-neutral-200 shadow-xs overflow-hidden">
        {/* Table 1 Header */}
        <div className="px-5 py-3.5 bg-neutral-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-[#c92228] flex items-center justify-center text-white text-xs font-bold">
              1
            </div>
            <div>
              <h3 className="text-sm font-black uppercase tracking-wide flex items-center gap-2">
                <span>Table 1: Bag Details</span>
                <span className="text-[10px] font-normal text-neutral-400">
                  (5 Columns: Employee ID, Employee Name, Bag Received, Bag Closed, Bag Dispatched)
                </span>
              </h3>
            </div>
          </div>

          <button
            type="button"
            onClick={handleAddBagRow}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#c92228] hover:bg-[#a01217] text-white rounded-lg text-xs font-bold transition-colors cursor-pointer self-start sm:self-auto shadow-2xs"
          >
            <Plus size={14} />
            <span>Add Employee Row</span>
          </button>
        </div>

        {/* Table 1 Data Grid */}
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-neutral-100 text-neutral-700 font-bold uppercase tracking-wider text-[11px] border-b border-neutral-200">
              <tr>
                <th className="py-2.5 px-3 w-12 text-center">#</th>
                <th className="py-2.5 px-3 w-40">Employee ID</th>
                <th className="py-2.5 px-3 min-w-[180px]">Employee Name</th>
                <th className="py-2.5 px-3 w-36 text-center">Bag Received</th>
                <th className="py-2.5 px-3 w-36 text-center">Bag Closed</th>
                <th className="py-2.5 px-3 w-36 text-center">Bag Dispatched</th>
                <th className="py-2.5 px-3 w-16 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-200">
              {bagRows.map((row, idx) => (
                <tr key={row.id} className="hover:bg-neutral-50/80 transition-colors">
                  <td className="py-2 px-3 text-center font-mono text-neutral-500 text-xs">
                    {idx + 1}
                  </td>
                  <td className="py-1.5 px-3">
                    <input
                      type="text"
                      value={row.employeeId}
                      onChange={(e) => handleUpdateBagRow(row.id, 'employeeId', e.target.value)}
                      placeholder="e.g. 10048219"
                      className="w-full bg-white border border-neutral-300 rounded px-2 py-1 font-mono text-xs text-neutral-900 focus:border-[#c92228] focus:ring-1 focus:ring-[#c92228] outline-hidden"
                    />
                  </td>
                  <td className="py-1.5 px-3">
                    <input
                      type="text"
                      value={row.employeeName}
                      onChange={(e) => handleUpdateBagRow(row.id, 'employeeName', e.target.value)}
                      placeholder="Employee Full Name"
                      className="w-full bg-white border border-neutral-300 rounded px-2.5 py-1 text-xs text-neutral-900 focus:border-[#c92228] focus:ring-1 focus:ring-[#c92228] outline-hidden"
                    />
                  </td>
                  <td className="py-1.5 px-3">
                    <input
                      type="number"
                      min="0"
                      value={row.bagReceived}
                      onChange={(e) => handleUpdateBagRow(row.id, 'bagReceived', e.target.value)}
                      placeholder="0"
                      className="w-full bg-white border border-neutral-300 rounded px-2 py-1 text-center font-mono text-xs font-bold text-neutral-900 focus:border-[#c92228] focus:ring-1 focus:ring-[#c92228] outline-hidden"
                    />
                  </td>
                  <td className="py-1.5 px-3">
                    <input
                      type="number"
                      min="0"
                      value={row.bagClosed}
                      onChange={(e) => handleUpdateBagRow(row.id, 'bagClosed', e.target.value)}
                      placeholder="0"
                      className="w-full bg-white border border-neutral-300 rounded px-2 py-1 text-center font-mono text-xs font-bold text-neutral-900 focus:border-[#c92228] focus:ring-1 focus:ring-[#c92228] outline-hidden"
                    />
                  </td>
                  <td className="py-1.5 px-3">
                    <input
                      type="number"
                      min="0"
                      value={row.bagDispatched}
                      onChange={(e) => handleUpdateBagRow(row.id, 'bagDispatched', e.target.value)}
                      placeholder="0"
                      className="w-full bg-white border border-neutral-300 rounded px-2 py-1 text-center font-mono text-xs font-bold text-neutral-900 focus:border-[#c92228] focus:ring-1 focus:ring-[#c92228] outline-hidden"
                    />
                  </td>
                  <td className="py-1.5 px-3 text-center">
                    <button
                      type="button"
                      onClick={() => handleDeleteBagRow(row.id)}
                      className="p-1 text-neutral-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors cursor-pointer"
                      title="Delete row"
                    >
                      <Trash2 size={15} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
            {/* Table 1 Column Totals Footer */}
            <tfoot className="bg-neutral-100/90 font-bold border-t-2 border-neutral-300 text-neutral-900 text-xs">
              <tr>
                <td colSpan={3} className="py-2.5 px-3 text-right uppercase tracking-wider text-[11px] text-neutral-600">
                  Total Bags Handled:
                </td>
                <td className="py-2.5 px-3 text-center font-mono text-sm text-[#c92228] bg-red-50/50">
                  {totalBagsReceived}
                </td>
                <td className="py-2.5 px-3 text-center font-mono text-sm text-[#c92228] bg-red-50/50">
                  {totalBagsClosed}
                </td>
                <td className="py-2.5 px-3 text-center font-mono text-sm text-[#c92228] bg-red-50/50">
                  {totalBagsDispatched}
                </td>
                <td className="py-2.5 px-3 text-center text-neutral-400">—</td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* TABLE 2: ARTICLE DETAILS */}
      <div className="bg-white rounded-xl border border-neutral-200 shadow-xs overflow-hidden">
        {/* Table 2 Header */}
        <div className="px-5 py-3.5 bg-neutral-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-blue-600 flex items-center justify-center text-white text-xs font-bold">
              2
            </div>
            <div>
              <h3 className="text-sm font-black uppercase tracking-wide flex items-center gap-2">
                <span>Table 2: Article Details</span>
                <span className="text-[10px] font-normal text-neutral-400">
                  (5 Columns: Employee ID, Employee Name, Article Closed, Insured Article Closed, Total Article Closed)
                </span>
              </h3>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
            <button
              type="button"
              onClick={handleCopyEmployeesFromTable1}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 hover:text-white rounded-lg text-xs font-semibold border border-neutral-700 transition-colors cursor-pointer shadow-2xs"
              title="Copy employee IDs and names from Table 1 into Table 2"
            >
              <Copy size={13} />
              <span>Copy Staff from Table 1</span>
            </button>

            <button
              type="button"
              onClick={handleAddArticleRow}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer shadow-2xs"
            >
              <Plus size={14} />
              <span>Add Employee Row</span>
            </button>
          </div>
        </div>

        {/* Table 2 Data Grid */}
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-neutral-100 text-neutral-700 font-bold uppercase tracking-wider text-[11px] border-b border-neutral-200">
              <tr>
                <th className="py-2.5 px-3 w-12 text-center">#</th>
                <th className="py-2.5 px-3 w-40">Employee ID</th>
                <th className="py-2.5 px-3 min-w-[180px]">Employee Name</th>
                <th className="py-2.5 px-3 w-36 text-center">Article Closed</th>
                <th className="py-2.5 px-3 w-44 text-center">Insured Article Closed</th>
                <th className="py-2.5 px-3 w-40 text-center bg-blue-50/80 text-blue-950">Total Article Closed</th>
                <th className="py-2.5 px-3 w-16 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-200">
              {articleRows.map((row, idx) => (
                <tr key={row.id} className="hover:bg-neutral-50/80 transition-colors">
                  <td className="py-2 px-3 text-center font-mono text-neutral-500 text-xs">
                    {idx + 1}
                  </td>
                  <td className="py-1.5 px-3">
                    <input
                      type="text"
                      value={row.employeeId}
                      onChange={(e) => handleUpdateArticleRow(row.id, 'employeeId', e.target.value)}
                      placeholder="e.g. 10048219"
                      className="w-full bg-white border border-neutral-300 rounded px-2 py-1 font-mono text-xs text-neutral-900 focus:border-blue-600 focus:ring-1 focus:ring-blue-600 outline-hidden"
                    />
                  </td>
                  <td className="py-1.5 px-3">
                    <input
                      type="text"
                      value={row.employeeName}
                      onChange={(e) => handleUpdateArticleRow(row.id, 'employeeName', e.target.value)}
                      placeholder="Employee Full Name"
                      className="w-full bg-white border border-neutral-300 rounded px-2.5 py-1 text-xs text-neutral-900 focus:border-blue-600 focus:ring-1 focus:ring-blue-600 outline-hidden"
                    />
                  </td>
                  <td className="py-1.5 px-3">
                    <input
                      type="number"
                      min="0"
                      value={row.articleClosed}
                      onChange={(e) => handleUpdateArticleRow(row.id, 'articleClosed', e.target.value)}
                      placeholder="0"
                      className="w-full bg-white border border-neutral-300 rounded px-2 py-1 text-center font-mono text-xs font-bold text-neutral-900 focus:border-blue-600 focus:ring-1 focus:ring-blue-600 outline-hidden"
                    />
                  </td>
                  <td className="py-1.5 px-3">
                    <input
                      type="number"
                      min="0"
                      value={row.insuredArticleClosed}
                      onChange={(e) => handleUpdateArticleRow(row.id, 'insuredArticleClosed', e.target.value)}
                      placeholder="0"
                      className="w-full bg-white border border-neutral-300 rounded px-2 py-1 text-center font-mono text-xs font-bold text-neutral-900 focus:border-blue-600 focus:ring-1 focus:ring-blue-600 outline-hidden"
                    />
                  </td>
                  <td className="py-1.5 px-3 bg-blue-50/40">
                    <input
                      type="number"
                      min="0"
                      value={row.totalArticleClosed}
                      onChange={(e) => handleUpdateArticleRow(row.id, 'totalArticleClosed', e.target.value)}
                      placeholder="0"
                      className="w-full bg-white border border-blue-300 rounded px-2 py-1 text-center font-mono text-xs font-black text-blue-900 focus:border-blue-600 focus:ring-1 focus:ring-blue-600 outline-hidden"
                      title="Auto-summed from Article Closed + Insured Article Closed, or manually editable"
                    />
                  </td>
                  <td className="py-1.5 px-3 text-center">
                    <button
                      type="button"
                      onClick={() => handleDeleteArticleRow(row.id)}
                      className="p-1 text-neutral-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors cursor-pointer"
                      title="Delete row"
                    >
                      <Trash2 size={15} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
            {/* Table 2 Column Totals Footer */}
            <tfoot className="bg-neutral-100/90 font-bold border-t-2 border-neutral-300 text-neutral-900 text-xs">
              <tr>
                <td colSpan={3} className="py-2.5 px-3 text-right uppercase tracking-wider text-[11px] text-neutral-600">
                  Total Articles Closed:
                </td>
                <td className="py-2.5 px-3 text-center font-mono text-sm text-blue-700 bg-blue-50/50">
                  {totalArticleClosed}
                </td>
                <td className="py-2.5 px-3 text-center font-mono text-sm text-blue-700 bg-blue-50/50">
                  {totalInsuredArticleClosed}
                </td>
                <td className="py-2.5 px-3 text-center font-mono text-base font-black text-blue-800 bg-blue-100/60">
                  {grandTotalArticlesClosed}
                </td>
                <td className="py-2.5 px-3 text-center text-neutral-400">—</td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* Optional Supervisor Remarks */}
      <div className="bg-white rounded-xl border border-neutral-200 p-4 shadow-2xs space-y-2">
        <label className="block text-xs font-bold text-neutral-700">
          Operational Notes & Handover Remarks (Optional)
        </label>
        <textarea
          rows={2}
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Enter any shift handover remarks, irregularity notes, or verification comments..."
          className="w-full bg-neutral-50 border border-neutral-300 rounded-lg p-2.5 text-xs text-neutral-900 focus:bg-white focus:border-[#c92228] focus:ring-1 focus:ring-[#c92228] outline-hidden resize-none"
        />
      </div>

      {/* HIDDEN PRINTABLE VIEW (Used by printIsolatedElement) */}
      <div id="printable-manual-consolidated-abstract" className="hidden print:block bg-white text-black p-6 font-serif">
        <div className="text-center border-b-2 border-black pb-3 mb-4">
          <h1 className="text-lg font-bold uppercase tracking-wider">DEPARTMENT OF POSTS, INDIA</h1>
          <h2 className="text-base font-semibold uppercase tracking-wide mt-0.5">
            CONSOLIDATED ABSTRACT OF BAGS & ARTICLES (MANUAL ENTRY)
          </h2>
          <div className="text-xs mt-2 flex justify-between px-4">
            <span><strong>Office:</strong> {officeName}</span>
            <span><strong>Set:</strong> {setName}</span>
            <span><strong>Date:</strong> {formatIndianDate(abstractDate)}</span>
            <span><strong>Supervisor:</strong> {supervisorName}</span>
          </div>
        </div>

        {/* Table 1 Print */}
        <div className="mb-6">
          <h3 className="text-xs font-bold uppercase mb-1 border-b border-black pb-0.5">
            1. BAG DETAILS (EMPLOYEE-WISE)
          </h3>
          <table className="w-full text-xs border-collapse border border-black mb-3">
            <thead>
              <tr className="bg-neutral-200">
                <th className="border border-black p-1 text-center w-8">#</th>
                <th className="border border-black p-1 text-left">Employee ID</th>
                <th className="border border-black p-1 text-left">Employee Name</th>
                <th className="border border-black p-1 text-center">Bag Received</th>
                <th className="border border-black p-1 text-center">Bag Closed</th>
                <th className="border border-black p-1 text-center">Bag Dispatched</th>
              </tr>
            </thead>
            <tbody>
              {bagRows.map((r, i) => (
                <tr key={r.id}>
                  <td className="border border-black p-1 text-center">{i + 1}</td>
                  <td className="border border-black p-1 font-mono">{r.employeeId || '—'}</td>
                  <td className="border border-black p-1">{r.employeeName || '—'}</td>
                  <td className="border border-black p-1 text-center font-mono">{r.bagReceived === '' ? 0 : r.bagReceived}</td>
                  <td className="border border-black p-1 text-center font-mono">{r.bagClosed === '' ? 0 : r.bagClosed}</td>
                  <td className="border border-black p-1 text-center font-mono">{r.bagDispatched === '' ? 0 : r.bagDispatched}</td>
                </tr>
              ))}
              <tr className="font-bold bg-neutral-100">
                <td colSpan={3} className="border border-black p-1 text-right">TOTAL:</td>
                <td className="border border-black p-1 text-center font-mono">{totalBagsReceived}</td>
                <td className="border border-black p-1 text-center font-mono">{totalBagsClosed}</td>
                <td className="border border-black p-1 text-center font-mono">{totalBagsDispatched}</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Table 2 Print */}
        <div className="mb-6">
          <h3 className="text-xs font-bold uppercase mb-1 border-b border-black pb-0.5">
            2. ARTICLE DETAILS (EMPLOYEE-WISE)
          </h3>
          <table className="w-full text-xs border-collapse border border-black mb-3">
            <thead>
              <tr className="bg-neutral-200">
                <th className="border border-black p-1 text-center w-8">#</th>
                <th className="border border-black p-1 text-left">Employee ID</th>
                <th className="border border-black p-1 text-left">Employee Name</th>
                <th className="border border-black p-1 text-center">Article Closed</th>
                <th className="border border-black p-1 text-center">Insured Article Closed</th>
                <th className="border border-black p-1 text-center">Total Article Closed</th>
              </tr>
            </thead>
            <tbody>
              {articleRows.map((r, i) => (
                <tr key={r.id}>
                  <td className="border border-black p-1 text-center">{i + 1}</td>
                  <td className="border border-black p-1 font-mono">{r.employeeId || '—'}</td>
                  <td className="border border-black p-1">{r.employeeName || '—'}</td>
                  <td className="border border-black p-1 text-center font-mono">{r.articleClosed === '' ? 0 : r.articleClosed}</td>
                  <td className="border border-black p-1 text-center font-mono">{r.insuredArticleClosed === '' ? 0 : r.insuredArticleClosed}</td>
                  <td className="border border-black p-1 text-center font-mono font-bold">{r.totalArticleClosed === '' ? 0 : r.totalArticleClosed}</td>
                </tr>
              ))}
              <tr className="font-bold bg-neutral-100">
                <td colSpan={3} className="border border-black p-1 text-right">TOTAL:</td>
                <td className="border border-black p-1 text-center font-mono">{totalArticleClosed}</td>
                <td className="border border-black p-1 text-center font-mono">{totalInsuredArticleClosed}</td>
                <td className="border border-black p-1 text-center font-mono">{grandTotalArticlesClosed}</td>
              </tr>
            </tbody>
          </table>
        </div>

        {notes && (
          <div className="mb-6 text-xs">
            <strong>Notes / Handover Remarks:</strong>
            <p className="border border-black p-2 mt-1 italic">{notes}</p>
          </div>
        )}

        {/* Signatures */}
        <div className="flex justify-between items-end pt-12 text-xs">
          <div className="text-center">
            <div className="border-t border-black w-40 pt-1">Duty Head Sorting Assistant</div>
          </div>
          <div className="text-center">
            <div className="border-t border-black w-40 pt-1">Supervisor / Postmaster</div>
          </div>
        </div>
      </div>
    </div>
  );
};
