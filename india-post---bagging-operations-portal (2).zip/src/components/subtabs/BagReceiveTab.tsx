import React, { useState, useEffect, useRef } from 'react';
import { BagRecord, UserSession, ActionSuccessDetails } from '../../types';
import { OfficeAutocomplete } from '../OfficeAutocomplete';
import { OfficeDirectoryModal } from '../OfficeDirectoryModal';
import { validateBagBarcode } from '../../utils/barcode';
import { Barcode, CheckCircle2, AlertCircle, PlusCircle, Inbox, Trash2, Layers, Building2 } from 'lucide-react';

interface BagReceiveTabProps {
  session: UserSession;
  bags: BagRecord[];
  onReceiveBag: (newBag: BagRecord) => void;
  onDeleteBag?: (bagId: string) => void;
  onActionSuccess?: (details: ActionSuccessDetails) => void;
}

export const BagReceiveTab: React.FC<BagReceiveTabProps> = ({
  session,
  bags,
  onReceiveBag,
  onDeleteBag,
  onActionSuccess,
}) => {
  const [bagBarcode, setBagBarcode] = useState('');
  const [sourceOffice, setSourceOffice] = useState('Indore GPO');
  const [bagStatus, setBagStatus] = useState<'received for open'>('received for open');
  const [speedCount, setSpeedCount] = useState<number>(0);
  const [insuredCount, setInsuredCount] = useState<number>(0);
  const [weightKg, setWeightKg] = useState<string>('2.500');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [isDirModalOpen, setIsDirModalOpen] = useState(false);
  const barcodeInputRef = useRef<HTMLInputElement | null>(null);

  // Auto calculate total article count
  const totalArticleCount = (Number(speedCount) || 0) + (Number(insuredCount) || 0);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const barcodeClean = bagBarcode.trim().toUpperCase();
    if (!barcodeClean) {
      setErrorMsg('Please scan or enter a 13-character bag barcode.');
      return;
    }

    // Format validation
    const validation = validateBagBarcode(barcodeClean);
    if (!validation.isValid) {
      setErrorMsg(validation.error || 'Invalid 13-character bag barcode.');
      return;
    }

    // Duplicate Check across all bagging operations
    const duplicate = bags.find(
      (b) => b.bagBarcode.toUpperCase() === barcodeClean
    );
    if (duplicate) {
      setErrorMsg(`DUPLICATE ENTRY! Bag ${barcodeClean} has already been registered in the system.`);
      return;
    }

    if (!sourceOffice.trim()) {
      setErrorMsg('Please enter or select a source office.');
      return;
    }

    const newBag: BagRecord = {
      id: `bag-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      bagBarcode: barcodeClean,
      sourceOffice: sourceOffice.trim(),
      destinationOffice: session.officeName,
      bagStatus: 'received for open',
      speedPostCount: Number(speedCount) || 0,
      insuredCount: Number(insuredCount) || 0,
      totalArticlesCount: totalArticleCount,
      setName: session.setName,
      officeName: session.officeName,
      receivedAt: new Date().toLocaleString('en-IN'),
      bagWeightKg: parseFloat(weightKg) || 2.5,
      articles: [],
    };

    onReceiveBag(newBag);
    setSuccessMsg(`Bag ${barcodeClean} successfully received for opening! Total Articles: ${totalArticleCount}`);

    // Trigger Success Action Popup
    if (onActionSuccess) {
      onActionSuccess({
        title: 'Bag Received Successfully',
        subtitle: `Queued for opening at ${session.officeName}`,
        badge: 'BAG RECEIVED',
        barcode: barcodeClean,
        actionType: 'receive',
        bag: newBag,
        details: [
          { label: 'Source Office', value: sourceOffice.trim() },
          { label: 'Total Articles', value: totalArticleCount },
          { label: 'Speed/Regd Articles', value: Number(speedCount) || 0 },
          { label: 'Insured Articles', value: Number(insuredCount) || 0 },
          { label: 'Bag Weight', value: `${newBag.bagWeightKg?.toFixed(3)} KG` },
          { label: 'Receiving Set', value: session.setName },
          { label: 'Received At', value: newBag.receivedAt || new Date().toLocaleString('en-IN') },
        ],
      });
    }

    setBagBarcode('');
    setSpeedCount(0);
    setInsuredCount(0);

    if (barcodeInputRef.current) {
      barcodeInputRef.current.focus();
    }
  };

  // Keyboard shortcut for Receive Bag (Alt + R)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.altKey && (e.key === 'r' || e.key === 'R')) {
        e.preventDefault();
        handleSubmit();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [bagBarcode, sourceOffice, speedCount, insuredCount, weightKg, bags]);

  // Sample quick barcode filler for testing
  const handleFillSample = () => {
    const randomDigits = Math.floor(1000000000 + Math.random() * 9000000000);
    setBagBarcode(`EBI${randomDigits}`);
  };

  const receivedForOpenBags = bags.filter((b) => b.bagStatus === 'received for open');

  return (
    <div className="space-y-6">
      {/* Sub tab Title & Description */}
      <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-neutral-900 flex items-center gap-2">
            <Inbox className="text-[#c92228]" size={22} />
            <span>Sub Tab 1: Bag Receive</span>
            <span
              className="text-[11px] font-mono bg-neutral-100 text-neutral-600 px-2 py-0.5 rounded border border-neutral-200"
              title="Shortcut key for this tab: Alt + 1"
            >
              Alt+1
            </span>
          </h2>
          <p className="text-xs text-neutral-500 mt-0.5">
            Receive incoming bags for opening at {session.officeName} ({session.setName})
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setIsDirModalOpen(true)}
            className="px-3 py-1.5 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer border border-neutral-300"
            title="Manage and update source office names and PIN codes"
          >
            <Building2 size={14} className="text-[#c92228]" />
            <span>Office & PIN Directory</span>
          </button>
          <span className="text-xs font-semibold bg-red-50 text-[#c92228] px-3 py-1.5 rounded-full border border-red-200">
            Total Received: {receivedForOpenBags.length} Bags
          </span>
        </div>
      </div>

      {/* Alerts */}
      {errorMsg && (
        <div className="p-3.5 bg-red-50 border-l-4 border-red-600 rounded-r-lg flex items-center gap-3 text-red-800 text-xs font-semibold animate-shake">
          <AlertCircle size={18} className="shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {successMsg && (
        <div className="p-3.5 bg-emerald-50 border-l-4 border-emerald-600 rounded-r-lg flex items-center gap-3 text-emerald-800 text-xs font-semibold">
          <CheckCircle2 size={18} className="shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Main Receiving Form */}
      <form onSubmit={handleSubmit} className="bg-white p-6 rounded-xl border border-neutral-200 shadow-xs space-y-5">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Barcode Scan Box */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider">
                Barcode (Bag Label) Scan Box *
              </label>
              <button
                type="button"
                onClick={handleFillSample}
                className="text-[11px] font-semibold text-[#c92228] hover:underline"
              >
                + Generate Sample
              </button>
            </div>
            <div className="relative">
              <input
                ref={barcodeInputRef}
                type="text"
                value={bagBarcode}
                maxLength={13}
                onChange={(e) => setBagBarcode(e.target.value.toUpperCase())}
                placeholder="Scan or enter 13-char bag code (e.g. EBI0123456789)"
                className="w-full pl-9 pr-4 py-2.5 bg-neutral-50 border-2 border-neutral-300 focus:border-[#c92228] rounded-lg text-sm font-mono font-bold uppercase text-neutral-900 focus:outline-hidden"
                autoFocus
              />
              <Barcode size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
            </div>
            <p className="text-[10px] text-neutral-500 mt-1">
              Must be exactly 13 characters (first 3 letters e.g. EBI, EBX, CBI, LBI + 10 digits).
            </p>
          </div>

          {/* Source Office with Suggestions */}
          <div>
            <OfficeAutocomplete
              id="receive-source-office"
              label="Source Office (Editable & Searchable) *"
              value={sourceOffice}
              onChange={setSourceOffice}
              placeholder="Search Sub Post Office, Head Office, GPO, NSH, PH..."
              required
            />
          </div>
        </div>

        {/* Counts & Status Row */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 pt-2">
          {/* Bag Status */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
              Bag Status (Default)
            </label>
            <input
              type="text"
              readOnly
              value={bagStatus}
              className="w-full px-3 py-2.5 bg-neutral-100 border border-neutral-300 rounded-lg text-xs font-bold text-neutral-800 cursor-not-allowed"
            />
          </div>

          {/* Speed Post / Registered Count */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
              Speed / Regd Article Count
            </label>
            <input
              type="number"
              min={0}
              value={speedCount}
              onChange={(e) => setSpeedCount(Math.max(0, parseInt(e.target.value) || 0))}
              className="w-full px-3 py-2.5 bg-neutral-50 border border-neutral-300 rounded-lg text-sm font-bold text-neutral-900 focus:ring-2 focus:ring-[#c92228] focus:outline-hidden"
            />
          </div>

          {/* Insured Article Count */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
              Insured Article Count
            </label>
            <input
              type="number"
              min={0}
              value={insuredCount}
              onChange={(e) => setInsuredCount(Math.max(0, parseInt(e.target.value) || 0))}
              className="w-full px-3 py-2.5 bg-neutral-50 border border-neutral-300 rounded-lg text-sm font-bold text-amber-700 focus:ring-2 focus:ring-[#c92228] focus:outline-hidden"
            />
          </div>

          {/* Total Article Count (Auto Calculated) */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
              Total Article Count (Auto Sum)
            </label>
            <div className="w-full px-3 py-2.5 bg-amber-50/70 border-2 border-amber-300 rounded-lg text-sm font-black text-amber-900 flex items-center justify-between">
              <span>{totalArticleCount}</span>
              <span className="text-[10px] uppercase font-bold text-amber-600">Calculated</span>
            </div>
          </div>
        </div>

        {/* Submit Action */}
        <div className="flex items-center justify-between pt-4 border-t border-neutral-200">
          <div className="flex items-center gap-2 text-xs text-neutral-500">
            <Layers size={15} />
            <span>Target Duty Set: <strong className="text-neutral-800">{session.setName}</strong></span>
          </div>
          <button
            type="submit"
            className="px-6 py-2.5 bg-[#c92228] hover:bg-[#a01217] text-white font-bold rounded-lg shadow-sm text-sm uppercase tracking-wide flex items-center gap-2 cursor-pointer transition-colors"
            title="Receive Bag (Shortcut: Alt + R)"
          >
            <PlusCircle size={17} />
            <span>Receive Bag</span>
            <kbd className="ml-1.5 px-1.5 py-0.5 rounded bg-red-900/60 text-white text-[10px] font-mono tracking-normal">
              Alt+R
            </kbd>
          </button>
        </div>
      </form>

      {/* Received Bags Table */}
      <div className="bg-white rounded-xl border border-neutral-200 shadow-xs overflow-hidden">
        <div className="px-5 py-4 border-b border-neutral-200 flex items-center justify-between bg-neutral-50">
          <div>
            <h3 className="font-bold text-neutral-800 text-sm">
              Current Session Received Bags ({receivedForOpenBags.length})
            </h3>
            <p className="text-xs text-neutral-500">
              Bags queued for opening in {session.officeName}
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-neutral-100 text-neutral-700 font-bold border-b border-neutral-200 uppercase tracking-wider">
              <tr>
                <th className="py-3 px-4">Bag Barcode (13-Char)</th>
                <th className="py-3 px-4">Source Office</th>
                <th className="py-3 px-4 text-center">Speed Count</th>
                <th className="py-3 px-4 text-center">Insured Count</th>
                <th className="py-3 px-4 text-center">Total Articles</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Received Time</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-200">
              {receivedForOpenBags.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-neutral-500 italic">
                    No bags received for opening yet. Use the scan box above to receive incoming bags.
                  </td>
                </tr>
              ) : (
                receivedForOpenBags.map((bag) => (
                  <tr key={bag.id} className="hover:bg-neutral-50">
                    <td className="py-3 px-4 font-mono font-bold text-neutral-900">
                      {bag.bagBarcode}
                    </td>
                    <td className="py-3 px-4 font-medium text-neutral-800">
                      {bag.sourceOffice}
                    </td>
                    <td className="py-3 px-4 text-center font-semibold">
                      {bag.speedPostCount}
                    </td>
                    <td className="py-3 px-4 text-center font-bold text-amber-700">
                      {bag.insuredCount}
                    </td>
                    <td className="py-3 px-4 text-center font-black text-neutral-900">
                      {bag.totalArticlesCount}
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 uppercase">
                        {bag.bagStatus}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-neutral-500 font-mono text-[11px]">
                      {bag.receivedAt || '—'}
                    </td>
                    <td className="py-3 px-4 text-right">
                      {onDeleteBag && (
                        <button
                          onClick={() => onDeleteBag(bag.id)}
                          title="Remove entry"
                          className="p-1 text-neutral-400 hover:text-red-600 rounded"
                        >
                          <Trash2 size={15} />
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Office & PIN Directory Manager Modal */}
      <OfficeDirectoryModal
        isOpen={isDirModalOpen}
        onClose={() => setIsDirModalOpen(false)}
        selectedOffice={sourceOffice}
        onSelectOffice={(officeName) => {
          setSourceOffice(officeName);
          setIsDirModalOpen(false);
        }}
      />
    </div>
  );
};
