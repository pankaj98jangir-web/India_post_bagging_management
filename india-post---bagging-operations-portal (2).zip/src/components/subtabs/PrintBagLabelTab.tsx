import React, { useState, useEffect, useRef } from 'react';
import { BagRecord, UserSession } from '../../types';
import { PrintableBagLabel } from '../PrintableBagLabel';
import { Tag, Barcode, Search, AlertCircle, CheckCircle2 } from 'lucide-react';

interface PrintBagLabelTabProps {
  session: UserSession;
  bags: BagRecord[];
}

export const PrintBagLabelTab: React.FC<PrintBagLabelTabProps> = ({ session, bags }) => {
  const [bagBarcode, setBagBarcode] = useState('');
  const [selectedBag, setSelectedBag] = useState<BagRecord | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  const handleFetch = (barcodeToLookup?: string) => {
    setErrorMsg(null);
    setSuccessMsg(null);
    const code = (barcodeToLookup || bagBarcode).trim().toUpperCase();

    if (!code) {
      setErrorMsg('Please enter or scan a bag barcode.');
      return;
    }

    const found = bags.find((b) => b.bagBarcode.toUpperCase() === code);
    if (!found) {
      setErrorMsg(`No bag found with barcode "${code}". Make sure the bag exists in the system.`);
      setSelectedBag(null);
      return;
    }

    setSelectedBag(found);
    setSuccessMsg(`Fetched Label for Bag: ${found.bagBarcode} (${found.destinationOffice})`);
  };

  // Auto trigger fetch when scanner inputs 13 characters or matches any bag
  const handleInputChange = (val: string) => {
    const uppercaseVal = val.toUpperCase();
    setBagBarcode(uppercaseVal);
    setErrorMsg(null);

    // Auto-fetch immediately without manual clicking!
    if (uppercaseVal.length === 13) {
      setTimeout(() => {
        handleFetch(uppercaseVal);
      }, 30);
    } else {
      const match = bags.find((b) => b.bagBarcode.toUpperCase() === uppercaseVal);
      if (match && uppercaseVal.length >= 8) {
        setTimeout(() => {
          handleFetch(uppercaseVal);
        }, 30);
      }
    }
  };

  useEffect(() => {
    if (!selectedBag) {
      const closedOrDeposit = bags.filter((b) => b.bagStatus === 'closed' || b.isDepositBag);
      if (closedOrDeposit.length > 0) {
        const latest = closedOrDeposit[closedOrDeposit.length - 1];
        setBagBarcode(latest.bagBarcode);
        setSelectedBag(latest);
      }
    }
  }, [bags]);

  const closedOrAllBags = bags.filter((b) => b.bagStatus === 'closed' || b.isDepositBag || b.bagBarcode);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-neutral-900 flex items-center gap-2">
            <Tag className="text-[#c92228]" size={22} />
            <span>Sub Tab 6: Print Bag Label</span>
            <span
              className="text-[11px] font-mono bg-neutral-100 text-neutral-600 px-2 py-0.5 rounded border border-neutral-200"
              title="Shortcut key for this tab: Alt + 6"
            >
              Alt+6
            </span>
          </h2>
          <p className="text-xs text-neutral-500 mt-0.5">
            Auto-fetches official 120mm × 70mm scannable bag label upon scanning without clicking any button
          </p>
        </div>
        <span className="text-xs font-bold text-neutral-700 bg-neutral-100 border border-neutral-300 px-3 py-1.5 rounded-lg font-mono">
          Label Size: 120mm × 70mm
        </span>
      </div>

      {errorMsg && (
        <div className="p-3.5 bg-red-50 border-l-4 border-red-600 rounded-r-lg flex items-center gap-3 text-red-800 text-xs font-semibold animate-in fade-in duration-100">
          <AlertCircle size={18} className="shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {successMsg && (
        <div className="p-3.5 bg-emerald-50 border-l-4 border-emerald-600 rounded-r-lg flex items-center gap-3 text-emerald-800 text-xs font-semibold animate-in fade-in duration-100">
          <CheckCircle2 size={18} className="shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Barcode Scan Box & Auto-Fetch Bar */}
      <div className="bg-white p-6 rounded-xl border border-neutral-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider">
            Barcode Scan Box (Auto-Fetches Instantly) *
          </label>
          <span className="text-[10px] text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
            ⚡ Hands-Free Auto-Fetch Active
          </span>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <input
              ref={inputRef}
              type="text"
              value={bagBarcode}
              maxLength={13}
              onChange={(e) => handleInputChange(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleFetch();
                }
              }}
              placeholder="Scan bag barcode with scanner (Auto-fetches on scan)..."
              className="w-full pl-9 pr-4 py-3 bg-neutral-50 border-2 border-neutral-300 focus:border-[#c92228] rounded-lg text-sm font-mono font-bold uppercase text-neutral-900 focus:outline-hidden"
              title="Scan bag barcode (Auto-fetches on 13 characters or Enter)"
              autoFocus
            />
            <Barcode size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
          </div>

          <button
            type="button"
            onClick={() => handleFetch()}
            className="px-6 py-3 bg-[#c92228] hover:bg-[#a01217] text-white font-bold rounded-lg text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer transition-colors shadow-xs"
            title="Fetch Bag Label"
          >
            <Search size={16} />
            <span>Fetch Bag Label</span>
          </button>
        </div>

        {/* Quick Pick Pills */}
        {closedOrAllBags.length > 0 && (
          <div className="pt-2 border-t border-neutral-100 flex items-center gap-2 flex-wrap">
            <span className="text-[11px] font-bold text-neutral-500 uppercase">Quick Pick Bag:</span>
            {closedOrAllBags.slice(-6).reverse().map((b) => (
              <button
                key={b.id}
                type="button"
                onClick={() => {
                  setBagBarcode(b.bagBarcode);
                  handleFetch(b.bagBarcode);
                }}
                className={`px-2.5 py-1 rounded text-xs font-mono font-bold border transition-colors cursor-pointer ${
                  selectedBag?.bagBarcode === b.bagBarcode
                    ? 'bg-[#c92228] text-white border-[#c92228]'
                    : 'bg-neutral-50 text-neutral-800 border-neutral-200 hover:bg-neutral-100'
                }`}
                title={`Fetch label for ${b.bagBarcode}`}
              >
                {b.bagBarcode} ({b.destinationOffice})
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Bag Label Display */}
      {selectedBag ? (
        <div className="bg-white p-8 rounded-xl border border-neutral-200 shadow-xs flex flex-col items-center">
          <PrintableBagLabel bag={selectedBag} isModal={false} />
        </div>
      ) : (
        <div className="bg-white p-12 rounded-xl border border-dashed border-neutral-300 text-center text-neutral-400 text-xs">
          Point your barcode scanner at a bag barcode to auto-fetch and print its official Department of Posts Bag Label.
        </div>
      )}
    </div>
  );
};
