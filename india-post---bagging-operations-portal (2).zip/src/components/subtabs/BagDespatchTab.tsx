import React, { useState, useEffect, useMemo } from 'react';
import {
  BagRecord,
  DespatchRecord,
  DespatchSchedule,
  UserSession,
  ActionSuccessDetails,
  FinalDestinationBifurcation,
} from '../../types';
import { OfficeAutocomplete } from '../OfficeAutocomplete';
import { DespatchScheduleModal } from '../DespatchScheduleModal';
import { PrintableBifurcatedMailList } from '../PrintableBifurcatedMailList';
import {
  getStoredSchedules,
  SCHEDULES_UPDATE_EVENT,
} from '../../utils/despatchScheduleStorage';
import {
  Truck,
  Barcode,
  Plus,
  Trash2,
  CheckCircle2,
  AlertCircle,
  Printer,
  Layers,
  Calendar,
  Clock,
  Building2,
  Edit2,
  Check,
  ChevronDown,
  Sparkles,
  RotateCcw,
  FileText,
} from 'lucide-react';

interface BagDespatchTabProps {
  session: UserSession;
  bags: BagRecord[];
  onDespatchBags: (despatch: DespatchRecord, bagIds: string[]) => void;
  onActionSuccess?: (details: ActionSuccessDetails) => void;
}

export const BagDespatchTab: React.FC<BagDespatchTabProps> = ({
  session,
  bags,
  onDespatchBags,
  onActionSuccess,
}) => {
  // Schedules State
  const [schedules, setSchedules] = useState<DespatchSchedule[]>(getStoredSchedules());
  const [selectedScheduleId, setSelectedScheduleId] = useState<string>(() => {
    const list = getStoredSchedules();
    return list[0]?.id || 'sch-bpl-01';
  });

  // Modal states for schedule management & mail list printing
  const [isScheduleModalOpen, setIsScheduleModalOpen] = useState(false);
  const [scheduleModalMode, setScheduleModalMode] = useState<'list' | 'add'>('list');
  const [scheduleToEdit, setScheduleToEdit] = useState<DespatchSchedule | null>(null);
  const [showPrintModal, setShowPrintModal] = useState(false);

  // Active Schedule helper
  const activeSchedule = useMemo(() => {
    return schedules.find((s) => s.id === selectedScheduleId) || schedules[0];
  }, [schedules, selectedScheduleId]);

  // Destination & Final Destination states
  const [destinationOffice, setDestinationOffice] = useState<string>('Bhopal NSH');
  const [selectedFinalDestination, setSelectedFinalDestination] = useState<string>('Bhopal GPO (462001)');
  const [customFinalDestInput, setCustomFinalDestInput] = useState<string>('');

  // Scanning & Queue
  const [bagBarcode, setBagBarcode] = useState('');
  const [scannedBags, setScannedBags] = useState<BagRecord[]>([]);

  // Feedback & History
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [lastDespatch, setLastDespatch] = useState<DespatchRecord | null>(null);

  // Listen for schedule storage updates
  useEffect(() => {
    const handleSchedulesUpdated = () => {
      const updatedList = getStoredSchedules();
      setSchedules(updatedList);
    };
    window.addEventListener(SCHEDULES_UPDATE_EVENT, handleSchedulesUpdated);
    return () => window.removeEventListener(SCHEDULES_UPDATE_EVENT, handleSchedulesUpdated);
  }, []);

  // Sync Destination Office & default Final Destination whenever active schedule changes
  useEffect(() => {
    if (activeSchedule) {
      setDestinationOffice(activeSchedule.destinationOffice);
      if (activeSchedule.finalDestinationOffices && activeSchedule.finalDestinationOffices.length > 0) {
        setSelectedFinalDestination(activeSchedule.finalDestinationOffices[0]);
      } else {
        setSelectedFinalDestination(activeSchedule.destinationOffice);
      }
    }
  }, [activeSchedule]);

  // Scan or add bag into the despatch queue
  const handleAddBagToDespatch = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const code = bagBarcode.trim().toUpperCase();
    if (!code) {
      setErrorMsg('Please enter or scan a 13-character bag barcode to despatch.');
      return;
    }

    if (scannedBags.some((b) => b.bagBarcode.toUpperCase() === code)) {
      setErrorMsg(`DUPLICATE ENTRY! Bag ${code} is already in this despatch queue.`);
      return;
    }

    const foundBag = bags.find((b) => b.bagBarcode.toUpperCase() === code);
    if (!foundBag) {
      setErrorMsg(`Bag ${code} was not found in registered closed or forwarding bags.`);
      return;
    }

    if (foundBag.bagStatus === 'despatched') {
      setErrorMsg(`Bag ${code} has already been marked as DESPATCHED.`);
      return;
    }

    // Determine final destination for this bag:
    // If bag has a destination office matching one of the schedule's final destinations, preserve it;
    // otherwise use selectedFinalDestination or custom
    const finalDestToAssign =
      customFinalDestInput.trim() ||
      selectedFinalDestination ||
      (activeSchedule?.finalDestinationOffices?.find((fd) =>
        foundBag.destinationOffice.toLowerCase().includes(fd.toLowerCase().split(' ')[0])
      ) ?? activeSchedule?.finalDestinationOffices?.[0]) ||
      destinationOffice;

    const queuedBag: BagRecord = {
      ...foundBag,
      destinationOffice: destinationOffice.trim() || activeSchedule.destinationOffice,
      finalDestinationOffice: finalDestToAssign,
      despatchScheduleId: activeSchedule.id,
    };

    setScannedBags((prev) => [queuedBag, ...prev]);
    setBagBarcode('');
    setCustomFinalDestInput('');
    setSuccessMsg(`Bag ${code} queued under Final Destination "${finalDestToAssign}".`);
  };

  // Change final destination office of an existing bag in the queue
  const handleUpdateBagFinalDestination = (bagId: string, newFinalDest: string) => {
    setScannedBags((prev) =>
      prev.map((b) => (b.id === bagId ? { ...b, finalDestinationOffice: newFinalDest } : b))
    );
  };

  const handleRemoveBag = (id: string) => {
    setScannedBags((prev) => prev.filter((b) => b.id !== id));
  };

  // Calculate live bifurcation groups
  const liveBifurcations: FinalDestinationBifurcation[] = useMemo(() => {
    const map = new Map<string, BagRecord[]>();
    for (const bag of scannedBags) {
      const destKey = bag.finalDestinationOffice?.trim() || destinationOffice;
      if (!map.has(destKey)) {
        map.set(destKey, []);
      }
      map.get(destKey)!.push(bag);
    }

    return Array.from(map.entries()).map(([finalDest, bagsList]) => {
      const totalWeight = bagsList.reduce((acc, b) => acc + (b.bagWeightKg || 2.5), 0);
      const totalArticles = bagsList.reduce((acc, b) => acc + (b.totalArticlesCount || 0), 0);
      const speedCount = bagsList.reduce((acc, b) => acc + (b.speedPostCount || 0), 0);
      const insuredCount = bagsList.reduce((acc, b) => acc + (b.insuredCount || 0), 0);
      return {
        finalDestinationOffice: finalDest,
        bags: bagsList,
        totalBags: bagsList.length,
        totalWeightKg: totalWeight,
        totalArticles,
        speedPostCount: speedCount,
        insuredCount,
      };
    });
  }, [scannedBags, destinationOffice]);

  // Execute Despatch
  const handleDespatch = () => {
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!destinationOffice.trim()) {
      setErrorMsg('Destination office is required.');
      return;
    }

    if (scannedBags.length === 0) {
      setErrorMsg('Please scan at least one bag into the despatch schedule.');
      return;
    }

    const scheduleId = activeSchedule ? activeSchedule.scheduleCode : `SCH-${Date.now().toString().slice(-6)}`;
    const totalWeight = scannedBags.reduce((acc, b) => acc + (b.bagWeightKg || 2.5), 0);

    const record: DespatchRecord = {
      id: `desp-${Date.now()}`,
      scheduleId,
      scheduleCode: activeSchedule?.scheduleCode || 'SCH-ROUTE',
      scheduleName: activeSchedule?.scheduleName || 'Outgoing Despatch',
      transitMode: activeSchedule?.transitMode || 'Road / MMS',
      departureTime: activeSchedule?.departureTime || 'Immediate',
      carrierOrVehicle: activeSchedule?.carrierOrVehicle || 'Dept Van',
      destinationOffice: destinationOffice.trim(),
      setName: session.setName,
      officeName: session.officeName,
      despatchedAt: new Date().toLocaleString('en-IN'),
      bags: scannedBags,
      totalBags: scannedBags.length,
      totalWeightKg: totalWeight,
      bifurcatedGroups: [
        {
          destinationOffice: destinationOffice.trim(),
          totalBags: scannedBags.length,
          totalWeightKg: totalWeight,
          totalArticles: scannedBags.reduce((a, b) => a + (b.totalArticlesCount || 0), 0),
          finalDestinations: liveBifurcations,
        },
      ],
    };

    const bagIds = scannedBags.map((b) => b.id);
    onDespatchBags(record, bagIds);
    setLastDespatch(record);
    setScannedBags([]);
    setSuccessMsg(
      `Despatch completed! ${bagIds.length} bags successfully bifurcated and despatched to ${destinationOffice}.`
    );

    if (onActionSuccess) {
      onActionSuccess({
        title: 'Bags Despatched Successfully',
        subtitle: `Schedule ${scheduleId} finalized with ${liveBifurcations.length} bifurcated stations`,
        badge: 'DESPATCH RECORD (M-11)',
        actionType: 'despatch',
        details: [
          { label: 'Schedule', value: `${scheduleId} (${activeSchedule?.scheduleName || 'Route'})` },
          { label: 'Destination Office', value: destinationOffice.trim() },
          { label: 'Final Destinations', value: `${liveBifurcations.length} Stations Bifurcated` },
          { label: 'Total Bags Despatched', value: bagIds.length },
          { label: 'Total Weight', value: `${totalWeight.toFixed(3)} KG` },
          { label: 'Despatching Set', value: `${session.setName} (${session.officeName})` },
          { label: 'Despatched At', value: record.despatchedAt },
        ],
      });
    }
  };

  // Keyboard shortcut: Alt + D
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.altKey && (e.key === 'd' || e.key === 'D')) {
        e.preventDefault();
        if (scannedBags.length > 0) {
          handleDespatch();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [scannedBags, destinationOffice, activeSchedule, liveBifurcations]);

  // Bags ready for despatch
  const readyForDespatch = bags.filter(
    (b) =>
      (b.bagStatus === 'closed' || b.bagStatus === 'received for forwarding') &&
      !scannedBags.some((sb) => sb.id === b.id)
  );

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-neutral-900 flex items-center gap-2">
            <Truck className="text-[#c92228]" size={22} />
            <span>Sub Tab 7: Bag Despatch & Mail Bifurcation</span>
            <span
              className="text-[11px] font-mono bg-neutral-100 text-neutral-600 px-2 py-0.5 rounded border border-neutral-200"
              title="Shortcut: Alt + 7"
            >
              Alt+7
            </span>
          </h2>
          <p className="text-xs text-neutral-500 mt-0.5">
            Select route schedule, assign destination & final destination offices, bifurcate mail list, and print Form M-11
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => {
              setScheduleModalMode('list');
              setIsScheduleModalOpen(true);
            }}
            className="px-3 py-1.5 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer border border-neutral-300"
          >
            <Calendar size={14} className="text-[#c92228]" />
            <span>Manage Schedules ({schedules.length})</span>
          </button>
          <span className="text-xs font-semibold bg-blue-50 text-blue-800 px-3 py-1.5 rounded-full border border-blue-200">
            Ready for Despatch: {readyForDespatch.length} Bags
          </span>
        </div>
      </div>

      {/* Status Alerts */}
      {errorMsg && (
        <div className="p-3.5 bg-red-50 border-l-4 border-red-600 rounded-r-lg flex items-center gap-3 text-red-800 text-xs font-semibold">
          <AlertCircle size={18} className="shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {successMsg && (
        <div className="p-3.5 bg-emerald-50 border-l-4 border-emerald-600 rounded-r-lg flex items-center gap-3 text-emerald-800 text-xs font-semibold">
          <CheckCircle2 size={18} className="shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 1. SCHEDULE BOX (Requested by User) */}
      {/* ========================================================================= */}
      <div className="bg-white rounded-xl border-2 border-neutral-300 p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-200 pb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-red-50 text-[#c92228] rounded-lg">
              <Calendar size={20} />
            </div>
            <div>
              <h3 className="font-extrabold text-sm text-neutral-900 uppercase tracking-wide flex items-center gap-2">
                <span>Despatch Schedule Box</span>
                <span className="text-[10px] bg-neutral-100 text-neutral-600 px-2 py-0.5 rounded font-mono font-bold">
                  MANUALLY EDITABLE & SAVEABLE
                </span>
              </h3>
              <p className="text-xs text-neutral-500">
                A schedule links bags to a Destination Office and bifurcated Final Destination Offices
              </p>
            </div>
          </div>

          {/* Quick Schedule Actions */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                setScheduleToEdit(activeSchedule);
                setIsScheduleModalOpen(true);
              }}
              className="px-3 py-1.5 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-bold rounded-lg flex items-center gap-1.5 cursor-pointer border border-neutral-300 transition-colors"
              title="Edit route code, departure time, and final destinations"
            >
              <Edit2 size={13} className="text-blue-600" />
              <span>Edit Schedule</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setScheduleToEdit(null);
                setScheduleModalMode('add');
                setIsScheduleModalOpen(true);
              }}
              className="px-3 py-1.5 bg-[#c92228] hover:bg-[#a01217] text-white text-xs font-bold rounded-lg flex items-center gap-1.5 cursor-pointer shadow-2xs transition-colors"
              title="Create a new schedule"
            >
              <Plus size={14} />
              <span>+ New Schedule</span>
            </button>
          </div>
        </div>

        {/* Schedule Selector & Active Details Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Schedule Picker Dropdown */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
              Select Despatch Schedule *
            </label>
            <select
              value={selectedScheduleId}
              onChange={(e) => setSelectedScheduleId(e.target.value)}
              className="w-full px-3 py-2.5 bg-neutral-50 border-2 border-neutral-300 focus:border-[#c92228] rounded-lg text-xs font-bold text-neutral-900 focus:outline-hidden"
            >
              {schedules.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.scheduleCode}: {s.scheduleName} ({s.departureTime || 'Immediate'})
                </option>
              ))}
            </select>
            <p className="text-[10px] text-neutral-500 mt-1 font-mono">
              Transit: {activeSchedule.transitMode} | Carrier: {activeSchedule.carrierOrVehicle || 'Dept Van'}
            </p>
          </div>

          {/* Destination Office (Transit Hub) Box - Manually Editable */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
              Destination Office (Transit Hub) *
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={destinationOffice}
                onChange={(e) => setDestinationOffice(e.target.value)}
                placeholder="Destination office..."
                className="flex-1 px-3 py-2 bg-red-50/60 border-2 border-red-200 rounded-lg text-xs font-bold text-[#c92228] focus:border-[#c92228] focus:outline-hidden"
              />
            </div>
            <p className="text-[10px] text-neutral-500 mt-1">
              Primary routing hub under this schedule.
            </p>
          </div>

          {/* Departure & Vehicle Info */}
          <div className="bg-neutral-50 p-3 rounded-lg border border-neutral-200 flex flex-col justify-between text-xs">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-neutral-500 uppercase">Departure Time</span>
              <span className="font-mono font-bold text-neutral-900 flex items-center gap-1">
                <Clock size={12} className="text-[#c92228]" />
                {activeSchedule.departureTime || '10:00'}
              </span>
            </div>
            <div className="flex items-center justify-between mt-1">
              <span className="text-[10px] font-bold text-neutral-500 uppercase">Transit Carrier</span>
              <span className="font-mono font-semibold text-neutral-800 truncate max-w-[150px]">
                {activeSchedule.carrierOrVehicle || 'RMS Section'}
              </span>
            </div>
            <div className="flex items-center justify-between mt-1 pt-1 border-t border-neutral-200">
              <span className="text-[10px] font-bold text-neutral-500 uppercase">Final Destinations</span>
              <span className="font-bold text-[#c92228]">
                {activeSchedule.finalDestinationOffices?.length || 1} Configured
              </span>
            </div>
          </div>
        </div>

        {/* Final Destination Offices Hierarchy Bar under Destination Office */}
        <div className="bg-neutral-50 p-3.5 rounded-xl border border-neutral-200">
          <div className="flex items-center justify-between mb-2">
            <div className="text-xs font-bold text-neutral-800 uppercase flex items-center gap-1.5">
              <Building2 size={14} className="text-[#c92228]" />
              <span>Final Destination Offices under Destination Office ({destinationOffice}):</span>
            </div>
            <span className="text-[11px] text-neutral-500">
              Click any chip below to set as active target for incoming scans
            </span>
          </div>

          <div className="flex flex-wrap gap-2">
            {activeSchedule.finalDestinationOffices && activeSchedule.finalDestinationOffices.length > 0 ? (
              activeSchedule.finalDestinationOffices.map((dest) => {
                const isSelected = selectedFinalDestination === dest;
                const bagsDestinedCount = scannedBags.filter(
                  (b) => b.finalDestinationOffice === dest
                ).length;

                return (
                  <button
                    key={dest}
                    type="button"
                    onClick={() => setSelectedFinalDestination(dest)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border ${
                      isSelected
                        ? 'bg-[#c92228] text-white border-[#c92228] shadow-xs'
                        : 'bg-white text-neutral-700 border-neutral-300 hover:border-neutral-400'
                    }`}
                  >
                    <span>{dest}</span>
                    {bagsDestinedCount > 0 && (
                      <span
                        className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                          isSelected ? 'bg-white text-[#c92228]' : 'bg-neutral-100 text-neutral-800'
                        }`}
                      >
                        {bagsDestinedCount}
                      </span>
                    )}
                  </button>
                );
              })
            ) : (
              <span className="text-xs text-neutral-400 italic">
                No final destinations configured. Click "Edit Schedule" above to add sub-offices.
              </span>
            )}
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. BAG SCANNING & FINAL DESTINATION ASSIGNMENT BOX */}
      {/* ========================================================================= */}
      <div className="bg-white p-6 rounded-xl border border-neutral-200 shadow-xs space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
          {/* Barcode (Bag Label) Scan Box */}
          <div className="md:col-span-5">
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
              Scan Bag Barcode (13 Chars) *
            </label>
            <div className="relative">
              <input
                type="text"
                value={bagBarcode}
                maxLength={13}
                onChange={(e) => setBagBarcode(e.target.value.toUpperCase())}
                placeholder="Scan 13-character bag barcode..."
                className="w-full pl-9 pr-4 py-2.5 bg-neutral-50 border-2 border-neutral-300 focus:border-[#c92228] rounded-lg text-sm font-mono font-bold uppercase text-neutral-900 focus:outline-hidden"
              />
              <Barcode size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
            </div>
            <p className="text-[10px] text-neutral-500 mt-1">
              Supports Speed Post, Parcel, and Regd Mail bags.
            </p>
          </div>

          {/* Final Destination Office for this Scanned Bag */}
          <div className="md:col-span-5">
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
              Assign Final Destination Office *
            </label>
            <select
              value={selectedFinalDestination}
              onChange={(e) => setSelectedFinalDestination(e.target.value)}
              className="w-full px-3 py-2.5 bg-neutral-50 border border-neutral-300 rounded-lg text-xs font-bold text-neutral-900 focus:ring-2 focus:ring-[#c92228] focus:outline-hidden"
            >
              {activeSchedule.finalDestinationOffices?.map((fd) => (
                <option key={fd} value={fd}>
                  {fd}
                </option>
              ))}
              <option value={destinationOffice}>
                Direct to {destinationOffice} (Transit Hub Direct)
              </option>
            </select>
            <p className="text-[10px] text-neutral-500 mt-1">
              Bifurcates bag under Destination Office ({destinationOffice}).
            </p>
          </div>

          {/* Add Bag Button */}
          <div className="md:col-span-2">
            <button
              type="button"
              onClick={handleAddBagToDespatch}
              className="w-full py-2.5 bg-[#c92228] hover:bg-[#a01217] text-white font-bold rounded-lg text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer transition-colors shadow-xs"
            >
              <Plus size={16} />
              <span>Queue Bag</span>
            </button>
          </div>
        </div>

        {/* Available Ready Bags Quick Pick */}
        {readyForDespatch.length > 0 && (
          <div className="pt-3 border-t border-neutral-100 flex items-center gap-2 flex-wrap">
            <span className="text-[11px] font-bold text-neutral-500 uppercase">
              Available Closed/Forwarding Bags:
            </span>
            {readyForDespatch.slice(0, 7).map((b) => (
              <button
                key={b.id}
                type="button"
                onClick={() => {
                  setBagBarcode(b.bagBarcode);
                  // Attempt to match bag's destination office to one of the final destinations
                  const matched = activeSchedule.finalDestinationOffices?.find((fd) =>
                    fd.toLowerCase().includes(b.destinationOffice.toLowerCase().split(' ')[0])
                  );
                  if (matched) {
                    setSelectedFinalDestination(matched);
                  }
                }}
                className="px-2.5 py-1 rounded text-xs font-mono font-bold border border-neutral-200 bg-neutral-50 hover:bg-neutral-100 text-neutral-800 transition-colors cursor-pointer"
                title={`Click to populate ${b.bagBarcode} destined for ${b.destinationOffice}`}
              >
                + {b.bagBarcode} <span className="text-neutral-500 font-sans">({b.destinationOffice})</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* 3. SCANNED BAGS LIST BOX & LIVE BIFURCATION BREAKDOWN */}
      {/* ========================================================================= */}
      <div className="bg-white rounded-xl border border-neutral-200 shadow-xs overflow-hidden">
        {/* Table Title Bar */}
        <div className="p-4 bg-neutral-50 border-b border-neutral-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="font-extrabold text-neutral-900 text-sm flex items-center gap-2">
              <span>Scanned Bags Queue ({scannedBags.length} Bags)</span>
              <span className="text-xs bg-[#c92228] text-white px-2 py-0.5 rounded font-bold">
                Route: {activeSchedule.scheduleCode}
              </span>
            </h3>
            <p className="text-xs text-neutral-500 mt-0.5">
              Transit Hub: <strong>{destinationOffice}</strong> | Bifurcated across {liveBifurcations.length} final stations
            </p>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs font-mono font-bold text-neutral-700 bg-neutral-200 px-3 py-1 rounded-full">
              Total Weight: {scannedBags.reduce((a, b) => a + (b.bagWeightKg || 2.5), 0).toFixed(3)} KG
            </span>
            {scannedBags.length > 0 && (
              <button
                type="button"
                onClick={() => setShowPrintModal(true)}
                className="px-3 py-1 bg-neutral-900 hover:bg-neutral-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-2xs"
              >
                <Printer size={13} />
                <span>Preview Mail List</span>
              </button>
            )}
          </div>
        </div>

        {/* Live Bifurcation Summary Cards */}
        {scannedBags.length > 0 && (
          <div className="p-3 bg-red-50/50 border-b border-neutral-200 flex flex-wrap gap-2">
            <span className="text-[11px] font-bold text-neutral-600 uppercase flex items-center gap-1 self-center">
              <span>Bifurcation Breakdown:</span>
            </span>
            {liveBifurcations.map((bif) => (
              <div
                key={bif.finalDestinationOffice}
                className="px-2.5 py-1 bg-white border border-red-200 rounded-lg text-xs shadow-2xs flex items-center gap-2"
              >
                <span className="font-bold text-neutral-800">{bif.finalDestinationOffice}</span>
                <span className="px-1.5 py-0.2 rounded bg-red-100 text-[#c92228] font-bold font-mono text-[10px]">
                  {bif.totalBags} bags
                </span>
                <span className="text-[10px] font-mono text-neutral-500">
                  {bif.totalWeightKg.toFixed(3)} KG
                </span>
              </div>
            ))}
          </div>
        )}

        {/* Queue Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-neutral-100 text-neutral-700 font-bold border-b border-neutral-200 uppercase tracking-wider">
              <tr>
                <th className="py-3 px-4 w-12 text-center">Sr.</th>
                <th className="py-3 px-4">Bag Barcode (13 Chars)</th>
                <th className="py-3 px-4">Origin Office</th>
                <th className="py-3 px-4">Destination (Hub)</th>
                <th className="py-3 px-4">Final Destination (Bifurcated)</th>
                <th className="py-3 px-4 text-center">Articles</th>
                <th className="py-3 px-4">Weight (KG)</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-200">
              {scannedBags.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-10 text-center text-neutral-400 italic">
                    No bags scanned into this despatch schedule yet. Scan or pick bag barcodes above.
                  </td>
                </tr>
              ) : (
                scannedBags.map((bag, idx) => (
                  <tr key={bag.id} className="hover:bg-neutral-50">
                    <td className="py-3 px-4 text-center font-bold text-neutral-400">{idx + 1}</td>
                    <td className="py-3 px-4 font-mono font-bold text-neutral-900 tracking-wide">
                      {bag.bagBarcode}
                    </td>
                    <td className="py-3 px-4 font-medium text-neutral-700">{bag.sourceOffice}</td>
                    <td className="py-3 px-4 font-bold text-neutral-800">{destinationOffice}</td>
                    <td className="py-3 px-4">
                      {/* Inline Final Destination Selector for Easy Editing */}
                      <select
                        value={bag.finalDestinationOffice || destinationOffice}
                        onChange={(e) => handleUpdateBagFinalDestination(bag.id, e.target.value)}
                        className="px-2 py-1 bg-white border border-neutral-300 rounded font-bold text-xs text-[#c92228] focus:outline-hidden focus:ring-1 focus:ring-[#c92228]"
                      >
                        {activeSchedule.finalDestinationOffices?.map((fd) => (
                          <option key={fd} value={fd}>
                            {fd}
                          </option>
                        ))}
                        <option value={destinationOffice}>{destinationOffice} (Transit Direct)</option>
                      </select>
                    </td>
                    <td className="py-3 px-4 text-center font-bold">
                      {bag.totalArticlesCount} ({bag.insuredCount} Ins)
                    </td>
                    <td className="py-3 px-4 font-semibold font-mono text-neutral-800">
                      {bag.bagWeightKg ? `${bag.bagWeightKg.toFixed(3)}` : '2.500'}
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-neutral-200 text-neutral-800 uppercase">
                        {bag.bagStatus}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        type="button"
                        onClick={() => handleRemoveBag(bag.id)}
                        className="p-1 text-neutral-400 hover:text-red-600 rounded transition-colors cursor-pointer"
                        title="Remove from queue"
                      >
                        <Trash2 size={15} />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Despatch Finalization Action Bar */}
        <div className="p-4 bg-neutral-50 border-t border-neutral-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs text-neutral-600">
            <Layers size={15} />
            <span>
              Despatching from <strong>{session.officeName} ({session.setName})</strong> via{' '}
              <strong>{activeSchedule.scheduleCode}</strong>
            </span>
          </div>

          <div className="flex items-center gap-3">
            {scannedBags.length > 0 && (
              <button
                type="button"
                onClick={() => setShowPrintModal(true)}
                className="px-4 py-2 bg-white border border-neutral-300 hover:bg-neutral-100 text-neutral-800 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-2xs"
              >
                <Printer size={15} />
                <span>Print Bifurcated Mail List (M-11)</span>
              </button>
            )}

            <button
              type="button"
              onClick={handleDespatch}
              disabled={scannedBags.length === 0}
              className={`px-6 py-2.5 rounded-lg text-sm font-bold uppercase tracking-wider flex items-center gap-2 transition-colors shadow-sm ${
                scannedBags.length > 0
                  ? 'bg-[#c92228] hover:bg-[#a01217] text-white cursor-pointer'
                  : 'bg-neutral-200 text-neutral-400 cursor-not-allowed'
              }`}
              title="Complete Bag Despatch (Shortcut: Alt + D)"
            >
              <Truck size={17} />
              <span>Despatch Bags ({scannedBags.length})</span>
              {scannedBags.length > 0 && (
                <kbd className="ml-1 px-1.5 py-0.5 rounded bg-red-900/60 text-white text-[10px] font-mono tracking-normal">
                  Alt+D
                </kbd>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 4. LAST DESPATCHED BIFURCATED MAIL LIST (M-11) DISPLAY */}
      {/* ========================================================================= */}
      {lastDespatch && (
        <div className="bg-white p-6 rounded-xl border border-neutral-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="text-emerald-600" size={22} />
              <div>
                <h3 className="font-extrabold text-neutral-900 text-sm">
                  Despatch Delivery Bill (Form M-11) Generated: {lastDespatch.scheduleId}
                </h3>
                <p className="text-xs text-neutral-500">
                  Destination: {lastDespatch.destinationOffice} | {lastDespatch.bags.length} Bags Despatched
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                setShowPrintModal(true);
              }}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#c92228] text-white hover:bg-[#a01217] text-xs font-bold shadow-xs cursor-pointer"
            >
              <Printer size={15} />
              <span>Print Bifurcated Mail List</span>
            </button>
          </div>

          {/* Embedded Full Bifurcated Mail List */}
          <PrintableBifurcatedMailList
            despatch={lastDespatch}
            schedule={activeSchedule}
            isModal={false}
          />
        </div>
      )}

      {/* Schedule Manager Modal */}
      <DespatchScheduleModal
        isOpen={isScheduleModalOpen}
        onClose={() => setIsScheduleModalOpen(false)}
        selectedScheduleId={selectedScheduleId}
        initialMode={scheduleModalMode}
        editScheduleItem={scheduleToEdit}
        onSelectSchedule={(sch) => {
          setSelectedScheduleId(sch.id);
          setIsScheduleModalOpen(false);
        }}
      />

      {/* Full Modal for Printing Mail List */}
      {showPrintModal && (
        <PrintableBifurcatedMailList
          despatch={
            lastDespatch || {
              id: `preview-${Date.now()}`,
              scheduleId: activeSchedule.scheduleCode,
              scheduleCode: activeSchedule.scheduleCode,
              scheduleName: activeSchedule.scheduleName,
              transitMode: activeSchedule.transitMode,
              departureTime: activeSchedule.departureTime,
              carrierOrVehicle: activeSchedule.carrierOrVehicle,
              destinationOffice: destinationOffice,
              setName: session.setName,
              officeName: session.officeName,
              despatchedAt: new Date().toLocaleString('en-IN'),
              bags: scannedBags,
              totalBags: scannedBags.length,
              totalWeightKg: scannedBags.reduce((a, b) => a + (b.bagWeightKg || 2.5), 0),
            }
          }
          schedule={activeSchedule}
          onClose={() => setShowPrintModal(false)}
          isModal={true}
        />
      )}
    </div>
  );
};
