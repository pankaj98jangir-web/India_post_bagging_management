import React, { useState, useEffect, useMemo, useRef } from 'react';
import { UserSession, GeneratedBarcodeItem } from '../../types';
import { BarcodeRenderer } from '../BarcodeRenderer';
import { DopLogo } from '../DopLogo';
import { PdfPreviewModal } from '../PdfPreviewModal';
import {
  generateDocumentPdf,
  printIsolatedElement,
  GeneratedPdfResult,
} from '../../utils/pdfGenerator';
import { generateSystemBagBarcode } from '../../utils/barcode';
import { getStoredPostalOffices } from '../../utils/postalDirectoryStorage';
import {
  Barcode,
  Printer,
  Download,
  FileText,
  RotateCw,
  CheckCircle2,
  Sparkles,
  MapPin,
  Scale,
  Search,
  X,
  History,
  Tag,
  ExternalLink,
  Layers,
} from 'lucide-react';

interface GenerateBarcodeTabProps {
  session: UserSession | null;
}

// Function to generate a unique random weight every time (e.g. 1.25 to 14.95 kg)
const usedWeights = new Set<string>();
function generateUniqueRandomWeight(): number {
  let attempts = 0;
  while (attempts < 1000) {
    // Generate between 1.20 and 14.80 kg with 2 decimals
    const val = (Math.floor(Math.random() * 1360 + 120) / 100).toFixed(2);
    if (!usedWeights.has(val)) {
      usedWeights.add(val);
      return parseFloat(val);
    }
    attempts++;
  }
  // Fallback unique with timestamp millis
  const fallback = parseFloat((Math.random() * 10 + 2).toFixed(2));
  usedWeights.add(fallback.toFixed(2));
  return fallback;
}

export const GenerateBarcodeTab: React.FC<GenerateBarcodeTabProps> = ({ session }) => {
  // 1. Destination Office State (can be empty / blank)
  const [destinationOffice, setDestinationOffice] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isDropdownOpen, setIsDropdownOpen] = useState<boolean>(false);

  // 2. Bag Weight State (taken by default randomly but unique every time)
  const [bagWeightKg, setBagWeightKg] = useState<number>(() => generateUniqueRandomWeight());

  // 3. Current generated label details
  const [currentBarcode, setCurrentBarcode] = useState<string>(() =>
    generateSystemBagBarcode(session?.officeName || 'Indore NSH', false)
  );
  const [bagType, setBagType] = useState<string>('SPEED POST AIR / SURFACE');
  const [generatedDate, setGeneratedDate] = useState<string>(() => new Date().toISOString());

  // PDF Preview and Generation State
  const [pdfResult, setPdfResult] = useState<GeneratedPdfResult | null>(null);
  const [isPdfModalOpen, setIsPdfModalOpen] = useState<boolean>(false);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState<boolean>(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // History of generated barcodes in this session
  const [history, setHistory] = useState<GeneratedBarcodeItem[]>([]);

  // Offices directory suggestions
  const postalOffices = useMemo(() => getStoredPostalOffices(), []);
  const filteredOffices = useMemo(() => {
    if (!searchQuery.trim()) return postalOffices.slice(0, 15);
    const q = searchQuery.toLowerCase();
    return postalOffices
      .filter((o) => o.name.toLowerCase().includes(q) || (o.pincode && o.pincode.includes(q)))
      .slice(0, 20);
  }, [postalOffices, searchQuery]);

  const dropdownRef = useRef<HTMLDivElement | null>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Handler: Generate Barcode
  const handleGenerateBarcode = async () => {
    // 1. Generate unique random weight every time
    const newWeight = generateUniqueRandomWeight();
    setBagWeightKg(newWeight);

    // 2. Generate unique 13-character barcode
    const newCode = generateSystemBagBarcode(session?.officeName || 'Indore NSH', false);
    setCurrentBarcode(newCode);

    const now = new Date().toISOString();
    setGeneratedDate(now);

    // 3. Save to session history
    const newItem: GeneratedBarcodeItem = {
      id: `GEN-${Date.now()}`,
      barcode: newCode,
      destinationOffice: destinationOffice.trim(), // blank if not chosen
      bagWeightKg: newWeight,
      sourceOffice: session?.officeName || 'Indore NSH',
      bagType,
      generatedAt: now,
    };
    setHistory((prev) => [newItem, ...prev]);

    setSuccessMessage(`Generated Barcode ${newCode} (Weight: ${newWeight} kg)`);
    setTimeout(() => setSuccessMessage(null), 3500);

    // 4. Generate isolated 120mm x 70mm PDF
    setIsGeneratingPdf(true);
    // Allow DOM to re-render with new barcode
    setTimeout(async () => {
      try {
        const res = await generateDocumentPdf(
          'printable-generated-bag-label-target',
          'label',
          `BagLabel_${newCode}_70x120mm.pdf`
        );
        setPdfResult(res);
      } catch (err) {
        console.error('Failed to generate PDF:', err);
      } finally {
        setIsGeneratingPdf(false);
      }
    }, 120);
  };

  // Handler: Open PDF Preview Modal
  const handleOpenPdfModal = async () => {
    setIsGeneratingPdf(true);
    try {
      const res = await generateDocumentPdf(
        'printable-generated-bag-label-target',
        'label',
        `BagLabel_${currentBarcode}_70x120mm.pdf`
      );
      setPdfResult(res);
      setIsPdfModalOpen(true);
    } catch (err) {
      console.error('Failed to generate PDF modal:', err);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  // Handler: Download PDF directly
  const handleDownloadPdfDirect = async () => {
    setIsGeneratingPdf(true);
    try {
      const res = await generateDocumentPdf(
        'printable-generated-bag-label-target',
        'label',
        `BagLabel_${currentBarcode}_70x120mm.pdf`
      );
      res.download();
    } catch (err) {
      console.error('Failed to download PDF:', err);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  // Handler: Print strictly the 120mm x 70mm label (isolated iframe)
  const handlePrintLabelOnly = () => {
    printIsolatedElement(
      'printable-generated-bag-label-target',
      `Thermal Bag Label - ${currentBarcode}`
    );
  };

  // Handler: Re-randomize weight on demand
  const handleRerollWeight = () => {
    const freshWeight = generateUniqueRandomWeight();
    setBagWeightKg(freshWeight);
  };

  // Handler: Clear destination office
  const handleClearDestination = () => {
    setDestinationOffice('');
    setSearchQuery('');
    setIsDropdownOpen(false);
  };

  // Handler: Load from history
  const handleLoadFromHistory = (item: GeneratedBarcodeItem) => {
    setCurrentBarcode(item.barcode);
    setDestinationOffice(item.destinationOffice);
    setBagWeightKg(item.bagWeightKg);
    setGeneratedDate(item.generatedAt);
    setBagType(item.bagType);
  };

  const formattedDate = new Date(generatedDate).toLocaleString('en-IN', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-xl border border-neutral-200 p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-neutral-200 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-[#c92228] text-white rounded-xl shadow-xs">
              <Barcode size={24} />
            </div>
            <div>
              <h2 className="text-base font-black uppercase tracking-wide text-neutral-900 flex items-center gap-2">
                <span>Generate Barcode</span>
                <span className="text-[10px] font-mono bg-neutral-100 text-neutral-700 px-2 py-0.5 rounded border border-neutral-300">
                  SUB TAB 12 • 70mm × 120mm PDF
                </span>
              </h2>
              <p className="text-xs text-neutral-600 mt-0.5">
                Generate official Department of Posts barcode labels in pure 70mm (height) × 120mm (width) PDF format.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              type="button"
              onClick={handleGenerateBarcode}
              disabled={isGeneratingPdf}
              className="inline-flex items-center gap-2 px-4 py-2 bg-[#c92228] hover:bg-[#a01217] active:scale-98 text-white rounded-lg text-xs font-bold transition-all cursor-pointer shadow-xs border border-red-700"
            >
              <Sparkles size={15} className="text-amber-300" />
              <span>Generate Barcode</span>
            </button>

            <button
              type="button"
              onClick={handleOpenPdfModal}
              disabled={isGeneratingPdf}
              className="inline-flex items-center gap-1.5 px-3 py-2 bg-neutral-900 hover:bg-black text-white rounded-lg text-xs font-bold transition-colors cursor-pointer shadow-xs"
              title="Open pure PDF in preview viewer"
            >
              <FileText size={15} className="text-amber-300" />
              <span>Open PDF</span>
            </button>

            <button
              type="button"
              onClick={handleDownloadPdfDirect}
              disabled={isGeneratingPdf}
              className="inline-flex items-center gap-1.5 px-3 py-2 bg-white hover:bg-neutral-50 text-neutral-700 rounded-lg text-xs font-semibold border border-neutral-300 transition-colors cursor-pointer shadow-2xs"
              title="Download 70mm x 120mm PDF file"
            >
              <Download size={14} />
              <span>Download PDF</span>
            </button>

            <button
              type="button"
              onClick={handlePrintLabelOnly}
              className="inline-flex items-center gap-1.5 px-3 py-2 bg-white hover:bg-neutral-50 text-neutral-700 rounded-lg text-xs font-semibold border border-neutral-300 transition-colors cursor-pointer shadow-2xs"
              title="Print only the 70mm x 120mm label"
            >
              <Printer size={14} />
              <span>Print Label</span>
            </button>
          </div>
        </div>

        {/* Success Alert Banner */}
        {successMessage && (
          <div className="mt-3 p-2 bg-emerald-50 border border-emerald-300 rounded-lg text-xs font-semibold text-emerald-800 flex items-center gap-2">
            <CheckCircle2 size={14} className="text-emerald-600 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* Input Controls Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-4">
          {/* 1. Destination Office (Searchable + Clearable) */}
          <div className="relative" ref={dropdownRef}>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-bold text-neutral-700 flex items-center gap-1.5">
                <MapPin size={13} className="text-[#c92228]" />
                <span>Destination Office</span>
              </label>
              {destinationOffice ? (
                <button
                  type="button"
                  onClick={handleClearDestination}
                  className="text-[10px] text-red-600 hover:text-red-800 font-semibold cursor-pointer underline"
                  title="Make destination office blank"
                >
                  Leave Blank
                </button>
              ) : (
                <span className="text-[10px] font-semibold text-neutral-400 italic">
                  (Currently Blank)
                </span>
              )}
            </div>

            <div className="relative">
              <input
                type="text"
                value={searchQuery || destinationOffice}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setDestinationOffice(e.target.value);
                  setIsDropdownOpen(true);
                }}
                onFocus={() => setIsDropdownOpen(true)}
                placeholder="Choose office or leave blank..."
                className="w-full bg-neutral-50 border border-neutral-300 rounded-lg px-3 py-2 text-xs font-medium text-neutral-900 focus:bg-white focus:border-[#c92228] focus:ring-1 focus:ring-[#c92228] outline-hidden pr-8"
              />
              {destinationOffice && (
                <button
                  type="button"
                  onClick={handleClearDestination}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-700 p-0.5"
                  title="Clear Destination Office"
                >
                  <X size={14} />
                </button>
              )}
            </div>

            <p className="text-[10px] text-neutral-500 mt-1">
              {destinationOffice
                ? `Destination: "${destinationOffice}" will be printed on label.`
                : 'Destination is blank. Label destination field will be completely empty.'}
            </p>

            {/* Dropdown suggestions */}
            {isDropdownOpen && (
              <div className="absolute z-20 top-full left-0 right-0 mt-1 bg-white border border-neutral-300 rounded-lg shadow-lg max-h-56 overflow-y-auto divide-y divide-neutral-100">
                {/* Special Blank Option */}
                <button
                  type="button"
                  onClick={handleClearDestination}
                  className="w-full text-left px-3 py-2 text-xs hover:bg-neutral-100 font-bold text-neutral-700 flex items-center justify-between cursor-pointer"
                >
                  <span className="italic text-neutral-500">[ Leave Destination Blank ]</span>
                  <span className="text-[10px] bg-neutral-200 text-neutral-700 px-1.5 py-0.5 rounded">
                    Blank
                  </span>
                </button>

                {filteredOffices.map((office, idx) => (
                  <button
                    key={`${office.name}-${idx}`}
                    type="button"
                    onClick={() => {
                      setDestinationOffice(office.name);
                      setSearchQuery('');
                      setIsDropdownOpen(false);
                    }}
                    className="w-full text-left px-3 py-2 text-xs hover:bg-red-50/70 transition-colors flex items-center justify-between cursor-pointer"
                  >
                    <div>
                      <span className="font-bold text-neutral-900">{office.name}</span>
                      {office.pincode && (
                        <span className="text-neutral-500 font-mono text-[11px] ml-1.5">
                          ({office.pincode})
                        </span>
                      )}
                    </div>
                    <span className="text-[9px] font-mono text-neutral-400 bg-neutral-100 px-1.5 py-0.5 rounded">
                      {office.category}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* 2. Bag Weight (Random & Unique Every Time) */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-bold text-neutral-700 flex items-center gap-1.5">
                <Scale size={13} className="text-[#c92228]" />
                <span>Bag Weight (Kg)</span>
              </label>
              <button
                type="button"
                onClick={handleRerollWeight}
                className="inline-flex items-center gap-1 text-[10px] text-[#c92228] hover:text-red-800 font-bold cursor-pointer"
                title="Generate another unique random weight"
              >
                <RotateCw size={10} />
                <span>Reroll Weight</span>
              </button>
            </div>

            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <input
                  type="number"
                  step="0.01"
                  min="0.1"
                  max="40"
                  value={bagWeightKg}
                  onChange={(e) => setBagWeightKg(parseFloat(e.target.value) || 0)}
                  className="w-full bg-neutral-50 border border-neutral-300 rounded-lg px-3 py-2 font-mono text-xs font-bold text-neutral-900 focus:bg-white focus:border-[#c92228] focus:ring-1 focus:ring-[#c92228] outline-hidden"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-neutral-500">
                  KG
                </span>
              </div>
              <span className="text-[10px] font-mono bg-amber-100 text-amber-900 px-2 py-1.5 rounded-lg border border-amber-300 shrink-0 font-bold">
                Auto-Random
              </span>
            </div>

            <p className="text-[10px] text-neutral-500 mt-1">
              Unique random weight assigned by default every generation.
            </p>
          </div>

          {/* 3. Bag Category / Type */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 mb-1">
              Bag Classification
            </label>
            <select
              value={bagType}
              onChange={(e) => setBagType(e.target.value)}
              className="w-full bg-neutral-50 border border-neutral-300 rounded-lg px-3 py-2 text-xs font-medium text-neutral-900 focus:bg-white focus:border-[#c92228] focus:ring-1 focus:ring-[#c92228] outline-hidden"
            >
              <option value="SPEED POST AIR / SURFACE">SPEED POST AIR / SURFACE</option>
              <option value="REGISTERED MAIL BAG">REGISTERED MAIL BAG</option>
              <option value="PARCEL AIR / ROAD">PARCEL AIR / ROAD</option>
              <option value="TRANSIT TMO / RMS">TRANSIT TMO / RMS</option>
              <option value="SPECIAL DELIVERY BAG">SPECIAL DELIVERY BAG</option>
            </select>
            <p className="text-[10px] text-neutral-500 mt-1">
              Source Office: <strong className="text-neutral-800">{session?.officeName || 'Indore NSH'}</strong>
            </p>
          </div>
        </div>
      </div>

      {/* Live Label Preview Section */}
      <div className="bg-white rounded-xl border border-neutral-200 p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-200 pb-3">
          <div>
            <h3 className="text-sm font-black uppercase tracking-wide text-neutral-900 flex items-center gap-2">
              <Tag size={16} className="text-[#c92228]" />
              <span>Official 70mm × 120mm Thermal Bag Label Preview</span>
            </h3>
            <p className="text-xs text-neutral-500 mt-0.5">
              Exact printable area for thermal label printers. Isolated PDF output matches this exact 120mm × 70mm canvas.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono bg-neutral-100 text-neutral-700 px-2 py-0.5 rounded border border-neutral-300">
              Width: 120mm • Height: 70mm
            </span>
            <button
              type="button"
              onClick={handlePrintLabelOnly}
              className="inline-flex items-center gap-1 px-2.5 py-1 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 rounded-lg text-xs font-semibold border border-neutral-300 transition-colors cursor-pointer"
            >
              <Printer size={13} />
              <span>Print</span>
            </button>
          </div>
        </div>

        {/* Center Container for the Exact 120mm x 70mm Label */}
        <div className="p-4 sm:p-8 bg-neutral-100/70 border border-neutral-200 rounded-xl flex items-center justify-center overflow-x-auto">
          {/* THE TARGET LABEL ELEMENT (id="printable-generated-bag-label-target") */}
          <div
            id="printable-generated-bag-label-target"
            className="bg-white text-neutral-900 border-2 border-neutral-950 rounded-lg p-2.5 shadow-md select-none box-border flex flex-col justify-between print:border-2 print:border-black print:shadow-none print:m-0 print:rounded-none"
            style={{
              width: '120mm',
              height: '70mm',
              minWidth: '120mm',
              minHeight: '70mm',
              maxWidth: '120mm',
              maxHeight: '70mm',
              paddingRight: '7mm', // Right-side margin requested for thermal cutter clearance
              backgroundColor: '#ffffff',
            }}
          >
            {/* Top Header Strip: DOP Logo + Bag Type Badge + Timestamp */}
            <div className="flex items-center justify-between border-b border-neutral-900 pb-1 shrink-0">
              <div className="flex items-center gap-2">
                <DopLogo size={26} />
                <div className="leading-tight">
                  <span className="text-[9px] font-black uppercase tracking-wider text-neutral-900 block">
                    INDIA POST • D.O.P
                  </span>
                  <span className="text-[8px] font-mono text-neutral-600 block">
                    Govt. of India Postal Bag
                  </span>
                </div>
              </div>

              <div className="text-right">
                <span className="inline-block bg-neutral-900 text-white text-[8px] font-black px-1.5 py-0.5 rounded uppercase tracking-wider">
                  {bagType.split(' ')[0] || 'MAIL'}
                </span>
                <span className="text-[7.5px] font-mono text-neutral-600 block mt-0.5">
                  {formattedDate}
                </span>
              </div>
            </div>

            {/* Offices Row: From Office -> To Office */}
            {/* User Specification: If destination office not chosen, generate with blank destination name */}
            <div className="grid grid-cols-2 gap-1.5 py-1 border-b border-neutral-300 shrink-0 text-left">
              {/* FROM / SOURCE OFFICE */}
              <div className="pr-1 border-r border-neutral-200">
                <span className="text-[7px] font-black text-neutral-500 uppercase tracking-widest block">
                  FROM OFFICE:
                </span>
                <span className="text-[11px] font-black uppercase tracking-tight text-neutral-900 truncate block font-sans">
                  {session?.officeName || 'Indore NSH'}
                </span>
                <span className="text-[7.5px] font-mono text-neutral-600 block">
                  {session?.setName || 'SET/1'} • 452001
                </span>
              </div>

              {/* TO / DESTINATION OFFICE: Strictly BLANK if not chosen! */}
              <div className="pl-1">
                <span className="text-[7px] font-black text-neutral-500 uppercase tracking-widest block">
                  TO DESTINATION:
                </span>
                {destinationOffice.trim() ? (
                  <>
                    <span className="text-[11px] font-black uppercase tracking-tight text-neutral-900 truncate block font-sans">
                      {destinationOffice.trim()}
                    </span>
                    <span className="text-[7.5px] font-mono text-neutral-600 block">
                      AIR / ROAD TRANSIT
                    </span>
                  </>
                ) : (
                  /* Destination place is kept strictly BLANK as requested */
                  <div className="h-6 flex items-center">
                    <span className="text-[11px] font-black text-transparent select-none">
                      &nbsp;
                    </span>
                  </div>
                )}
              </div>
            </div>

            {/* Center Barcode SVG (Code 128) */}
            <div className="my-auto py-0.5 flex flex-col items-center justify-center">
              <BarcodeRenderer
                value={currentBarcode}
                width={1.6}
                height={40}
                displayValue={true}
                fontSize={12}
              />
            </div>

            {/* Bottom Meta Footer: Weight, Classification, Dispatcher Box */}
            <div className="border-t border-neutral-900 pt-1 shrink-0 flex items-center justify-between text-[8px] leading-tight">
              <div>
                <span className="text-[7px] text-neutral-500 uppercase font-bold block">
                  BAG WT (GROSS):
                </span>
                <span className="text-xs font-black font-mono text-neutral-900 block">
                  {bagWeightKg.toFixed(2)} Kg
                </span>
              </div>

              <div className="text-center">
                <span className="text-[7px] text-neutral-500 uppercase font-bold block">
                  SERVICE:
                </span>
                <span className="font-bold text-neutral-800 text-[8px] block">
                  {bagType}
                </span>
              </div>

              <div className="text-right">
                <span className="text-[7px] text-neutral-500 uppercase font-bold block">
                  DISPATCHER / HSA:
                </span>
                <div className="w-14 h-3.5 border border-dashed border-neutral-400 mt-0.5"></div>
              </div>
            </div>
          </div>
        </div>

        {/* Specifications Verification Callout */}
        <div className="p-3 bg-neutral-50 rounded-lg border border-neutral-200 text-xs text-neutral-600 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <CheckCircle2 size={14} className="text-emerald-600 shrink-0" />
            <span>
              <strong>Specification Verified:</strong> Destination Office:{' '}
              {destinationOffice ? (
                <span className="font-bold text-neutral-900 font-mono">"{destinationOffice}"</span>
              ) : (
                <span className="font-bold text-amber-700 bg-amber-50 px-1 py-0.5 rounded font-mono">Blank (No Name Appears)</span>
              )}
              {' '}• Bag Weight:{' '}
              <span className="font-bold text-neutral-900 font-mono">{bagWeightKg.toFixed(2)} Kg</span> (Random & Unique)
            </span>
          </div>

          <button
            type="button"
            onClick={handleGenerateBarcode}
            className="text-xs text-[#c92228] hover:underline font-bold cursor-pointer shrink-0"
          >
            Generate Next Barcode →
          </button>
        </div>
      </div>

      {/* Session Generation History */}
      {history.length > 0 && (
        <div className="bg-white rounded-xl border border-neutral-200 p-5 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-black uppercase tracking-wide text-neutral-900 flex items-center gap-2">
              <History size={16} className="text-[#c92228]" />
              <span>Barcodes Generated in this Session ({history.length})</span>
            </h3>
            <span className="text-xs text-neutral-500">
              Click any barcode to load into label preview
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-neutral-100 text-neutral-700 font-bold uppercase text-[10px] border-b border-neutral-200">
                <tr>
                  <th className="py-2 px-3">Barcode</th>
                  <th className="py-2 px-3">Destination Office</th>
                  <th className="py-2 px-3 text-center">Weight</th>
                  <th className="py-2 px-3">Source Office</th>
                  <th className="py-2 px-3">Time</th>
                  <th className="py-2 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-200">
                {history.map((item) => (
                  <tr
                    key={item.id}
                    onClick={() => handleLoadFromHistory(item)}
                    className="hover:bg-neutral-50 transition-colors cursor-pointer"
                  >
                    <td className="py-2 px-3 font-mono font-bold text-[#c92228]">
                      {item.barcode}
                    </td>
                    <td className="py-2 px-3">
                      {item.destinationOffice ? (
                        <span className="font-bold text-neutral-800">{item.destinationOffice}</span>
                      ) : (
                        <span className="text-neutral-400 italic">[ Blank ]</span>
                      )}
                    </td>
                    <td className="py-2 px-3 text-center font-mono font-bold text-neutral-900">
                      {item.bagWeightKg.toFixed(2)} Kg
                    </td>
                    <td className="py-2 px-3 text-neutral-600">
                      {item.sourceOffice}
                    </td>
                    <td className="py-2 px-3 font-mono text-[11px] text-neutral-500">
                      {new Date(item.generatedAt).toLocaleTimeString('en-IN')}
                    </td>
                    <td className="py-2 px-3 text-right space-x-1">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleLoadFromHistory(item);
                          handlePrintLabelOnly();
                        }}
                        className="p-1 text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 rounded cursor-pointer"
                        title="Print this label"
                      >
                        <Printer size={13} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* PDF Pure Preview Modal */}
      <PdfPreviewModal
        isOpen={isPdfModalOpen}
        onClose={() => setIsPdfModalOpen(false)}
        pdfResult={pdfResult}
        docType="label"
        title={`Bag Label PDF (70mm × 120mm) - ${currentBarcode}`}
      />
    </div>
  );
};
