import React, { useState } from 'react';
import { BagRecord, SetName, UserSession } from '../../types';
import { DopLogo } from '../DopLogo';
import { FileSpreadsheet, Calendar, Search, Printer, Download, Layers, ShieldCheck, CheckCircle2 } from 'lucide-react';

interface ConsolidatedAbstractTabProps {
  session: UserSession;
  bags: BagRecord[];
}

const SET_OPTIONS = [
  'All Sets',
  'SET/1',
  'SET/2',
  'SET/2A',
  'SET/2B',
  'SET/3A',
  'SET/3B',
];

export const ConsolidatedAbstractTab: React.FC<ConsolidatedAbstractTabProps> = ({
  session,
  bags,
}) => {
  const [selectedSet, setSelectedSet] = useState<string>(session.setName);
  const todayDateStr = new Date().toISOString().slice(0, 10);
  const [fromDateTime, setFromDateTime] = useState<string>(`${todayDateStr}T00:00`);
  const [toDateTime, setToDateTime] = useState<string>(`${todayDateStr}T23:59`);

  // Filtered stats
  const [stats, setStats] = useState({
    // Bag Details
    bagReceivedForOpenCount: 0,
    bagReceivedForOpenWeight: 0,
    bagReceivedForForwardingCount: 0,
    bagReceivedForForwardingWeight: 0,
    bagClosedCount: 0,
    bagClosedWeight: 0,
    bagDespatchedCount: 0,
    bagDespatchedWeight: 0,
    totalBagsHandled: 0,
    totalWeightHandled: 0,

    // Article Details
    totalArticleReceivedInSet: 0,
    totalInsuredArticleReceived: 0,
    totalArticleClosedInSet: 0,
    totalInsuredArticleClosed: 0,
  });

  const handleFetch = () => {
    // Filter matching bags
    const filtered = bags.filter((b) => {
      if (selectedSet !== 'All Sets' && b.setName !== selectedSet) {
        return false;
      }
      const timeStr = b.receivedAt || b.closedAt || b.despatchedAt || '';
      if (timeStr && fromDateTime && toDateTime) {
        const fromTs = new Date(fromDateTime).getTime();
        const toTs = new Date(toDateTime).getTime();
        const bagTs = new Date(timeStr.replace(' ', 'T')).getTime();
        if (!isNaN(bagTs) && !isNaN(fromTs) && !isNaN(toTs)) {
          if (bagTs < fromTs || bagTs > toTs) return false;
        }
      }
      return true;
    });

    // 1. Bag Details
    const recvOpen = filtered.filter((b) => b.bagStatus === 'received for open' || b.bagStatus === 'opened');
    const recvFwd = filtered.filter((b) => b.bagStatus === 'received for forwarding');
    const closed = filtered.filter((b) => b.bagStatus === 'closed');
    const despatched = filtered.filter((b) => b.bagStatus === 'despatched');

    const recvOpenWeight = recvOpen.reduce((a, b) => a + (b.bagWeightKg || 2.5), 0);
    const recvFwdWeight = recvFwd.reduce((a, b) => a + (b.bagWeightKg || 3.5), 0);
    const closedWeight = closed.reduce((a, b) => a + (b.bagWeightKg || 2.45), 0);
    const despWeight = despatched.reduce((a, b) => a + (b.bagWeightKg || 2.5), 0);

    // 2. Article Details
    // Articles received in set = total articles in received for open + opened bags
    const totalReceivedArticles = recvOpen.reduce((a, b) => a + (b.totalArticlesCount || 0), 0);
    const totalInsuredReceived = recvOpen.reduce((a, b) => a + (b.insuredCount || 0), 0);

    // Articles closed in set = articles enclosed in closed bags + despatched bags
    const closedAndDespBags = [...closed, ...despatched];
    const totalClosedArticles = closedAndDespBags.reduce((a, b) => a + (b.totalArticlesCount || 0), 0);
    const totalInsuredClosed = closedAndDespBags.reduce((a, b) => a + (b.insuredCount || 0), 0);

    setStats({
      bagReceivedForOpenCount: recvOpen.length,
      bagReceivedForOpenWeight: recvOpenWeight,
      bagReceivedForForwardingCount: recvFwd.length,
      bagReceivedForForwardingWeight: recvFwdWeight,
      bagClosedCount: closed.length,
      bagClosedWeight: closedWeight,
      bagDespatchedCount: despatched.length,
      bagDespatchedWeight: despWeight,
      totalBagsHandled: filtered.length,
      totalWeightHandled: recvOpenWeight + recvFwdWeight + closedWeight + despWeight,

      totalArticleReceivedInSet: totalReceivedArticles,
      totalInsuredArticleReceived: totalInsuredReceived,
      totalArticleClosedInSet: totalClosedArticles,
      totalInsuredArticleClosed: totalInsuredClosed,
    });
  };

  React.useEffect(() => {
    handleFetch();
  }, [bags, selectedSet]);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs flex items-center justify-between print:hidden">
        <div>
          <h2 className="text-lg font-bold text-neutral-900 flex items-center gap-2">
            <FileSpreadsheet className="text-[#c92228]" size={22} />
            Sub Tab 10: Consolidated Abstract
          </h2>
          <p className="text-xs text-neutral-500 mt-0.5">
            Consolidated operational abstract categorized into Bag Details and Article Details tables
          </p>
        </div>

        <button
          type="button"
          onClick={handlePrint}
          className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#c92228] hover:bg-[#a01217] text-white font-bold rounded-lg text-xs uppercase tracking-wider transition-colors shadow-xs cursor-pointer"
        >
          <Printer size={15} />
          <span>Print / Download PDF</span>
        </button>
      </div>

      {/* Filter Parameters */}
      <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs print:hidden space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
          {/* Select Set Name Box */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5 flex items-center gap-1">
              <Layers size={14} className="text-neutral-500" />
              Select Set Name Box
            </label>
            <select
              value={selectedSet}
              onChange={(e) => setSelectedSet(e.target.value)}
              className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-xs font-bold text-neutral-900 focus:ring-2 focus:ring-[#c92228]"
            >
              {SET_OPTIONS.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>

          {/* From Date & Time */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5 flex items-center gap-1">
              <Calendar size={14} className="text-neutral-500" />
              From Date & Time
            </label>
            <input
              type="datetime-local"
              value={fromDateTime}
              onChange={(e) => setFromDateTime(e.target.value)}
              className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-xs font-mono font-semibold text-neutral-900 focus:ring-2 focus:ring-[#c92228]"
            />
          </div>

          {/* To Date & Time */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5 flex items-center gap-1">
              <Calendar size={14} className="text-neutral-500" />
              To Date & Time
            </label>
            <input
              type="datetime-local"
              value={toDateTime}
              onChange={(e) => setToDateTime(e.target.value)}
              className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-xs font-mono font-semibold text-neutral-900 focus:ring-2 focus:ring-[#c92228]"
            />
          </div>

          {/* Fetch Button */}
          <div className="flex flex-col justify-end">
            <button
              type="button"
              onClick={handleFetch}
              className="w-full py-2.5 px-4 bg-neutral-900 hover:bg-black text-white font-bold rounded-lg text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-xs"
            >
              <Search size={15} />
              <span>Fetch Consolidated Data</span>
            </button>
          </div>
        </div>
      </div>

      {/* Printable Report Form */}
      <div className="bg-white p-6 sm:p-8 rounded-xl border border-neutral-300 shadow-sm print:border-none print:shadow-none print:p-2 space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between border-b-2 border-neutral-900 pb-4">
          <DopLogo size={46} />
          <div className="text-center">
            <h1 className="text-base font-black tracking-wider uppercase text-neutral-900">
              DEPARTMENT OF POSTS — INDIA
            </h1>
            <h2 className="text-xs font-bold text-neutral-700 uppercase tracking-wide">
              CONSOLIDATED DUTY ABSTRACT & STATISTICAL RETURN
            </h2>
            <p className="text-[11px] text-neutral-500 font-mono mt-0.5">
              Office: {session.officeName} | Shift Duty: {selectedSet}
            </p>
          </div>
          <div className="text-right text-[11px]">
            <span className="font-bold bg-neutral-900 text-white px-2 py-0.5 rounded">
              FORM M-47 (MNOP)
            </span>
            <p className="text-neutral-500 mt-1 font-mono">{new Date().toLocaleString('en-IN')}</p>
          </div>
        </div>

        {/* Date Filter Strip */}
        <div className="bg-neutral-100 p-2.5 rounded border border-neutral-300 text-xs flex items-center justify-between font-mono">
          <div><strong>Active Office:</strong> {session.officeName}</div>
          <div><strong>Set Period:</strong> {fromDateTime.replace('T', ' ')} to {toDateTime.replace('T', ' ')}</div>
          <div><strong>Shift Set:</strong> {selectedSet}</div>
        </div>

        {/* TABLE 1: BAG DETAILS */}
        <div>
          <div className="flex items-center justify-between pb-2 border-b-2 border-neutral-900 mb-3">
            <h3 className="font-black text-xs uppercase tracking-wider text-neutral-900 flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-[#c92228]" />
              TABLE 1: BAG DETAILS
            </h3>
            <span className="text-xs font-mono font-bold text-neutral-700">
              Total Bags Handled: {stats.totalBagsHandled}
            </span>
          </div>

          <div className="border border-neutral-300 rounded overflow-hidden">
            <table className="w-full text-xs text-left">
              <thead className="bg-neutral-100 font-bold border-b border-neutral-300 text-neutral-800 uppercase tracking-wider">
                <tr>
                  <th className="p-3 border-r border-neutral-300 w-12 text-center">Sr.</th>
                  <th className="p-3 border-r border-neutral-300">Bag Operation Category</th>
                  <th className="p-3 border-r border-neutral-300 text-center">Total Bags Count</th>
                  <th className="p-3 border-r border-neutral-300 text-right">Gross Weight (KG)</th>
                  <th className="p-3">Remarks / Verification Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-200">
                <tr className="hover:bg-neutral-50">
                  <td className="p-3 text-center border-r border-neutral-200 font-bold text-neutral-400">1</td>
                  <td className="p-3 border-r border-neutral-200 font-bold text-neutral-900">
                    Bag Received for Open
                  </td>
                  <td className="p-3 border-r border-neutral-200 text-center font-bold text-blue-700 text-sm">
                    {stats.bagReceivedForOpenCount}
                  </td>
                  <td className="p-3 border-r border-neutral-200 text-right font-mono font-semibold">
                    {stats.bagReceivedForOpenWeight.toFixed(3)}
                  </td>
                  <td className="p-3 text-neutral-600 text-[11px]">
                    Incoming mail bags taken into sorting section
                  </td>
                </tr>

                <tr className="hover:bg-neutral-50">
                  <td className="p-3 text-center border-r border-neutral-200 font-bold text-neutral-400">2</td>
                  <td className="p-3 border-r border-neutral-200 font-bold text-neutral-900">
                    Bag Received for Forwarding
                  </td>
                  <td className="p-3 border-r border-neutral-200 text-center font-bold text-purple-700 text-sm">
                    {stats.bagReceivedForForwardingCount}
                  </td>
                  <td className="p-3 border-r border-neutral-200 text-right font-mono font-semibold">
                    {stats.bagReceivedForForwardingWeight.toFixed(3)}
                  </td>
                  <td className="p-3 text-neutral-600 text-[11px]">
                    Closed transit bags received for direct outward routing
                  </td>
                </tr>

                <tr className="hover:bg-neutral-50">
                  <td className="p-3 text-center border-r border-neutral-200 font-bold text-neutral-400">3</td>
                  <td className="p-3 border-r border-neutral-200 font-bold text-neutral-900">
                    Bag Closed
                  </td>
                  <td className="p-3 border-r border-neutral-200 text-center font-bold text-emerald-700 text-sm">
                    {stats.bagClosedCount}
                  </td>
                  <td className="p-3 border-r border-neutral-200 text-right font-mono font-semibold">
                    {stats.bagClosedWeight.toFixed(3)}
                  </td>
                  <td className="p-3 text-neutral-600 text-[11px]">
                    Outward mail bags closed with manifest and scannable label
                  </td>
                </tr>

                <tr className="hover:bg-neutral-50">
                  <td className="p-3 text-center border-r border-neutral-200 font-bold text-neutral-400">4</td>
                  <td className="p-3 border-r border-neutral-200 font-bold text-neutral-900">
                    Bag Despatched
                  </td>
                  <td className="p-3 border-r border-neutral-200 text-center font-bold text-amber-800 text-sm">
                    {stats.bagDespatchedCount}
                  </td>
                  <td className="p-3 border-r border-neutral-200 text-right font-mono font-semibold">
                    {stats.bagDespatchedWeight.toFixed(3)}
                  </td>
                  <td className="p-3 text-neutral-600 text-[11px]">
                    Bags handed over to mail carriers / scheduled vans
                  </td>
                </tr>
              </tbody>
              <tfoot className="bg-neutral-100 font-black border-t-2 border-neutral-400 text-neutral-900">
                <tr>
                  <td colSpan={2} className="p-3 text-right">TOTAL BAGS HANDLED:</td>
                  <td className="p-3 text-center text-sm">{stats.totalBagsHandled} Bags</td>
                  <td className="p-3 text-right font-mono text-sm">{stats.totalWeightHandled.toFixed(3)} KG</td>
                  <td className="p-3 text-[11px] text-neutral-500">Verified by Set Supervisor</td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>

        {/* TABLE 2: ARTICLE DETAILS */}
        <div>
          <div className="flex items-center justify-between pb-2 border-b-2 border-neutral-900 mb-3">
            <h3 className="font-black text-xs uppercase tracking-wider text-neutral-900 flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-blue-600" />
              TABLE 2: ARTICLE DETAILS
            </h3>
            <span className="text-xs font-mono font-bold text-neutral-700">
              Set: {selectedSet}
            </span>
          </div>

          <div className="border border-neutral-300 rounded overflow-hidden">
            <table className="w-full text-xs text-left">
              <thead className="bg-neutral-100 font-bold border-b border-neutral-300 text-neutral-800 uppercase tracking-wider">
                <tr>
                  <th className="p-3 border-r border-neutral-300 w-12 text-center">Sr.</th>
                  <th className="p-3 border-r border-neutral-300">Article Category in Set</th>
                  <th className="p-3 border-r border-neutral-300 text-center">Total Articles Count</th>
                  <th className="p-3 border-r border-neutral-300 text-center">Insured Articles Portion</th>
                  <th className="p-3">Audit Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-200">
                <tr className="hover:bg-neutral-50">
                  <td className="p-3 text-center border-r border-neutral-200 font-bold text-neutral-400">1</td>
                  <td className="p-3 border-r border-neutral-200 font-bold text-neutral-900">
                    Total Article Received in Set
                  </td>
                  <td className="p-3 border-r border-neutral-200 text-center font-bold text-neutral-900 text-sm">
                    {stats.totalArticleReceivedInSet}
                  </td>
                  <td className="p-3 border-r border-neutral-200 text-center font-bold text-amber-700">
                    {stats.totalInsuredArticleReceived} Insured
                  </td>
                  <td className="p-3 text-neutral-600 text-[11px]">
                    Total articles checked from opened incoming bags
                  </td>
                </tr>

                <tr className="hover:bg-neutral-50">
                  <td className="p-3 text-center border-r border-neutral-200 font-bold text-neutral-400">2</td>
                  <td className="p-3 border-r border-neutral-200 font-bold text-neutral-900">
                    Total Insured Article Received
                  </td>
                  <td className="p-3 border-r border-neutral-200 text-center font-black text-amber-800 text-sm">
                    {stats.totalInsuredArticleReceived}
                  </td>
                  <td className="p-3 border-r border-neutral-200 text-center font-bold text-amber-700">
                    100% Insured
                  </td>
                  <td className="p-3 text-neutral-600 text-[11px]">
                    High value insured items verified in safe custody
                  </td>
                </tr>

                <tr className="hover:bg-neutral-50">
                  <td className="p-3 text-center border-r border-neutral-200 font-bold text-neutral-400">3</td>
                  <td className="p-3 border-r border-neutral-200 font-bold text-neutral-900">
                    Total Article Closed in Set
                  </td>
                  <td className="p-3 border-r border-neutral-200 text-center font-bold text-emerald-800 text-sm">
                    {stats.totalArticleClosedInSet}
                  </td>
                  <td className="p-3 border-r border-neutral-200 text-center font-bold text-amber-700">
                    {stats.totalInsuredArticleClosed} Insured
                  </td>
                  <td className="p-3 text-neutral-600 text-[11px]">
                    Enclosed into outward destination and deposit bags
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Verification Signatures */}
        <div className="grid grid-cols-3 gap-6 pt-6 border-t-2 border-neutral-800 text-center text-xs">
          <div>
            <div className="h-10 border-b border-neutral-300"></div>
            <p className="font-bold pt-1 text-neutral-800">Prepared By (Sorting Assistant)</p>
            <p className="text-[10px] text-neutral-500">ID: {session.userId} ({session.officeName})</p>
          </div>
          <div>
            <div className="h-10 border-b border-neutral-300"></div>
            <p className="font-bold pt-1 text-neutral-800">Set Round Stamp</p>
            <p className="text-[10px] text-neutral-500">{selectedSet}</p>
          </div>
          <div>
            <div className="h-10 border-b border-neutral-300"></div>
            <p className="font-bold pt-1 text-neutral-800">Supervisor / Head Sorting Assistant</p>
            <p className="text-[10px] text-neutral-500">Department of Posts</p>
          </div>
        </div>
      </div>
    </div>
  );
};
