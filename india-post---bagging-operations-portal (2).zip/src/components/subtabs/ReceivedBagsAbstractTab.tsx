import React, { useState } from 'react';
import { BagRecord, SetName, UserSession } from '../../types';
import { DopLogo } from '../DopLogo';
import { ClipboardList, Calendar, Search, Printer, Download, Layers, ShieldCheck } from 'lucide-react';

interface ReceivedBagsAbstractTabProps {
  session: UserSession;
  bags: BagRecord[];
}

const SET_OPTIONS = [
  'All Sets',
  'SET/1',
  'SET/2',
  'SET/2A',
  'SET/2B',
  'SET/3A',
  'SET/3B',
];

export const ReceivedBagsAbstractTab: React.FC<ReceivedBagsAbstractTabProps> = ({
  session,
  bags,
}) => {
  const [selectedSet, setSelectedSet] = useState<string>(session.setName);
  // Default date time range: today 00:00 to 23:59
  const todayDateStr = new Date().toISOString().slice(0, 10);
  const [fromDateTime, setFromDateTime] = useState<string>(`${todayDateStr}T00:00`);
  const [toDateTime, setToDateTime] = useState<string>(`${todayDateStr}T23:59`);

  const [hasFetched, setHasFetched] = useState<boolean>(true);
  const [fetchedReceivedForOpen, setFetchedReceivedForOpen] = useState<BagRecord[]>([]);
  const [fetchedClosedBags, setFetchedClosedBags] = useState<BagRecord[]>([]);

  const handleFetch = () => {
    // Filter bags based on set and date/time range
    const filtered = bags.filter((b) => {
      // Set match
      if (selectedSet !== 'All Sets' && b.setName !== selectedSet) {
        return false;
      }

      // Date match (if receivedAt or closedAt present)
      const dateToCheck = b.receivedAt || b.closedAt || '';
      if (dateToCheck && fromDateTime && toDateTime) {
        const fromTs = new Date(fromDateTime).getTime();
        const toTs = new Date(toDateTime).getTime();
        const bagTs = new Date(dateToCheck.replace(' ', 'T')).getTime();
        if (!isNaN(bagTs) && !isNaN(fromTs) && !isNaN(toTs)) {
          if (bagTs < fromTs || bagTs > toTs) {
            return false;
          }
        }
      }

      return true;
    });

    const forOpen = filtered.filter((b) => b.bagStatus === 'received for open' || b.bagStatus === 'opened');
    const closed = filtered.filter((b) => b.bagStatus === 'closed' || b.bagStatus === 'despatched');

    setFetchedReceivedForOpen(forOpen);
    setFetchedClosedBags(closed);
    setHasFetched(true);
  };

  // Initial fetch on mount or when bags change
  React.useEffect(() => {
    handleFetch();
  }, [bags, selectedSet]);

  const handleDownloadPdf = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs flex items-center justify-between print:hidden">
        <div>
          <h2 className="text-lg font-bold text-neutral-900 flex items-center gap-2">
            <ClipboardList className="text-[#c92228]" size={22} />
            Sub Tab 9: Received Bags Abstract
          </h2>
          <p className="text-xs text-neutral-500 mt-0.5">
            Statistical report of total received bags for opening and closed bags lists separately
          </p>
        </div>

        {/* Download PDF / Print Button */}
        <button
          type="button"
          onClick={handleDownloadPdf}
          className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#c92228] hover:bg-[#a01217] text-white font-bold rounded-lg text-xs uppercase tracking-wider transition-colors shadow-xs cursor-pointer"
        >
          <Download size={15} />
          <span>Download PDF / Print</span>
        </button>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs print:hidden space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
          {/* Set Name Box */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5 flex items-center gap-1">
              <Layers size={14} className="text-neutral-500" />
              Set Name Box
            </label>
            <select
              value={selectedSet}
              onChange={(e) => setSelectedSet(e.target.value)}
              className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-xs font-bold text-neutral-900 focus:ring-2 focus:ring-[#c92228]"
            >
              {SET_OPTIONS.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>

          {/* From Date and Time */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5 flex items-center gap-1">
              <Calendar size={14} className="text-neutral-500" />
              From Date & Time
            </label>
            <input
              type="datetime-local"
              value={fromDateTime}
              onChange={(e) => setFromDateTime(e.target.value)}
              className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-xs font-mono font-semibold text-neutral-900 focus:ring-2 focus:ring-[#c92228]"
            />
          </div>

          {/* To Date and Time */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5 flex items-center gap-1">
              <Calendar size={14} className="text-neutral-500" />
              To Date & Time
            </label>
            <input
              type="datetime-local"
              value={toDateTime}
              onChange={(e) => setToDateTime(e.target.value)}
              className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-xs font-mono font-semibold text-neutral-900 focus:ring-2 focus:ring-[#c92228]"
            />
          </div>

          {/* Fetch Button */}
          <div className="flex flex-col justify-end">
            <button
              type="button"
              onClick={handleFetch}
              className="w-full py-2.5 px-4 bg-neutral-900 hover:bg-black text-white font-bold rounded-lg text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-xs"
            >
              <Search size={15} />
              <span>Fetch Abstract Data</span>
            </button>
          </div>
        </div>
      </div>

      {/* Printable Format Document */}
      <div className="bg-white p-6 sm:p-8 rounded-xl border border-neutral-300 shadow-sm print:border-none print:shadow-none print:p-2">
        {/* Document Header */}
        <div className="flex items-center justify-between border-b-2 border-neutral-900 pb-4 mb-6">
          <DopLogo size={46} />
          <div className="text-center">
            <h1 className="text-base font-black tracking-wider uppercase text-neutral-900">
              DEPARTMENT OF POSTS — INDIA
            </h1>
            <h2 className="text-xs font-bold text-neutral-700 uppercase tracking-wide">
              RECEIVED BAGS & CLOSED BAGS ABSTRACT REGISTER
            </h2>
            <p className="text-[11px] text-neutral-500 font-mono mt-0.5">
              Office: {session.officeName} | Set: {selectedSet}
            </p>
          </div>
          <div className="text-right text-[11px]">
            <span className="font-bold bg-neutral-900 text-white px-2 py-0.5 rounded">
              FORM M-44 ABSTRACT
            </span>
            <p className="text-neutral-500 mt-1 font-mono">{new Date().toLocaleString('en-IN')}</p>
          </div>
        </div>

        {/* Abstract Period Banner */}
        <div className="bg-neutral-100 p-2.5 rounded border border-neutral-300 mb-6 text-xs flex items-center justify-between font-mono">
          <div><strong>Set Filter:</strong> {selectedSet}</div>
          <div><strong>Date From:</strong> {fromDateTime.replace('T', ' ')}</div>
          <div><strong>Date To:</strong> {toDateTime.replace('T', ' ')}</div>
        </div>

        {/* Section 1: Total Received Bags for Open List */}
        <div className="mb-8">
          <div className="flex items-center justify-between pb-2 border-b border-neutral-300 mb-2">
            <h3 className="font-bold text-xs uppercase tracking-wider text-neutral-900 flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-600" />
              1. Total Received Bags for Open ({fetchedReceivedForOpen.length} Bags)
            </h3>
            <span className="text-xs font-mono font-bold text-blue-700">
              Total Enclosed Articles: {fetchedReceivedForOpen.reduce((a, b) => a + b.totalArticlesCount, 0)}
            </span>
          </div>

          <div className="border border-neutral-300 rounded overflow-hidden">
            <table className="w-full text-xs text-left">
              <thead className="bg-neutral-100 font-bold border-b border-neutral-300 text-neutral-800">
                <tr>
                  <th className="p-2 w-10 text-center border-r border-neutral-300">Sr.</th>
                  <th className="p-2 border-r border-neutral-300">Bag Barcode</th>
                  <th className="p-2 border-r border-neutral-300">Source Office</th>
                  <th className="p-2 border-r border-neutral-300 text-center">Speed Count</th>
                  <th className="p-2 border-r border-neutral-300 text-center">Insured Count</th>
                  <th className="p-2 border-r border-neutral-300 text-center">Total Articles</th>
                  <th className="p-2 border-r border-neutral-300">Status</th>
                  <th className="p-2 text-right">Received Time</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-200">
                {fetchedReceivedForOpen.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="p-4 text-center text-neutral-400 italic">
                      No bags received for open found in the selected set and period.
                    </td>
                  </tr>
                ) : (
                  fetchedReceivedForOpen.map((b, i) => (
                    <tr key={b.id} className="hover:bg-neutral-50">
                      <td className="p-2 text-center border-r border-neutral-200 text-neutral-500 font-mono">{i + 1}</td>
                      <td className="p-2 border-r border-neutral-200 font-mono font-bold text-neutral-900">{b.bagBarcode}</td>
                      <td className="p-2 border-r border-neutral-200 font-medium text-neutral-800">{b.sourceOffice}</td>
                      <td className="p-2 border-r border-neutral-200 text-center">{b.speedPostCount}</td>
                      <td className="p-2 border-r border-neutral-200 text-center font-bold text-amber-700">{b.insuredCount}</td>
                      <td className="p-2 border-r border-neutral-200 text-center font-bold">{b.totalArticlesCount}</td>
                      <td className="p-2 border-r border-neutral-200 uppercase font-semibold text-[11px] text-blue-700">{b.bagStatus}</td>
                      <td className="p-2 text-right font-mono text-neutral-500 text-[11px]">{b.receivedAt || '—'}</td>
                    </tr>
                  ))
                )}
              </tbody>
              {fetchedReceivedForOpen.length > 0 && (
                <tfoot className="bg-neutral-100 font-bold border-t border-neutral-300">
                  <tr>
                    <td colSpan={3} className="p-2 text-right">Subtotal Received Bags: {fetchedReceivedForOpen.length}</td>
                    <td className="p-2 text-center">{fetchedReceivedForOpen.reduce((a, b) => a + b.speedPostCount, 0)}</td>
                    <td className="p-2 text-center text-amber-800">{fetchedReceivedForOpen.reduce((a, b) => a + b.insuredCount, 0)}</td>
                    <td className="p-2 text-center text-neutral-900">{fetchedReceivedForOpen.reduce((a, b) => a + b.totalArticlesCount, 0)}</td>
                    <td colSpan={2} className="p-2"></td>
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        </div>

        {/* Section 2: Closed Bags List */}
        <div className="mb-6">
          <div className="flex items-center justify-between pb-2 border-b border-neutral-300 mb-2">
            <h3 className="font-bold text-xs uppercase tracking-wider text-neutral-900 flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-600" />
              2. Total Closed Bags List ({fetchedClosedBags.length} Bags)
            </h3>
            <span className="text-xs font-mono font-bold text-emerald-800">
              Total Weight: {fetchedClosedBags.reduce((a, b) => a + (b.bagWeightKg || 2.45), 0).toFixed(3)} KG
            </span>
          </div>

          <div className="border border-neutral-300 rounded overflow-hidden">
            <table className="w-full text-xs text-left">
              <thead className="bg-neutral-100 font-bold border-b border-neutral-300 text-neutral-800">
                <tr>
                  <th className="p-2 w-10 text-center border-r border-neutral-300">Sr.</th>
                  <th className="p-2 border-r border-neutral-300">Bag Barcode</th>
                  <th className="p-2 border-r border-neutral-300">Destination Office</th>
                  <th className="p-2 border-r border-neutral-300 text-center">Articles Count</th>
                  <th className="p-2 border-r border-neutral-300 text-center">Insured Count</th>
                  <th className="p-2 border-r border-neutral-300 text-right">Weight (KG)</th>
                  <th className="p-2 border-r border-neutral-300">Set</th>
                  <th className="p-2 text-right">Closed Time</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-200">
                {fetchedClosedBags.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="p-4 text-center text-neutral-400 italic">
                      No closed bags found in the selected set and period.
                    </td>
                  </tr>
                ) : (
                  fetchedClosedBags.map((b, i) => (
                    <tr key={b.id} className="hover:bg-neutral-50">
                      <td className="p-2 text-center border-r border-neutral-200 text-neutral-500 font-mono">{i + 1}</td>
                      <td className="p-2 border-r border-neutral-200 font-mono font-bold text-neutral-900">{b.bagBarcode}</td>
                      <td className="p-2 border-r border-neutral-200 font-bold text-[#c92228]">{b.destinationOffice}</td>
                      <td className="p-2 border-r border-neutral-200 text-center font-bold">{b.totalArticlesCount}</td>
                      <td className="p-2 border-r border-neutral-200 text-center font-bold text-amber-700">{b.insuredCount}</td>
                      <td className="p-2 border-r border-neutral-200 text-right font-mono">{b.bagWeightKg?.toFixed(3) || '2.450'}</td>
                      <td className="p-2 border-r border-neutral-200 font-semibold">{b.setName}</td>
                      <td className="p-2 text-right font-mono text-neutral-500 text-[11px]">{b.closedAt || '—'}</td>
                    </tr>
                  ))
                )}
              </tbody>
              {fetchedClosedBags.length > 0 && (
                <tfoot className="bg-neutral-100 font-bold border-t border-neutral-300">
                  <tr>
                    <td colSpan={3} className="p-2 text-right">Subtotal Closed Bags: {fetchedClosedBags.length}</td>
                    <td className="p-2 text-center">{fetchedClosedBags.reduce((a, b) => a + b.totalArticlesCount, 0)}</td>
                    <td className="p-2 text-center text-amber-800">{fetchedClosedBags.reduce((a, b) => a + b.insuredCount, 0)}</td>
                    <td className="p-2 text-right font-mono">{fetchedClosedBags.reduce((a, b) => a + (b.bagWeightKg || 2.45), 0).toFixed(3)} KG</td>
                    <td colSpan={2} className="p-2"></td>
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        </div>

        {/* Verification Signatures */}
        <div className="grid grid-cols-3 gap-6 pt-6 border-t-2 border-neutral-800 text-center text-xs">
          <div>
            <div className="h-10 border-b border-neutral-300"></div>
            <p className="font-bold pt-1 text-neutral-800">Mail Guard / SA Incharge</p>
            <p className="text-[10px] text-neutral-500">{session.officeName}</p>
          </div>
          <div>
            <div className="h-10 border-b border-neutral-300"></div>
            <p className="font-bold pt-1 text-neutral-800">Set Round Stamp</p>
            <p className="text-[10px] text-neutral-500">{selectedSet}</p>
          </div>
          <div>
            <div className="h-10 border-b border-neutral-300"></div>
            <p className="font-bold pt-1 text-neutral-800">Supervisor / HSA</p>
            <p className="text-[10px] text-neutral-500">Department of Posts</p>
          </div>
        </div>
      </div>
    </div>
  );
};
