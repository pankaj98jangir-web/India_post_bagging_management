import React, { useState, useEffect, useRef } from 'react';
import { ArticleItem, ArticleType, BagRecord, UserSession, ActionSuccessDetails } from '../../types';
import { OfficeAutocomplete } from '../OfficeAutocomplete';
import { OfficeDirectoryModal } from '../OfficeDirectoryModal';
import { PrintableBagLabel } from '../PrintableBagLabel';
import { PrintableManifest } from '../PrintableManifest';
import {
  generateSystemBagBarcode,
  validateArticleBarcode,
  validateBagBarcode,
  generateRandomArticleBarcode,
} from '../../utils/barcode';
import { exportArticlesToExcel } from '../../utils/excelExport';
import { playScanSuccess, playScanError } from '../../utils/sound';
import {
  PackageCheck,
  Barcode,
  Plus,
  Trash2,
  FileSpreadsheet,
  Printer,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  Scale,
  Building2,
} from 'lucide-react';

interface BagCloseTabProps {
  session: UserSession;
  bags: BagRecord[];
  onCloseBag: (newBag: BagRecord) => void;
  onActionSuccess?: (details: ActionSuccessDetails) => void;
}

export const BagCloseTab: React.FC<BagCloseTabProps> = ({
  session,
  bags,
  onCloseBag,
  onActionSuccess,
}) => {
  // Manual barcode scan input
  const [bagBarcode, setBagBarcode] = useState('');
  const [destinationOffice, setDestinationOffice] = useState('New Delhi NSH');
  const [bagWeightKg, setBagWeightKg] = useState<string>('2.450');
  const [isDirModalOpen, setIsDirModalOpen] = useState(false);

  // Article scan inputs
  const [articleBarcode, setArticleBarcode] = useState('');
  const defaultArticleType: ArticleType = session.officeName === 'Indore PH' ? 'Parcel' : 'Speed Post';
  const [articleType, setArticleType] = useState<ArticleType>(defaultArticleType);
  const [isInsured, setIsInsured] = useState(false);

  // Scanned articles inside current pending closed bag
  const [scannedArticles, setScannedArticles] = useState<ArticleItem[]>([]);

  // Post-close printable modal states
  const [closedBagModal, setClosedBagModal] = useState<BagRecord | null>(null);
  const [modalView, setModalView] = useState<'label' | 'manifest'>('label');

  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const articleInputRef = useRef<HTMLInputElement | null>(null);

  // Auto add article function
  const addArticleByCode = (rawCode: string, insuredFlag: boolean) => {
    setErrorMsg(null);
    setSuccessMsg(null);

    const code = rawCode.trim().toUpperCase();
    if (!code) {
      return;
    }

    const validation = validateArticleBarcode(code);
    if (!validation.isValid) {
      playScanError();
      setErrorMsg(validation.error || 'Invalid 13-character article barcode format.');
      return;
    }

    // Check duplicate in this current bag
    if (scannedArticles.some((a) => a.articleNumber.toUpperCase() === code)) {
      playScanError();
      setErrorMsg(`DUPLICATE ARTICLE! Article ${code} is already added to this bag.`);
      setArticleBarcode('');
      return;
    }

    const newArt: ArticleItem = {
      id: `art-close-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      articleNumber: code,
      articleType,
      isInsured: insuredFlag,
      scannedAt: new Date().toLocaleString('en-IN'),
      destinationOffice,
      weightGrams: Math.floor(100 + Math.random() * 400),
    };

    setScannedArticles((prev) => [newArt, ...prev]);
    setArticleBarcode('');

    // Crucial requirement: flag as insured click automatically unclicks after one article is scanned!
    setIsInsured(false);

    playScanSuccess();
    setSuccessMsg(`Article ${code} added to bag manifest.${insuredFlag ? ' (Insured ✓)' : ''}`);

    if (articleInputRef.current) {
      articleInputRef.current.focus();
    }
  };

  // Article scanner input change: auto add on 13 characters!
  const handleArticleInputChange = (val: string) => {
    const uppercaseVal = val.toUpperCase();
    setArticleBarcode(uppercaseVal);

    if (uppercaseVal.length === 13) {
      setTimeout(() => {
        addArticleByCode(uppercaseVal, isInsured);
      }, 40);
    }
  };

  const handleManualAddArticle = (e: React.FormEvent) => {
    e.preventDefault();
    addArticleByCode(articleBarcode, isInsured);
  };

  const handleRemoveArticle = (id: string) => {
    setScannedArticles((prev) => prev.filter((a) => a.id !== id));
  };

  const handleGenerateSampleArticle = () => {
    const code = generateRandomArticleBarcode(articleType);
    setArticleBarcode(code);
    setTimeout(() => {
      addArticleByCode(code, isInsured);
    }, 100);
  };

  // Close bag helper
  const finalizeBagClose = (finalBarcode: string) => {
    if (!destinationOffice.trim()) {
      setErrorMsg('Please select or specify a destination office.');
      return;
    }

    if (scannedArticles.length === 0) {
      setErrorMsg('Please scan at least one article into the bag before closing.');
      return;
    }

    // Check duplicate bag barcode across all existing bags
    const exists = bags.some((b) => b.bagBarcode.toUpperCase() === finalBarcode.toUpperCase());
    if (exists) {
      setErrorMsg(`DUPLICATE BAG! Bag number ${finalBarcode} has already been closed or received.`);
      return;
    }

    const insuredCount = scannedArticles.filter((a) => a.isInsured).length;
    const speedCount = scannedArticles.length - insuredCount;

    const closedBag: BagRecord = {
      id: `bag-closed-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      bagBarcode: finalBarcode,
      sourceOffice: session.officeName,
      destinationOffice: destinationOffice.trim(),
      bagStatus: 'closed',
      speedPostCount: speedCount,
      insuredCount: insuredCount,
      totalArticlesCount: scannedArticles.length,
      setName: session.setName,
      officeName: session.officeName,
      closedAt: new Date().toLocaleString('en-IN'),
      bagWeightKg: parseFloat(bagWeightKg) || 2.45,
      articles: scannedArticles.map((a) => ({ ...a, bagBarcode: finalBarcode })),
    };

    onCloseBag(closedBag);
    setSuccessMsg(`Bag ${finalBarcode} successfully closed with ${scannedArticles.length} articles!`);

    // Reset local staging inputs
    setBagBarcode('');
    setScannedArticles([]);

    // Trigger Success Popup on Action
    if (onActionSuccess) {
      onActionSuccess({
        title: 'Bag Closed Successfully',
        subtitle: `Ready for despatch to ${destinationOffice.trim()}`,
        badge: 'BAG CLOSED',
        barcode: finalBarcode,
        actionType: 'close',
        bag: closedBag,
        details: [
          { label: 'Destination Office', value: destinationOffice.trim() },
          { label: 'Origin Office', value: session.officeName },
          { label: 'Total Articles', value: closedBag.totalArticlesCount },
          { label: 'Insured Articles', value: insuredCount },
          { label: 'Bag Weight', value: `${closedBag.bagWeightKg?.toFixed(3)} KG` },
          { label: 'Set Name', value: session.setName },
          { label: 'Closed At', value: closedBag.closedAt || new Date().toLocaleString('en-IN') },
        ],
      });
    }

    // Also open printable modal with Label & Manifest
    setClosedBagModal(closedBag);
    setModalView('label');
  };

  // 1. Close Bag (with manually entered barcode)
  const handleCloseWithEnteredBarcode = () => {
    setErrorMsg(null);
    const barcodeClean = bagBarcode.trim().toUpperCase();
    if (!barcodeClean) {
      setErrorMsg('Please enter a barcode in the bag label box, or click "Generate Barcode & Close Bag".');
      return;
    }

    const validation = validateBagBarcode(barcodeClean);
    if (!validation.isValid) {
      setErrorMsg(validation.error || 'Invalid 13-character bag barcode.');
      return;
    }

    finalizeBagClose(barcodeClean);
  };

  // 2. Generate Barcode & Close Bag (System generated 13-char barcode)
  const handleGenerateBarcodeAndClose = () => {
    setErrorMsg(null);
    const existingSet = new Set<string>(bags.map((b) => b.bagBarcode.toUpperCase()));
    const generated = generateSystemBagBarcode(session.officeName, false, existingSet);
    finalizeBagClose(generated);
  };

  // Keyboard shortcut listener for Close Bag actions (Alt + C: Generate and close, Alt + G: Close with entered)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.altKey && (e.key === 'c' || e.key === 'C')) {
        e.preventDefault();
        handleGenerateBarcodeAndClose();
      } else if (e.altKey && (e.key === 'g' || e.key === 'G')) {
        e.preventDefault();
        handleCloseWithEnteredBarcode();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [scannedArticles, destinationOffice, bagBarcode, bagWeightKg]);

  // Export Scanned Articles to Excel
  const handleExportExcel = () => {
    if (scannedArticles.length === 0) {
      setErrorMsg('No articles scanned to export to Excel.');
      return;
    }
    exportArticlesToExcel(
      scannedArticles,
      bagBarcode || 'PENDING_BAG',
      destinationOffice,
      session.officeName,
      session.setName
    );
  };

  const insuredArticlesCount = scannedArticles.filter((a) => a.isInsured).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-neutral-900 flex items-center gap-2">
            <PackageCheck className="text-[#c92228]" size={22} />
            <span>Sub Tab 4: Bag Close</span>
            <span
              className="text-[11px] font-mono bg-neutral-100 text-neutral-600 px-2 py-0.5 rounded border border-neutral-200"
              title="Shortcut key for this tab: Alt + 4"
            >
              Alt+4
            </span>
          </h2>
          <p className="text-xs text-neutral-500 mt-0.5">
            Auto-scan outgoing mail articles, generate scannable DOP bag label & A4 manifest
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setIsDirModalOpen(true)}
            className="px-3 py-2 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer border border-neutral-300"
            title="Manage and update destination offices and PIN codes"
          >
            <Building2 size={14} className="text-[#c92228]" />
            <span>Office & PIN Directory</span>
          </button>

          {/* Excel Export Button */}
          <button
            type="button"
            onClick={handleExportExcel}
            disabled={scannedArticles.length === 0}
            className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold border transition-colors shadow-xs ${
              scannedArticles.length > 0
                ? 'border-emerald-600 bg-emerald-50 text-emerald-800 hover:bg-emerald-100 cursor-pointer'
                : 'border-neutral-200 bg-neutral-100 text-neutral-400 cursor-not-allowed'
            }`}
            title="Export current scanned articles to Excel"
          >
            <FileSpreadsheet size={16} />
            <span>Export Articles to Excel</span>
          </button>
        </div>
      </div>

      {/* Alerts */}
      {errorMsg && (
        <div className="p-3.5 bg-red-50 border-l-4 border-red-600 rounded-r-lg flex items-center gap-3 text-red-800 text-xs font-semibold animate-in fade-in duration-100">
          <AlertCircle size={18} className="shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {successMsg && (
        <div className="p-3.5 bg-emerald-50 border-l-4 border-emerald-600 rounded-r-lg flex items-center gap-3 text-emerald-800 text-xs font-semibold animate-in fade-in duration-100">
          <CheckCircle2 size={18} className="shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Bag Configuration Row */}
      <div className="bg-white p-6 rounded-xl border border-neutral-200 shadow-xs space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {/* Barcode (Bag Label) Scan Box */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
              Barcode (Bag Label) Scan Box (Optional)
            </label>
            <div className="relative">
              <input
                type="text"
                value={bagBarcode}
                maxLength={13}
                onChange={(e) => setBagBarcode(e.target.value.toUpperCase())}
                placeholder="Leave blank to auto-generate, or scan label..."
                className="w-full pl-9 pr-4 py-2.5 bg-neutral-50 border border-neutral-300 rounded-lg text-sm font-mono font-bold uppercase text-neutral-900 focus:ring-2 focus:ring-[#c92228] focus:outline-hidden"
              />
              <Barcode size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
            </div>
            <p className="text-[10px] text-neutral-500 mt-1">
              Prefix: EBI/EBX ({session.officeName})
            </p>
          </div>

          {/* Destination Office */}
          <div>
            <OfficeAutocomplete
              id="close-dest-office"
              label="Destination Office *"
              value={destinationOffice}
              onChange={setDestinationOffice}
              placeholder="Search Sub Post Office, NSH, PH..."
              required
            />
          </div>

          {/* Bag Weight */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <Scale size={14} className="text-neutral-500" />
              <span>Bag Weight (KG) *</span>
            </label>
            <input
              type="number"
              step="0.005"
              min={0.05}
              value={bagWeightKg}
              onChange={(e) => setBagWeightKg(e.target.value)}
              className="w-full px-3 py-2.5 bg-neutral-50 border border-neutral-300 rounded-lg text-sm font-bold text-neutral-900 focus:ring-2 focus:ring-[#c92228] focus:outline-hidden"
            />
          </div>
        </div>
      </div>

      {/* Article Scanning and Scanned Articles List Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Scanned Articles List Box */}
        <div className="lg:col-span-7 bg-white rounded-xl border border-neutral-200 shadow-xs overflow-hidden flex flex-col">
          <div className="p-4 bg-neutral-50 border-b border-neutral-200 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-neutral-900 text-sm">
                Scanned Articles List Box ({scannedArticles.length})
              </h3>
              <p className="text-xs text-neutral-500">
                Destination: <strong className="text-neutral-800">{destinationOffice}</strong>
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold bg-amber-100 text-amber-900 px-2.5 py-1 rounded-full flex items-center gap-1 border border-amber-300">
                <ShieldCheck size={13} /> {insuredArticlesCount} Insured
              </span>
              <span className="text-xs font-bold bg-neutral-200 text-neutral-800 px-2.5 py-1 rounded-full font-mono">
                Total: {scannedArticles.length}
              </span>
            </div>
          </div>

          <div className="p-4 flex-1 overflow-y-auto max-h-96 space-y-2">
            {scannedArticles.length === 0 ? (
              <div className="py-14 text-center text-neutral-400 text-xs italic">
                No articles scanned into this bag yet. Scan article barcodes with your scanner on the right — it automatically adds to the bag!
              </div>
            ) : (
              scannedArticles.map((art, idx) => (
                <div
                  key={art.id}
                  className="p-3 bg-neutral-50 border border-neutral-200 rounded-lg flex items-center justify-between hover:bg-neutral-100 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-bold text-neutral-400 w-6 text-center">{idx + 1}</span>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-neutral-900 text-sm">
                          {art.articleNumber}
                        </span>
                        {art.isInsured && (
                          <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-300">
                            <ShieldCheck size={11} /> INSURED
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-neutral-500">
                        {art.articleType} • Time: {art.scannedAt}
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleRemoveArticle(art.id)}
                    className="p-1.5 text-neutral-400 hover:text-red-600 rounded transition-colors cursor-pointer"
                    title="Remove article"
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Article Input Form & Close Action Buttons */}
        <div className="lg:col-span-5 space-y-5">
          <form onSubmit={handleManualAddArticle} className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-100">
              <h3 className="font-bold text-neutral-800 text-sm uppercase tracking-wider">
                Scan Article into Bag
              </h3>
              <span className="text-[10px] text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                ⚡ Auto-Adds on Scan
              </span>
            </div>

            {/* Article Barcode */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider">
                  Article Barcode Scan Box (13-Chars) *
                </label>
                <button
                  type="button"
                  onClick={handleGenerateSampleArticle}
                  className="text-[11px] font-semibold text-[#c92228] hover:underline cursor-pointer"
                  title="Generate and scan a test article"
                >
                  + Auto-Scan Sample
                </button>
              </div>
              <div className="relative">
                <input
                  ref={articleInputRef}
                  type="text"
                  value={articleBarcode}
                  maxLength={13}
                  onChange={(e) => handleArticleInputChange(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      addArticleByCode(articleBarcode, isInsured);
                    }
                  }}
                  placeholder="Scan article with barcode scanner..."
                  className="pc-scanner-input w-full pl-9 pr-4 py-2.5 bg-neutral-50 border-2 border-neutral-300 focus:border-[#c92228] rounded-lg text-sm font-mono font-bold uppercase text-neutral-900 focus:outline-hidden"
                  title="Scan article barcode (Auto-adds without clicking button)"
                  autoFocus
                />
                <Barcode size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
              </div>
            </div>

            {/* Article Type & Insured Flag Button with Auto-Unclick */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                  Article Type
                </label>
                <select
                  value={articleType}
                  onChange={(e) => setArticleType(e.target.value as ArticleType)}
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-xs font-bold text-neutral-900 cursor-pointer"
                >
                  <option value="Speed Post">Speed Post</option>
                  <option value="Parcel">Parcel</option>
                  <option value="Registered">Registered</option>
                </select>
              </div>

              {/* Insured Article Tick Button: Automatically unclicks after one article is scanned! */}
              <div className="flex flex-col justify-end">
                <button
                  type="button"
                  onClick={() => setIsInsured(!isInsured)}
                  className={`w-full py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer border ${
                    isInsured
                      ? 'bg-amber-500 text-white border-amber-600 shadow-xs'
                      : 'bg-neutral-50 text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                  title="Click to flag article as insured then scan barcode. Automatically unclicks after one article is scanned."
                >
                  <ShieldCheck size={16} />
                  <span>{isInsured ? '✓ Insured Flagged' : 'Flag as Insured'}</span>
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-neutral-900 hover:bg-black text-white font-bold rounded-lg text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer transition-colors shadow-xs"
              title="Add Article to Bag (Auto-adds on scan or Enter)"
            >
              <Plus size={16} />
              <span>Add Article to Bag</span>
              <span className="text-[10px] font-mono bg-white/20 px-1.5 py-0.5 rounded text-neutral-300">
                Auto-Scan On
              </span>
            </button>
          </form>

          {/* Close Bag Dual Action Buttons with Hover Shortcuts & Visual Badges */}
          <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs space-y-3">
            <h3 className="font-bold text-neutral-800 text-xs uppercase tracking-wider pb-1">
              Close Bag Actions
            </h3>

            {/* Button 1: If user hasn't printed bag label */}
            <button
              type="button"
              onClick={handleGenerateBarcodeAndClose}
              className="w-full py-3 px-4 bg-[#c92228] hover:bg-[#a01217] text-white font-bold rounded-lg shadow-sm text-xs uppercase tracking-wide flex items-center justify-center gap-2 cursor-pointer transition-colors"
              title="Generate Barcode & Close Bag (Shortcut: Alt + C)"
            >
              <Sparkles size={17} />
              <span>Generate Barcode & Close Bag</span>
              <kbd className="ml-1.5 px-1.5 py-0.5 rounded bg-red-900/60 text-white text-[10px] font-mono tracking-normal">
                Alt+C
              </kbd>
            </button>
            <p className="text-[10px] text-neutral-500 text-center">
              (Generates system barcode with DOP prefix; Shortcut: Alt + C)
            </p>

            <div className="relative flex py-1 items-center">
              <div className="grow border-t border-neutral-200"></div>
              <span className="shrink mx-2 text-[10px] text-neutral-400 uppercase font-semibold">OR</span>
              <div className="grow border-t border-neutral-200"></div>
            </div>

            {/* Button 2: If user already entered barcode */}
            <button
              type="button"
              onClick={handleCloseWithEnteredBarcode}
              className="w-full py-2.5 px-4 bg-neutral-800 hover:bg-neutral-900 text-white font-bold rounded-lg shadow-xs text-xs uppercase tracking-wide flex items-center justify-center gap-2 cursor-pointer transition-colors"
              title="Close Bag With Entered Barcode (Shortcut: Alt + G)"
            >
              <PackageCheck size={16} />
              <span>Close Bag (With Entered Barcode)</span>
              <kbd className="ml-1.5 px-1.5 py-0.5 rounded bg-neutral-700 text-neutral-200 text-[10px] font-mono tracking-normal">
                Alt+G
              </kbd>
            </button>
            <p className="text-[10px] text-neutral-500 text-center">
              (Use if you already scanned or entered a barcode number; Shortcut: Alt + G)
            </p>
          </div>
        </div>
      </div>

      {/* Immediate Printable Format Modal (Bag Manifest & Generated Bag Label) */}
      {closedBagModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 print:p-0 print:static print:bg-white backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full p-6 print:shadow-none print:p-0 print:border-none relative max-h-[92vh] flex flex-col">
            {/* Modal Header with Switch Tabs */}
            <div className="flex items-center justify-between pb-4 border-b border-neutral-200 shrink-0 print:hidden">
              <div className="flex items-center gap-3">
                <span className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse" />
                <h3 className="font-bold text-neutral-900 text-base">
                  Bag Successfully Closed: <span className="font-mono text-[#c92228]">{closedBagModal.bagBarcode}</span>
                </h3>
              </div>

              {/* Toggle between Bag Label and Bag Manifest */}
              <div className="flex items-center gap-2">
                <div className="bg-neutral-100 p-1 rounded-lg flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => setModalView('label')}
                    className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all cursor-pointer ${
                      modalView === 'label'
                        ? 'bg-white text-neutral-900 shadow-xs'
                        : 'text-neutral-600 hover:text-neutral-900'
                    }`}
                  >
                    Bag Label (120×70mm)
                  </button>
                  <button
                    type="button"
                    onClick={() => setModalView('manifest')}
                    className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all cursor-pointer ${
                      modalView === 'manifest'
                        ? 'bg-white text-neutral-900 shadow-xs'
                        : 'text-neutral-600 hover:text-neutral-900'
                    }`}
                  >
                    Bag Manifest (A4)
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => setClosedBagModal(null)}
                  className="px-3 py-1.5 bg-neutral-200 hover:bg-neutral-300 text-neutral-800 rounded-lg text-xs font-bold cursor-pointer"
                >
                  Done / Close
                </button>
              </div>
            </div>

            {/* Printable View Body */}
            <div className="overflow-y-auto flex-1 py-4 flex justify-center">
              {modalView === 'label' ? (
                <PrintableBagLabel bag={closedBagModal} isModal={false} />
              ) : (
                <PrintableManifest bag={closedBagModal} isModal={false} />
              )}
            </div>
          </div>
        </div>
      )}

      {/* Office & PIN Directory Manager Modal */}
      <OfficeDirectoryModal
        isOpen={isDirModalOpen}
        onClose={() => setIsDirModalOpen(false)}
        selectedOffice={destinationOffice}
        onSelectOffice={(officeName) => {
          setDestinationOffice(officeName);
          setIsDirModalOpen(false);
        }}
      />
    </div>
  );
};
