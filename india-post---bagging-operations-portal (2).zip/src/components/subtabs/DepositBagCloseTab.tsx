import React, { useState, useEffect, useRef } from 'react';
import { ArticleItem, ArticleType, BagRecord, SetName, UserSession, ActionSuccessDetails } from '../../types';
import { PrintableBagLabel } from '../PrintableBagLabel';
import { PrintableManifest } from '../PrintableManifest';
import {
  generateSystemBagBarcode,
  validateArticleBarcode,
  validateBagBarcode,
  generateRandomArticleBarcode,
} from '../../utils/barcode';
import { exportArticlesToExcel } from '../../utils/excelExport';
import { playScanSuccess, playScanError } from '../../utils/sound';
import {
  Archive,
  Barcode,
  Plus,
  Trash2,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  Scale,
  Layers,
  FileSpreadsheet,
} from 'lucide-react';

interface DepositBagCloseTabProps {
  session: UserSession;
  bags: BagRecord[];
  onCloseDepositBag: (newBag: BagRecord) => void;
  onActionSuccess?: (details: ActionSuccessDetails) => void;
}

const DEPOSIT_SETS: SetName[] = ['SET/1', 'SET/2', 'SET/2A', 'SET/2B'];

export const DepositBagCloseTab: React.FC<DepositBagCloseTabProps> = ({
  session,
  bags,
  onCloseDepositBag,
  onActionSuccess,
}) => {
  const [bagBarcode, setBagBarcode] = useState('');
  // Set name instead of destination office
  const [targetSet, setTargetSet] = useState<SetName>('SET/2');
  const [bagWeightKg, setBagWeightKg] = useState<string>('1.950');

  // Article scan inputs
  const [articleBarcode, setArticleBarcode] = useState('');
  const defaultArticleType: ArticleType = session.officeName === 'Indore PH' ? 'Parcel' : 'Speed Post';
  const [articleType, setArticleType] = useState<ArticleType>(defaultArticleType);
  const [isInsured, setIsInsured] = useState(false);

  // Scanned articles inside pending deposit bag
  const [scannedArticles, setScannedArticles] = useState<ArticleItem[]>([]);

  // Modal views
  const [closedBagModal, setClosedBagModal] = useState<BagRecord | null>(null);
  const [modalView, setModalView] = useState<'label' | 'manifest'>('label');

  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const articleInputRef = useRef<HTMLInputElement | null>(null);

  const addArticleByCode = (rawCode: string, insuredFlag: boolean) => {
    setErrorMsg(null);
    setSuccessMsg(null);

    const code = rawCode.trim().toUpperCase();
    if (!code) {
      return;
    }

    const validation = validateArticleBarcode(code);
    if (!validation.isValid) {
      playScanError();
      setErrorMsg(validation.error || 'Invalid article format.');
      return;
    }

    if (scannedArticles.some((a) => a.articleNumber.toUpperCase() === code)) {
      playScanError();
      setErrorMsg(`DUPLICATE ARTICLE! Article ${code} is already added to this deposit bag.`);
      setArticleBarcode('');
      return;
    }

    const newArt: ArticleItem = {
      id: `art-dep-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      articleNumber: code,
      articleType,
      isInsured: insuredFlag,
      scannedAt: new Date().toLocaleString('en-IN'),
      destinationOffice: `${session.officeName} (${targetSet})`,
      weightGrams: Math.floor(80 + Math.random() * 300),
    };

    setScannedArticles((prev) => [newArt, ...prev]);
    setArticleBarcode('');
    setIsInsured(false);
    playScanSuccess();
    setSuccessMsg(`Article ${code} added to deposit bag.${insuredFlag ? ' (Insured ✓)' : ''}`);

    if (articleInputRef.current) {
      articleInputRef.current.focus();
    }
  };

  const handleArticleInputChange = (val: string) => {
    const uppercaseVal = val.toUpperCase();
    setArticleBarcode(uppercaseVal);
    if (uppercaseVal.length === 13) {
      setTimeout(() => {
        addArticleByCode(uppercaseVal, isInsured);
      }, 40);
    }
  };

  const handleAddArticle = (e: React.FormEvent) => {
    e.preventDefault();
    addArticleByCode(articleBarcode, isInsured);
  };

  const handleRemoveArticle = (id: string) => {
    setScannedArticles((prev) => prev.filter((a) => a.id !== id));
  };

  const handleSampleArticle = () => {
    const code = generateRandomArticleBarcode(articleType);
    setArticleBarcode(code);
  };

  const finalizeDepositBagClose = (finalBarcode: string) => {
    if (scannedArticles.length === 0) {
      setErrorMsg('Please scan at least one article into the deposit bag before closing.');
      return;
    }

    // Check duplicate bag barcode
    const exists = bags.some((b) => b.bagBarcode.toUpperCase() === finalBarcode.toUpperCase());
    if (exists) {
      setErrorMsg(`DUPLICATE BAG! Bag ${finalBarcode} already exists in the system.`);
      return;
    }

    const insuredCount = scannedArticles.filter((a) => a.isInsured).length;
    const speedCount = scannedArticles.length - insuredCount;

    const depositBag: BagRecord = {
      id: `bag-dep-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      bagBarcode: finalBarcode,
      sourceOffice: session.officeName,
      destinationOffice: `${session.officeName} - DEPOSIT FOR ${targetSet}`,
      bagStatus: 'closed',
      speedPostCount: speedCount,
      insuredCount: insuredCount,
      totalArticlesCount: scannedArticles.length,
      setName: session.setName,
      officeName: session.officeName,
      closedAt: new Date().toLocaleString('en-IN'),
      isDepositBag: true,
      targetSetForDeposit: targetSet,
      bagWeightKg: parseFloat(bagWeightKg) || 1.95,
      articles: scannedArticles.map((a) => ({ ...a, bagBarcode: finalBarcode })),
    };

    onCloseDepositBag(depositBag);
    setSuccessMsg(`Deposit Bag ${finalBarcode} successfully closed for ${targetSet}!`);

    if (onActionSuccess) {
      onActionSuccess({
        title: 'Deposit Bag Closed Successfully',
        subtitle: `Sealed for handover to ${targetSet}`,
        badge: 'DEPOSIT BAG',
        barcode: finalBarcode,
        actionType: 'deposit_close',
        bag: depositBag,
        details: [
          { label: 'Target Handover Set', value: targetSet },
          { label: 'Working Office', value: session.officeName },
          { label: 'Current Set', value: session.setName },
          { label: 'Total Articles', value: depositBag.totalArticlesCount },
          { label: 'Insured Articles', value: insuredCount },
          { label: 'Bag Weight', value: `${depositBag.bagWeightKg?.toFixed(3)} KG` },
          { label: 'Timestamp', value: depositBag.closedAt || new Date().toLocaleString('en-IN') },
        ],
      });
    }

    setBagBarcode('');
    setScannedArticles([]);
    setClosedBagModal(depositBag);
    setModalView('label');
  };

  // Keyboard shortcut (Alt + P)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.altKey && (e.key === 'p' || e.key === 'P')) {
        e.preventDefault();
        handleGenerateAndClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [scannedArticles, targetSet, session, bagWeightKg]);

  // Close Deposit Bag with entered barcode
  const handleCloseDepositBag = () => {
    setErrorMsg(null);
    const barcodeClean = bagBarcode.trim().toUpperCase();
    if (!barcodeClean) {
      setErrorMsg('Please enter a barcode or click "Generate Barcode and Close Bag".');
      return;
    }

    const validation = validateBagBarcode(barcodeClean);
    if (!validation.isValid) {
      setErrorMsg(validation.error || 'Invalid 13-character bag barcode.');
      return;
    }

    finalizeDepositBagClose(barcodeClean);
  };

  // Generate Barcode and Close Bag (Starts from DBX/DBI for all offices!)
  const handleGenerateAndClose = () => {
    setErrorMsg(null);
    const existingSet = new Set<string>(bags.map((b) => b.bagBarcode.toUpperCase()));
    // isDepositBag = true generates DBI / DBX prefix
    const generated = generateSystemBagBarcode(session.officeName, true, existingSet);
    finalizeDepositBagClose(generated);
  };

  const handleExportExcel = () => {
    if (scannedArticles.length === 0) return;
    exportArticlesToExcel(
      scannedArticles,
      bagBarcode || 'DEPOSIT_BAG',
      `Deposit for ${targetSet}`,
      session.officeName,
      session.setName
    );
  };

  const insuredCount = scannedArticles.filter((a) => a.isInsured).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-neutral-900 flex items-center gap-2">
            <Archive className="text-[#c92228]" size={22} />
            <span>Sub Tab 8: Deposit Bag Close</span>
            <span
              className="text-[11px] font-mono bg-neutral-100 text-neutral-600 px-2 py-0.5 rounded border border-neutral-200"
              title="Shortcut key for this tab: Alt + 8"
            >
              Alt+8
            </span>
          </h2>
          <p className="text-xs text-neutral-500 mt-0.5">
            Close internal hand-over deposit bags between working sets (Barcodes start with DBI/DBX)
          </p>
        </div>

        <button
          type="button"
          onClick={handleExportExcel}
          disabled={scannedArticles.length === 0}
          className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold border transition-colors shadow-xs ${
            scannedArticles.length > 0
              ? 'border-emerald-600 bg-emerald-50 text-emerald-800 hover:bg-emerald-100 cursor-pointer'
              : 'border-neutral-200 bg-neutral-100 text-neutral-400 cursor-not-allowed'
          }`}
        >
          <FileSpreadsheet size={16} />
          <span>Export Scanned Articles to Excel</span>
        </button>
      </div>

      {errorMsg && (
        <div className="p-3.5 bg-red-50 border-l-4 border-red-600 rounded-r-lg flex items-center gap-3 text-red-800 text-xs font-semibold">
          <AlertCircle size={18} className="shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {successMsg && (
        <div className="p-3.5 bg-emerald-50 border-l-4 border-emerald-600 rounded-r-lg flex items-center gap-3 text-emerald-800 text-xs font-semibold">
          <CheckCircle2 size={18} className="shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Bag Configuration Row */}
      <div className="bg-white p-6 rounded-xl border border-neutral-200 shadow-xs space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {/* Barcode (Bag Label) Scan Box */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
              Barcode (Bag Label) Scan Box (Optional)
            </label>
            <div className="relative">
              <input
                type="text"
                value={bagBarcode}
                maxLength={13}
                onChange={(e) => setBagBarcode(e.target.value.toUpperCase())}
                placeholder="Leave blank to auto-generate (DBI/DBX)..."
                className="w-full pl-9 pr-4 py-2.5 bg-neutral-50 border border-neutral-300 rounded-lg text-sm font-mono font-bold uppercase text-neutral-900 focus:ring-2 focus:ring-[#c92228] focus:outline-hidden"
              />
              <Barcode size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
            </div>
            <p className="text-[10px] text-neutral-500 mt-1">
              Deposit barcode starts with DBI or DBX for all offices
            </p>
          </div>

          {/* Set Name (SET/1, SET/2, SET/2A, SET/2B) instead of Destination Office */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <Layers size={14} className="text-neutral-500" />
              Target Set Name (Instead of Destination Office) *
            </label>
            <select
              value={targetSet}
              onChange={(e) => setTargetSet(e.target.value as SetName)}
              className="w-full px-3 py-2.5 bg-neutral-50 border border-neutral-300 rounded-lg text-sm font-bold text-neutral-900 focus:ring-2 focus:ring-[#c92228]"
            >
              {DEPOSIT_SETS.map((s) => (
                <option key={s} value={s}>
                  {s} (Handover Target)
                </option>
              ))}
            </select>
            <p className="text-[10px] text-neutral-500 mt-1">
              Specifies the subsequent duty set receiving this deposit bag
            </p>
          </div>

          {/* Bag Weight */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <Scale size={14} className="text-neutral-500" />
              Deposit Bag Weight (KG)
            </label>
            <input
              type="number"
              step="0.005"
              min={0.05}
              value={bagWeightKg}
              onChange={(e) => setBagWeightKg(e.target.value)}
              className="w-full px-3 py-2.5 bg-neutral-50 border border-neutral-300 rounded-lg text-sm font-bold text-neutral-900 focus:ring-2 focus:ring-[#c92228] focus:outline-hidden"
            />
          </div>
        </div>
      </div>

      {/* Scanned Articles & Action Buttons */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Scanned Articles List Box */}
        <div className="lg:col-span-7 bg-white rounded-xl border border-neutral-200 shadow-xs overflow-hidden flex flex-col">
          <div className="p-4 bg-neutral-50 border-b border-neutral-200 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-neutral-900 text-sm">
                Deposit Scanned Articles List Box ({scannedArticles.length})
              </h3>
              <p className="text-xs text-neutral-500">
                Holding for next shift set: <strong>{targetSet}</strong>
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold bg-amber-100 text-amber-900 px-2.5 py-1 rounded-full flex items-center gap-1">
                <ShieldCheck size={13} /> {insuredCount} Insured
              </span>
              <span className="text-xs font-bold bg-neutral-200 text-neutral-800 px-2.5 py-1 rounded-full font-mono">
                Total: {scannedArticles.length}
              </span>
            </div>
          </div>

          <div className="p-4 flex-1 overflow-y-auto max-h-96 space-y-2">
            {scannedArticles.length === 0 ? (
              <div className="py-14 text-center text-neutral-400 text-xs italic">
                No deposit articles scanned yet. Scan article barcodes using the form on the right.
              </div>
            ) : (
              scannedArticles.map((art, idx) => (
                <div
                  key={art.id}
                  className="p-3 bg-neutral-50 border border-neutral-200 rounded-lg flex items-center justify-between hover:bg-neutral-100 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-bold text-neutral-400 w-6 text-center">{idx + 1}</span>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-neutral-900 text-sm">
                          {art.articleNumber}
                        </span>
                        {art.isInsured && (
                          <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800">
                            <ShieldCheck size={11} /> INSURED
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-neutral-500">
                        {art.articleType} • Added: {art.scannedAt}
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleRemoveArticle(art.id)}
                    className="p-1.5 text-neutral-400 hover:text-red-600 rounded transition-colors"
                    title="Remove article"
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Scan Article & Deposit Close Buttons */}
        <div className="lg:col-span-5 space-y-5">
          <form onSubmit={handleAddArticle} className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs space-y-4">
            <h3 className="font-bold text-neutral-800 text-sm uppercase tracking-wider pb-2 border-b border-neutral-100">
              Scan Article into Deposit Bag
            </h3>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider">
                  Article Barcode Scan Box (13-Chars) *
                </label>
                <button
                  type="button"
                  onClick={handleSampleArticle}
                  className="text-[11px] font-semibold text-[#c92228] hover:underline"
                >
                  + Sample
                </button>
              </div>
              <div className="relative">
                <input
                  ref={articleInputRef}
                  type="text"
                  value={articleBarcode}
                  maxLength={13}
                  onChange={(e) => handleArticleInputChange(e.target.value)}
                  placeholder="e.g. EE123456789IN (Auto-adds on 13 chars)"
                  className="pc-scanner-input w-full pl-9 pr-4 py-2.5 bg-neutral-50 border-2 border-neutral-300 focus:border-[#c92228] rounded-lg text-sm font-mono font-bold uppercase text-neutral-900 focus:outline-hidden"
                />
                <Barcode size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                  Article Type
                </label>
                <select
                  value={articleType}
                  onChange={(e) => setArticleType(e.target.value as ArticleType)}
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-lg text-xs font-bold text-neutral-900"
                >
                  <option value="Speed Post">Speed Post</option>
                  <option value="Parcel">Parcel</option>
                  <option value="Registered">Registered</option>
                </select>
              </div>

              <div className="flex flex-col justify-end">
                <button
                  type="button"
                  onClick={() => setIsInsured(!isInsured)}
                  className={`w-full py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-colors border ${
                    isInsured
                      ? 'bg-amber-500 text-white border-amber-600 shadow-xs'
                      : 'bg-neutral-50 text-neutral-700 border-neutral-300 hover:bg-neutral-100'
                  }`}
                >
                  <ShieldCheck size={16} />
                  <span>{isInsured ? '✓ Insured' : 'Flag Insured'}</span>
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-neutral-900 hover:bg-black text-white font-bold rounded-lg text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer transition-colors shadow-xs"
            >
              <Plus size={16} />
              <span>Add Article to Deposit Bag</span>
            </button>
          </form>

          {/* Deposit Close Action Buttons */}
          <div className="bg-white p-5 rounded-xl border border-neutral-200 shadow-xs space-y-3">
            <h3 className="font-bold text-neutral-800 text-xs uppercase tracking-wider pb-1">
              Deposit Bag Actions
            </h3>

            {/* Button 1: Generate Barcode & Close Bag (Starts with DBI / DBX) */}
            <button
              type="button"
              onClick={handleGenerateAndClose}
              className="w-full py-3 px-4 bg-[#c92228] hover:bg-[#a01217] text-white font-bold rounded-lg shadow-sm text-xs uppercase tracking-wide flex items-center justify-center gap-2 cursor-pointer transition-colors"
              title="Generate Barcode and Close Deposit Bag (Shortcut: Alt + P)"
            >
              <Sparkles size={17} />
              <span>Generate Barcode and Close Bag (DBI/DBX)</span>
              <kbd className="ml-1 px-1.5 py-0.5 rounded bg-red-900/60 text-white text-[10px] font-mono tracking-normal">
                Alt+P
              </kbd>
            </button>
            <p className="text-[10px] text-neutral-500 text-center">
              Auto-assigns DBI/DBX prefix scannable barcode for deposit
            </p>

            <div className="relative flex py-1 items-center">
              <div className="grow border-t border-neutral-200"></div>
              <span className="shrink mx-2 text-[10px] text-neutral-400 uppercase font-semibold">OR</span>
              <div className="grow border-t border-neutral-200"></div>
            </div>

            {/* Button 2: Close Deposit Bag with entered barcode */}
            <button
              type="button"
              onClick={handleCloseDepositBag}
              className="w-full py-2.5 px-4 bg-neutral-800 hover:bg-neutral-900 text-white font-bold rounded-lg shadow-xs text-xs uppercase tracking-wide flex items-center justify-center gap-2 cursor-pointer transition-colors"
            >
              <Archive size={16} />
              <span>Close Deposit Bag (With Entered Barcode)</span>
            </button>
          </div>
        </div>
      </div>

      {/* Immediate Printable Modal */}
      {closedBagModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 print:p-0 print:static print:bg-white backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full p-6 print:shadow-none print:p-0 print:border-none relative max-h-[92vh] flex flex-col">
            <div className="flex items-center justify-between pb-4 border-b border-neutral-200 shrink-0 print:hidden">
              <div className="flex items-center gap-3">
                <span className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse" />
                <h3 className="font-bold text-neutral-900 text-base">
                  Deposit Bag Closed: <span className="font-mono text-[#c92228]">{closedBagModal.bagBarcode}</span> ({targetSet})
                </h3>
              </div>

              <div className="flex items-center gap-2">
                <div className="bg-neutral-100 p-1 rounded-lg flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => setModalView('label')}
                    className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${
                      modalView === 'label'
                        ? 'bg-white text-neutral-900 shadow-xs'
                        : 'text-neutral-600 hover:text-neutral-900'
                    }`}
                  >
                    Deposit Bag Label
                  </button>
                  <button
                    type="button"
                    onClick={() => setModalView('manifest')}
                    className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${
                      modalView === 'manifest'
                        ? 'bg-white text-neutral-900 shadow-xs'
                        : 'text-neutral-600 hover:text-neutral-900'
                    }`}
                  >
                    Deposit Manifest
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => setClosedBagModal(null)}
                  className="px-3 py-1.5 bg-neutral-200 hover:bg-neutral-300 text-neutral-800 rounded-lg text-xs font-bold cursor-pointer"
                >
                  Done / Close
                </button>
              </div>
            </div>

            <div className="overflow-y-auto flex-1 py-4">
              {modalView === 'label' ? (
                <PrintableBagLabel bag={closedBagModal} isModal={false} />
              ) : (
                <PrintableManifest bag={closedBagModal} isModal={false} />
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
