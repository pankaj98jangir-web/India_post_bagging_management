import React, { useState, useEffect } from 'react';
import { OfficeName, SetName, UserSession } from '../types';
import { generateRandomUserId, validateUserId } from '../utils/barcode';
import { DopLogo } from './DopLogo';
import { RefreshCw, LogIn, ShieldCheck, Building2, Layers, AlertCircle } from 'lucide-react';

interface LoginModalProps {
  onLogin: (session: UserSession) => void;
  currentSession?: UserSession | null;
}

const OFFICES: OfficeName[] = [
  'Indore RMS L1U',
  'Indore TMO',
  'Indore PH',
  'Indore NSH',
];

const SETS: SetName[] = [
  'SET/1',
  'SET/2',
  'SET/2A',
  'SET/2B',
  'SET/3A',
  'SET/3B',
];

export const LoginModal: React.FC<LoginModalProps> = ({ onLogin, currentSession }) => {
  const [userId, setUserId] = useState<string>('');
  const [officeName, setOfficeName] = useState<OfficeName>('Indore NSH');
  const [setName, setSetName] = useState<SetName>('SET/1');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (currentSession && /^\d{8}$/.test(currentSession.userId)) {
      setUserId(currentSession.userId);
      setOfficeName(currentSession.officeName);
      setSetName(currentSession.setName);
    } else {
      setUserId(generateRandomUserId());
    }
  }, [currentSession]);

  const handleRefreshId = () => {
    setUserId(generateRandomUserId());
    setError(null);
  };

  const handleUserIdChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Strictly numeric, maximum 8 digits
    const numericOnly = e.target.value.replace(/\D/g, '').slice(0, 8);
    setUserId(numericOnly);
    if (error) setError(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validation = validateUserId(userId);
    if (!validation.isValid) {
      setError(validation.error || 'User ID must be an 8-digit number.');
      return;
    }

    onLogin({
      userId: userId.trim(),
      officeName,
      setName,
      loginTime: new Date().toLocaleString('en-IN'),
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-neutral-900/80 backdrop-blur-xs p-4">
      <div className="bg-white rounded-2xl shadow-2xl border border-neutral-200 max-w-md w-full overflow-hidden">
        {/* Top DOP Banner */}
        <div className="bg-[#c92228] px-6 py-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-1.5 bg-white/10 rounded-md">
              <DopLogo size={38} className="text-white" />
            </div>
            <div>
              <p className="text-[11px] font-medium tracking-wide uppercase opacity-90 text-amber-200">
                Department of Posts (MNOP)
              </p>
              <h2 className="text-lg font-bold leading-tight">
                Bagging Operations Portal
              </h2>
            </div>
          </div>
          <div className="p-2 bg-white/15 rounded-full text-white">
            <ShieldCheck size={20} />
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          <div className="text-xs text-neutral-500 pb-1 border-b border-neutral-100">
            Please verify your 8-digit Operator ID, working postal office, and active duty set to start bagging operations.
          </div>

          {/* User ID (8-Digit Numeric) */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider">
                Operator / User ID (8-Digit Number) *
              </label>
              <span className="text-[10px] font-mono text-neutral-500 font-semibold">
                {userId.length}/8 Digits
              </span>
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                inputMode="numeric"
                pattern="[0-9]{8}"
                maxLength={8}
                value={userId}
                onChange={handleUserIdChange}
                required
                placeholder="e.g. 10048219"
                className="flex-1 px-3 py-2.5 bg-neutral-50 border border-neutral-300 rounded-lg text-sm font-mono font-bold tracking-widest text-neutral-900 focus:outline-hidden focus:ring-2 focus:ring-[#c92228] focus:border-transparent"
              />
              <button
                type="button"
                onClick={handleRefreshId}
                title="Generate New 8-Digit ID"
                className="px-3 py-2 bg-neutral-100 hover:bg-neutral-200 text-neutral-700 border border-neutral-300 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <RefreshCw size={14} />
                <span>New 8-Digit ID</span>
              </button>
            </div>
            {error ? (
              <p className="text-xs text-red-600 font-medium mt-1.5 flex items-center gap-1">
                <AlertCircle size={14} />
                <span>{error}</span>
              </p>
            ) : (
              <p className="text-[11px] text-neutral-500 mt-1 font-medium">
                Standard MNOP Operator ID: exactly 8 numeric digits (e.g., 10048219).
              </p>
            )}
          </div>

          {/* Office Name Dropdown */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <Building2 size={14} className="text-neutral-500" />
              Office Name (Working Postal Unit)
            </label>
            <select
              value={officeName}
              onChange={(e) => setOfficeName(e.target.value as OfficeName)}
              className="w-full px-3 py-2.5 bg-neutral-50 border border-neutral-300 rounded-lg text-sm font-semibold text-neutral-900 focus:outline-hidden focus:ring-2 focus:ring-[#c92228]"
            >
              {OFFICES.map((off) => (
                <option key={off} value={off}>
                  {off}
                </option>
              ))}
            </select>
          </div>

          {/* Set Name Dropdown */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <Layers size={14} className="text-neutral-500" />
              Set Name (Duty / Shift)
            </label>
            <select
              value={setName}
              onChange={(e) => setSetName(e.target.value as SetName)}
              className="w-full px-3 py-2.5 bg-neutral-50 border border-neutral-300 rounded-lg text-sm font-semibold text-neutral-900 focus:outline-hidden focus:ring-2 focus:ring-[#c92228]"
            >
              {SETS.map((set) => (
                <option key={set} value={set}>
                  {set}
                </option>
              ))}
            </select>
          </div>

          {/* Submit / Login Button */}
          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3 px-4 bg-[#c92228] hover:bg-[#a01217] text-white font-bold rounded-lg shadow-md transition-all flex items-center justify-center gap-2 text-sm uppercase tracking-wide cursor-pointer"
            >
              <LogIn size={18} />
              <span>Login to Bagging Operations</span>
            </button>
          </div>

          <p className="text-[11px] text-center text-neutral-500">
            India Post — Central Mail Processing & Transit Management System
          </p>
        </form>
      </div>
    </div>
  );
};
