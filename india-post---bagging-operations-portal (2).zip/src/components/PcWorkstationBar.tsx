import React, { useState, useEffect } from 'react';
import {
  Monitor,
  Barcode,
  Volume2,
  VolumeX,
  Maximize2,
  Minimize2,
  Keyboard,
  Clock,
  Printer,
  Sparkles,
  SlidersHorizontal,
  Shrink,
  Expand,
  PlayCircle,
  StopCircle,
  Archive,
} from 'lucide-react';
import { UserSession, ShiftRecord } from '../types';
import { formatIndianDate } from '../utils/shiftStorage';

interface PcWorkstationBarProps {
  session?: UserSession;
  officeName?: string;
  setName?: string;
  isSoundEnabled: boolean;
  onToggleSound: () => void;
  isCompactMode: boolean;
  onToggleCompact?: () => void;
  onToggleCompactMode?: () => void;
  isWidescreen: boolean;
  onToggleWidescreen: () => void;
  onOpenShortcuts: () => void;
  onToggleFullscreen?: () => void;
  activeShift?: ShiftRecord | null;
  onOpenShiftBegin?: () => void;
  onOpenShiftEnd?: () => void;
  onOpenShiftHistory?: () => void;
  savedShiftsCount?: number;
}

export const PcWorkstationBar: React.FC<PcWorkstationBarProps> = ({
  session,
  officeName: propOffice,
  setName: propSet,
  isSoundEnabled,
  onToggleSound,
  isCompactMode,
  onToggleCompact,
  onToggleCompactMode,
  isWidescreen,
  onToggleWidescreen,
  onOpenShortcuts,
  onToggleFullscreen,
  activeShift,
  onOpenShiftBegin,
  onOpenShiftEnd,
  onOpenShiftHistory,
  savedShiftsCount = 0,
}) => {
  const officeName = propOffice || session?.officeName || 'Indore NSH';
  const setName = propSet || session?.setName || 'SET/1';
  const handleToggleCompact = onToggleCompact || onToggleCompactMode || (() => {});

  const [timeStr, setTimeStr] = useState<string>('');
  const [isCapsLockOn, setIsCapsLockOn] = useState<boolean>(false);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  // Live postal clock
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const options: Intl.DateTimeFormatOptions = {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true,
      };
      setTimeStr(`${now.toLocaleDateString('en-IN', options)} IST`);
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  // Monitor CapsLock status across keydown/keyup
  useEffect(() => {
    const handleKeyStatus = (e: KeyboardEvent) => {
      if (typeof e.getModifierState === 'function') {
        setIsCapsLockOn(e.getModifierState('CapsLock'));
      }
    };
    window.addEventListener('keydown', handleKeyStatus);
    window.addEventListener('keyup', handleKeyStatus);
    return () => {
      window.removeEventListener('keydown', handleKeyStatus);
      window.removeEventListener('keyup', handleKeyStatus);
    };
  }, []);

  // Fullscreen state listener
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
  };

  return (
    <div className="bg-neutral-900 text-neutral-300 border-b border-neutral-800 text-[11px] px-3 sm:px-6 py-1.5 flex flex-wrap items-center justify-between gap-2 select-none print:hidden">
      {/* Left: Terminal & Hardware Status */}
      <div className="flex items-center flex-wrap gap-2.5">
        {/* Terminal Station Identity */}
        <div className="flex items-center gap-1.5 text-neutral-200">
          <Monitor size={13} className="text-red-400" />
          <span className="font-mono font-bold tracking-tight">PC-WS/04</span>
          <span className="text-neutral-500">|</span>
          <span className="text-neutral-400 font-semibold">{officeName} ({setName})</span>
        </div>

        {/* USB Barcode Scanner Status */}
        <div className="hidden sm:flex items-center gap-1.5 bg-neutral-800/80 px-2 py-0.5 rounded border border-neutral-700">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <Barcode size={12} className="text-neutral-400" />
          <span className="font-mono text-[10px] text-neutral-300">SCANNER: READY</span>
        </div>

        {/* Printer Status */}
        <div className="hidden md:flex items-center gap-1.5 bg-neutral-800/80 px-2 py-0.5 rounded border border-neutral-700 text-neutral-400">
          <Printer size={12} className="text-neutral-400" />
          <span className="font-mono text-[10px]">PRINT: 70x120 / A4 READY</span>
        </div>

        {/* Caps Lock Indicator */}
        <div
          className={`flex items-center gap-1 px-1.5 py-0.5 rounded font-mono text-[10px] font-bold border transition-colors ${
            isCapsLockOn
              ? 'bg-amber-950/80 text-amber-300 border-amber-600'
              : 'bg-neutral-800/60 text-neutral-400 border-neutral-700'
          }`}
          title={isCapsLockOn ? 'Caps Lock is ON' : 'Caps Lock is OFF'}
        >
          <span>CAPS:</span>
          <span>{isCapsLockOn ? 'ON' : 'OFF'}</span>
        </div>

        {/* Live Shift Status & Shift Buttons */}
        {activeShift ? (
          <div className="flex items-center gap-1.5">
            <div className="flex items-center gap-1.5 bg-emerald-950/90 border border-emerald-600/80 px-2 py-0.5 rounded text-emerald-300 font-mono text-[10px]">
              <span className="relative flex h-1.5 w-1.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
              </span>
              <span>SHIFT: {formatIndianDate(activeShift.shiftDate)} ({activeShift.setName})</span>
            </div>

            {onOpenShiftEnd && (
              <button
                type="button"
                onClick={onOpenShiftEnd}
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-[#c92228] hover:bg-[#a01217] text-white transition-colors cursor-pointer border border-red-600 shadow-2xs"
                title="End current shift and save data to local storage"
              >
                <StopCircle size={11} />
                <span>SHIFT END</span>
              </button>
            )}
          </div>
        ) : (
          <div className="flex items-center gap-1.5">
            <span className="text-neutral-500 font-mono text-[10px] hidden xl:inline">
              NO ACTIVE SHIFT
            </span>
            {onOpenShiftBegin && (
              <button
                type="button"
                onClick={onOpenShiftBegin}
                className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-[10px] font-bold bg-emerald-700 hover:bg-emerald-600 text-white transition-colors cursor-pointer border border-emerald-500 shadow-2xs"
                title="Start a new fresh shift on the date"
              >
                <PlayCircle size={11} />
                <span>SHIFT BEGIN</span>
              </button>
            )}
          </div>
        )}

        {/* Saved Shifts History */}
        {onOpenShiftHistory && (
          <button
            type="button"
            onClick={onOpenShiftHistory}
            className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-neutral-800/90 hover:bg-neutral-700 text-neutral-300 hover:text-white border border-neutral-700 transition-colors cursor-pointer"
            title="View shifts saved in local storage"
          >
            <Archive size={11} className="text-amber-400" />
            <span className="hidden sm:inline">SAVED SHIFTS</span>
            {savedShiftsCount > 0 && (
              <span className="bg-amber-400 text-neutral-950 px-1 py-0 rounded text-[9px] font-mono font-bold">
                {savedShiftsCount}
              </span>
            )}
          </button>
        )}
      </div>

      {/* Right: Live Clock & PC Controls */}
      <div className="flex items-center flex-wrap gap-2">
        {/* Live Clock */}
        <div className="hidden lg:flex items-center gap-1.5 font-mono text-neutral-400 bg-neutral-800/60 px-2 py-0.5 rounded border border-neutral-700">
          <Clock size={12} className="text-neutral-400" />
          <span>{timeStr}</span>
        </div>

        {/* Scanner Audio Sound Toggle (F9) */}
        <button
          type="button"
          onClick={onToggleSound}
          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold transition-colors cursor-pointer border ${
            isSoundEnabled
              ? 'bg-neutral-800 text-emerald-400 border-emerald-900 hover:bg-neutral-700'
              : 'bg-neutral-800 text-neutral-400 border-neutral-700 hover:text-neutral-200'
          }`}
          title="Toggle Barcode Scanner Audio Beep (F9)"
        >
          {isSoundEnabled ? <Volume2 size={12} /> : <VolumeX size={12} />}
          <span>BEEP: {isSoundEnabled ? 'ON' : 'OFF'}</span>
          <kbd className="text-[9px] font-mono text-neutral-400 bg-neutral-900 px-1 rounded">F9</kbd>
        </button>

        {/* Density Toggle (F8) */}
        <button
          type="button"
          onClick={onToggleCompactMode}
          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold transition-colors cursor-pointer border ${
            isCompactMode
              ? 'bg-neutral-800 text-amber-300 border-amber-900 hover:bg-neutral-700'
              : 'bg-neutral-800 text-neutral-300 border-neutral-700 hover:text-white'
          }`}
          title="Toggle Compact PC Table Density (F8)"
        >
          <SlidersHorizontal size={11} />
          <span>{isCompactMode ? 'COMPACT PC' : 'COMFORT'}</span>
          <kbd className="text-[9px] font-mono text-neutral-400 bg-neutral-900 px-1 rounded">F8</kbd>
        </button>

        {/* Widescreen Toggle */}
        <button
          type="button"
          onClick={onToggleWidescreen}
          className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-700 transition-colors cursor-pointer"
          title={isWidescreen ? 'Switch to Standard Width' : 'Switch to Full Widescreen'}
        >
          {isWidescreen ? <Shrink size={11} /> : <Expand size={11} />}
          <span className="hidden sm:inline">{isWidescreen ? 'WIDE' : 'STANDARD'}</span>
        </button>

        {/* Fullscreen Kiosk Mode (F11) */}
        <button
          type="button"
          onClick={toggleFullscreen}
          className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-700 transition-colors cursor-pointer"
          title="Toggle Fullscreen Counter Kiosk (F11)"
        >
          {isFullscreen ? <Minimize2 size={11} /> : <Maximize2 size={11} />}
          <span className="hidden sm:inline">{isFullscreen ? 'EXIT' : 'FULL'}</span>
          <kbd className="text-[9px] font-mono text-neutral-400 bg-neutral-900 px-1 rounded">F11</kbd>
        </button>

        {/* Keyboard Shortcuts Help (F1 / ?) */}
        <button
          type="button"
          onClick={onOpenShortcuts}
          className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-[10px] font-bold bg-red-600 hover:bg-red-700 text-white transition-colors cursor-pointer shadow-2xs"
          title="Show PC Keyboard Shortcuts & Scanner Guide (F1 or ?)"
        >
          <Keyboard size={12} />
          <span>SHORTCUTS</span>
          <kbd className="text-[9px] font-mono bg-red-900/60 px-1 rounded text-white">F1</kbd>
        </button>
      </div>
    </div>
  );
};
