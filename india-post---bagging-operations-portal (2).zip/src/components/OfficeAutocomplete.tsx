import React, { useState, useRef, useEffect } from 'react';
import { PostalOfficeSuggestion } from '../data/postalOffices';
import { getStoredPostalOffices, DIRECTORY_UPDATE_EVENT } from '../utils/postalDirectoryStorage';
import { Search, MapPin, Check, BookOpen, Edit2, PlusCircle } from 'lucide-react';
import { OfficeDirectoryModal } from './OfficeDirectoryModal';

interface OfficeAutocompleteProps {
  value: string;
  onChange: (val: string) => void;
  label?: string;
  placeholder?: string;
  disabled?: boolean;
  required?: boolean;
  className?: string;
  id?: string;
  onOpenDirectoryManager?: () => void;
}

export const OfficeAutocomplete: React.FC<OfficeAutocompleteProps> = ({
  value,
  onChange,
  label,
  placeholder = 'Type to search or enter custom office...',
  disabled = false,
  required = false,
  className = '',
  id,
}) => {
  const [allOffices, setAllOffices] = useState<PostalOfficeSuggestion[]>(getStoredPostalOffices());
  const [isOpen, setIsOpen] = useState(false);
  const [filterText, setFilterText] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  const [isDirectoryOpen, setIsDirectoryOpen] = useState(false);
  const [directoryInitialMode, setDirectoryInitialMode] = useState<'browse' | 'add' | 'manage'>('browse');
  const wrapperRef = useRef<HTMLDivElement | null>(null);

  // Sync with stored postal offices
  useEffect(() => {
    const handleUpdate = () => {
      setAllOffices(getStoredPostalOffices());
    };
    window.addEventListener(DIRECTORY_UPDATE_EVENT, handleUpdate);
    return () => window.removeEventListener(DIRECTORY_UPDATE_EVENT, handleUpdate);
  }, []);

  // Close suggestions if clicked outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const suggestions: PostalOfficeSuggestion[] = allOffices.filter((item) => {
    // Check category filter
    if (categoryFilter !== 'ALL') {
      if (categoryFilter === 'INDORE_GPO_SO' && item.parentHO !== 'Indore GPO') return false;
      if (categoryFilter === 'REGION_SO' && item.category !== 'Indore Region SO' && item.category !== 'Indore Division SO') return false;
      if (categoryFilter === 'HO' && item.category !== 'Head Office') return false;
      if (categoryFilter === 'RMS' && item.category !== 'Indore RMS / TMO') return false;
      if (categoryFilter === 'NSH_PH' && item.category !== 'NSH' && item.category !== 'PH') return false;
    }

    const q = (filterText || value || '').toLowerCase().trim();
    if (!q) return true;

    return (
      item.name.toLowerCase().includes(q) ||
      (item.pincode && item.pincode.includes(q)) ||
      (item.parentHO && item.parentHO.toLowerCase().includes(q)) ||
      (item.division && item.division.toLowerCase().includes(q)) ||
      item.category.toLowerCase().includes(q)
    );
  }).slice(0, 50); // limit for swift DOM render

  const handleSelect = (officeName: string) => {
    onChange(officeName);
    setFilterText('');
    setIsOpen(false);
  };

  return (
    <div className={`relative ${className}`} ref={wrapperRef}>
      {label && (
        <div className="flex items-center justify-between mb-1.5 flex-wrap gap-1">
          <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider">
            {label}
          </label>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                setDirectoryInitialMode('browse');
                setIsDirectoryOpen(true);
              }}
              className="text-[11px] text-neutral-600 hover:text-neutral-900 font-bold flex items-center gap-1 cursor-pointer hover:underline"
              title="Browse all registered offices"
            >
              <BookOpen size={12} />
              <span>Browse ({allOffices.length})</span>
            </button>
            <span className="text-neutral-300">•</span>
            <button
              type="button"
              onClick={() => {
                setDirectoryInitialMode('add');
                setIsDirectoryOpen(true);
              }}
              className="text-[11px] text-[#c92228] hover:text-red-800 font-bold flex items-center gap-1 cursor-pointer hover:underline"
              title="Add or update office and PIN code"
            >
              <PlusCircle size={12} />
              <span>Update / Add Office & PIN</span>
            </button>
          </div>
        </div>
      )}

      <div className="relative">
        <input
          id={id}
          type="text"
          value={value}
          disabled={disabled}
          required={required}
          placeholder={placeholder}
          onFocus={() => {
            setFilterText('');
            setIsOpen(true);
          }}
          onChange={(e) => {
            onChange(e.target.value);
            setFilterText(e.target.value);
            setIsOpen(true);
          }}
          className="w-full pl-9 pr-14 py-2.5 bg-neutral-50 border border-neutral-300 rounded-lg text-sm font-semibold text-neutral-900 focus:outline-hidden focus:ring-2 focus:ring-[#c92228] focus:bg-white"
        />
        <MapPin
          size={16}
          className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 pointer-events-none"
        />
        <div className="absolute right-2.5 top-1/2 -translate-y-1/2 flex items-center gap-1">
          {value && (
            <button
              type="button"
              onClick={() => {
                onChange('');
                setFilterText('');
              }}
              className="text-neutral-400 hover:text-neutral-600 text-xs font-bold p-1"
              title="Clear entry"
            >
              ×
            </button>
          )}
          <button
            type="button"
            onClick={() => setIsDirectoryOpen(true)}
            className="p-1 text-neutral-400 hover:text-[#c92228] transition-colors"
            title="Browse Indore Region Directory"
          >
            <BookOpen size={14} />
          </button>
        </div>
      </div>

      {/* Autocomplete Dropdown List */}
      {isOpen && !disabled && (
        <div className="absolute z-40 left-0 right-0 mt-1 max-h-80 overflow-y-auto bg-white border border-neutral-300 rounded-xl shadow-2xl divide-y divide-neutral-100">
          {/* Header & Quick Filter Pills */}
          <div className="p-2.5 bg-neutral-50 border-b border-neutral-200">
            <div className="flex items-center justify-between text-[10px] uppercase font-bold text-neutral-500 tracking-wider mb-2">
              <span>Postal Office Suggestions ({suggestions.length})</span>
              <button
                type="button"
                onMouseDown={(e) => {
                  e.preventDefault();
                  setIsDirectoryOpen(true);
                  setIsOpen(false);
                }}
                className="text-[#c92228] font-bold hover:underline cursor-pointer flex items-center gap-1"
              >
                <span>Full Directory</span>
                <ChevronIcon />
              </button>
            </div>

            {/* Quick Filter Tabs */}
            <div className="flex items-center gap-1 overflow-x-auto pb-0.5 text-[10px]">
              <button
                type="button"
                onMouseDown={(e) => {
                  e.preventDefault();
                  setCategoryFilter('ALL');
                }}
                className={`px-2 py-0.5 rounded font-bold transition-colors cursor-pointer ${
                  categoryFilter === 'ALL'
                    ? 'bg-neutral-800 text-white'
                    : 'bg-white border border-neutral-200 text-neutral-600 hover:bg-neutral-100'
                }`}
              >
                All ({allOffices.length})
              </button>
              <button
                type="button"
                onMouseDown={(e) => {
                  e.preventDefault();
                  setCategoryFilter('INDORE_GPO_SO');
                }}
                className={`px-2 py-0.5 rounded font-bold transition-colors cursor-pointer ${
                  categoryFilter === 'INDORE_GPO_SO'
                    ? 'bg-[#c92228] text-white'
                    : 'bg-white border border-neutral-200 text-neutral-600 hover:bg-neutral-100'
                }`}
              >
                Indore GPO SOs
              </button>
              <button
                type="button"
                onMouseDown={(e) => {
                  e.preventDefault();
                  setCategoryFilter('REGION_SO');
                }}
                className={`px-2 py-0.5 rounded font-bold transition-colors cursor-pointer ${
                  categoryFilter === 'REGION_SO'
                    ? 'bg-blue-600 text-white'
                    : 'bg-white border border-neutral-200 text-neutral-600 hover:bg-neutral-100'
                }`}
              >
                All Region SOs
              </button>
              <button
                type="button"
                onMouseDown={(e) => {
                  e.preventDefault();
                  setCategoryFilter('HO');
                }}
                className={`px-2 py-0.5 rounded font-bold transition-colors cursor-pointer ${
                  categoryFilter === 'HO'
                    ? 'bg-amber-600 text-white'
                    : 'bg-white border border-neutral-200 text-neutral-600 hover:bg-neutral-100'
                }`}
              >
                Head Offices (HO)
              </button>
              <button
                type="button"
                onMouseDown={(e) => {
                  e.preventDefault();
                  setCategoryFilter('RMS');
                }}
                className={`px-2 py-0.5 rounded font-bold transition-colors cursor-pointer ${
                  categoryFilter === 'RMS'
                    ? 'bg-emerald-600 text-white'
                    : 'bg-white border border-neutral-200 text-neutral-600 hover:bg-neutral-100'
                }`}
              >
                RMS / TMO
              </button>
              <button
                type="button"
                onMouseDown={(e) => {
                  e.preventDefault();
                  setCategoryFilter('NSH_PH');
                }}
                className={`px-2 py-0.5 rounded font-bold transition-colors cursor-pointer ${
                  categoryFilter === 'NSH_PH'
                    ? 'bg-purple-600 text-white'
                    : 'bg-white border border-neutral-200 text-neutral-600 hover:bg-neutral-100'
                }`}
              >
                NSH / PH
              </button>
            </div>
          </div>

          {/* Suggestions List */}
          {suggestions.length === 0 ? (
            <div className="p-4 text-xs text-neutral-500 text-center">
              No direct matches found. You can keep your custom entry "{value}".
            </div>
          ) : (
            suggestions.map((item) => {
              const isSelected = value === item.name;
              return (
                <button
                  key={item.name}
                  type="button"
                  onMouseDown={(e) => {
                    e.preventDefault();
                    handleSelect(item.name);
                  }}
                  className={`w-full text-left px-3.5 py-2.5 text-xs flex items-center justify-between hover:bg-red-50/70 transition-colors cursor-pointer ${
                    isSelected ? 'bg-red-50 font-bold text-[#c92228]' : 'text-neutral-800'
                  }`}
                >
                  <div className="min-w-0 pr-2">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-neutral-900 truncate">{item.name}</span>
                      {item.pincode && (
                        <span className="text-[10px] font-mono bg-neutral-100 px-1.5 py-0.2 rounded text-neutral-600 shrink-0">
                          {item.pincode}
                        </span>
                      )}
                    </div>
                    {item.parentHO && (
                      <div className="text-[10px] text-neutral-500 mt-0.5 flex items-center gap-1.5">
                        <span className="font-semibold text-neutral-700">HO: {item.parentHO}</span>
                        {item.division && (
                          <span className="text-neutral-400">• {item.division}</span>
                        )}
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <span
                      className={`text-[9px] px-1.5 py-0.5 rounded font-medium whitespace-nowrap ${
                        item.category === 'Indore Division SO'
                          ? 'bg-blue-100 text-blue-800'
                          : item.category === 'Indore Region SO'
                          ? 'bg-sky-100 text-sky-800'
                          : item.category === 'Head Office'
                          ? 'bg-amber-100 text-amber-900 font-bold'
                          : item.category === 'NSH'
                          ? 'bg-purple-100 text-purple-800'
                          : item.category === 'PH'
                          ? 'bg-emerald-100 text-emerald-800'
                          : item.category === 'Indore RMS / TMO'
                          ? 'bg-rose-100 text-rose-800 font-semibold'
                          : 'bg-neutral-100 text-neutral-700'
                      }`}
                    >
                      {item.category}
                    </span>
                    {isSelected && <Check size={14} className="text-[#c92228]" />}
                  </div>
                </button>
              );
            })
          )}
          {/* Bottom quick manage action */}
          <div className="p-2 bg-neutral-50 border-t border-neutral-200 flex items-center justify-between text-xs">
            <span className="text-[11px] text-neutral-500 font-medium">
              Can't find your office or want to change PIN?
            </span>
            <button
              type="button"
              onMouseDown={(e) => {
                e.preventDefault();
                setDirectoryInitialMode('add');
                setIsDirectoryOpen(true);
                setIsOpen(false);
              }}
              className="text-[11px] font-bold text-[#c92228] hover:underline cursor-pointer flex items-center gap-1"
            >
              <PlusCircle size={13} />
              <span>+ Add / Update Office</span>
            </button>
          </div>
        </div>
      )}

      {/* Region Directory Modal */}
      <OfficeDirectoryModal
        isOpen={isDirectoryOpen}
        onClose={() => setIsDirectoryOpen(false)}
        selectedOffice={value}
        initialMode={directoryInitialMode}
        onSelectOffice={(officeName) => {
          onChange(officeName);
          setFilterText('');
        }}
      />
    </div>
  );
};

const ChevronIcon = () => (
  <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
  </svg>
);
