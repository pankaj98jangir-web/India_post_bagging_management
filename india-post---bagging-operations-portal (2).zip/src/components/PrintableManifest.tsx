import React, { useState } from 'react';
import { BarcodeRenderer } from './BarcodeRenderer';
import { DopLogo } from './DopLogo';
import { BagRecord } from '../types';
import { Printer, X, ShieldCheck, FileSpreadsheet, FileText, Download, Loader2 } from 'lucide-react';
import { exportArticlesToExcel } from '../utils/excelExport';
import { generateDocumentPdf, printIsolatedElement, GeneratedPdfResult } from '../utils/pdfGenerator';
import { PdfPreviewModal } from './PdfPreviewModal';

interface PrintableManifestProps {
  bag: BagRecord;
  onClose?: () => void;
  isModal?: boolean;
}

export const PrintableManifest: React.FC<PrintableManifestProps> = ({
  bag,
  onClose,
  isModal = false,
}) => {
  const [pdfResult, setPdfResult] = useState<GeneratedPdfResult | null>(null);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [isPdfModalOpen, setIsPdfModalOpen] = useState(false);

  const handlePrint = () => {
    printIsolatedElement('printable-dop-bag-manifest', `Bag Manifest - ${bag.bagBarcode}`);
  };

  const handleOpenPdf = async () => {
    setIsGeneratingPdf(true);
    try {
      const res = await generateDocumentPdf(
        'printable-dop-bag-manifest',
        'manifest',
        `BagManifest_${bag.bagBarcode}.pdf`
      );
      setPdfResult(res);
      setIsPdfModalOpen(true);
    } catch (err) {
      console.error('Failed to generate bag manifest PDF:', err);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  const handleDownloadPdf = async () => {
    setIsGeneratingPdf(true);
    try {
      const res = await generateDocumentPdf(
        'printable-dop-bag-manifest',
        'manifest',
        `BagManifest_${bag.bagBarcode}.pdf`
      );
      res.download();
    } catch (err) {
      console.error('Failed to download bag manifest PDF:', err);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  const handleExportExcel = () => {
    exportArticlesToExcel(
      bag.articles,
      bag.bagBarcode,
      bag.destinationOffice,
      bag.officeName,
      bag.setName
    );
  };

  const articlesList = bag.articles || [];
  const insuredCount = articlesList.filter((a) => a.isInsured).length || bag.insuredCount || 0;
  const totalCount = Math.max(articlesList.length, bag.totalArticlesCount || 0);
  const normalCount = Math.max(0, totalCount - insuredCount);

  // Group articles into pairs for 4-column layout to save paper:
  // Col 1: Article Barcode | Col 2: Insured | Col 3: Article Barcode | Col 4: Insured
  const rowCount = Math.ceil(articlesList.length / 2);
  const pairedRows = Array.from({ length: rowCount }, (_, rowIndex) => {
    const leftIndex = rowIndex * 2;
    const rightIndex = rowIndex * 2 + 1;
    return {
      leftArticle: articlesList[leftIndex],
      leftIndex: leftIndex + 1,
      rightArticle: rightIndex < articlesList.length ? articlesList[rightIndex] : null,
      rightIndex: rightIndex + 1,
    };
  });

  const content = (
    <div
      id="printable-dop-bag-manifest"
      className="bg-white text-neutral-900 border border-neutral-300 rounded-lg p-7 mx-auto shadow-sm print:border-none print:shadow-none print:p-2 print:m-0 w-full"
      style={{
        maxWidth: '210mm', // Standard A4 width
        minHeight: '297mm', // Standard A4 height
        boxSizing: 'border-box',
      }}
    >
      {/* Official Government Header */}
      <div className="flex items-center justify-between border-b-2 border-neutral-900 pb-3 mb-3">
        <DopLogo size={42} />
        <div className="text-center">
          <h1 className="text-base font-black tracking-wider uppercase text-neutral-900">
            DEPARTMENT OF POSTS, INDIA
          </h1>
          <h2 className="text-xs font-bold text-neutral-800 uppercase tracking-wide">
            MAIL NETWORK OPTIMIZATION PROJECT (MNOP) — BAG MANIFEST (A4)
          </h2>
          <p className="text-[10px] text-neutral-500 mt-0.5">
            Form M-52 / MNOP Bag Delivery & Transmission Bill
          </p>
        </div>
        <div className="text-right leading-tight">
          <span className="text-[9px] font-bold bg-neutral-900 text-white px-2 py-0.5 rounded-xs">
            ORIGINAL COPY
          </span>
          <p className="text-[11px] font-mono font-bold mt-1 text-neutral-800">
            {bag.receivedAt || bag.closedAt || new Date().toLocaleString('en-IN')}
          </p>
        </div>
      </div>

      {/* Bag Details Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5 bg-neutral-50 border border-neutral-300 rounded-md p-3 mb-3 text-xs">
        <div>
          <span className="text-[9.5px] font-bold text-neutral-500 uppercase block">Bag Barcode No.</span>
          <span className="font-mono font-black text-xs text-neutral-900">{bag.bagBarcode}</span>
        </div>
        <div>
          <span className="text-[9.5px] font-bold text-neutral-500 uppercase block">Origin Office</span>
          <span className="font-bold text-neutral-900">{bag.sourceOffice || bag.officeName}</span>
        </div>
        <div>
          <span className="text-[9.5px] font-bold text-neutral-500 uppercase block">Destination Office</span>
          <span className="font-bold text-[#c92228]">{bag.destinationOffice}</span>
        </div>
        <div>
          <span className="text-[9.5px] font-bold text-neutral-500 uppercase block">Duty Set & Office</span>
          <span className="font-bold text-neutral-900">{bag.setName} ({bag.officeName})</span>
        </div>
        <div>
          <span className="text-[9.5px] font-bold text-neutral-500 uppercase block">Bag Status</span>
          <span className="font-bold uppercase text-neutral-800">{bag.bagStatus}</span>
        </div>
        <div>
          <span className="text-[9.5px] font-bold text-neutral-500 uppercase block">Bag Weight</span>
          <span className="font-bold text-neutral-900">
            {bag.bagWeightKg ? `${bag.bagWeightKg.toFixed(3)} KG` : '2.450 KG'}
          </span>
        </div>
        <div>
          <span className="text-[9.5px] font-bold text-neutral-500 uppercase block">Normal Articles</span>
          <span className="font-bold text-neutral-900">{normalCount}</span>
        </div>
        <div>
          <span className="text-[9.5px] font-bold text-neutral-500 uppercase block">Insured Articles</span>
          <span className="font-bold text-amber-700 flex items-center gap-1">
            <ShieldCheck size={12} /> {insuredCount}
          </span>
        </div>
      </div>

      {/* Bag Barcode Graphic */}
      <div className="flex flex-col items-center justify-center p-1.5 mb-3 bg-white border border-dashed border-neutral-300 rounded shrink-0">
        <BarcodeRenderer value={bag.bagBarcode} width={2} height={42} fontSize={13} />
      </div>

      {/* Articles Manifest Section with Top Right Articles Description */}
      <div className="mb-4">
        {/* Section Header with Articles Description on Top Right Corner */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2 pb-1 border-b border-neutral-200">
          <div>
            <h3 className="text-xs font-black text-neutral-900 uppercase tracking-wider">
              Enclosed Articles Manifest
            </h3>
            <p className="text-[10px] text-neutral-500">
              Compact 4-column paper-saving layout (Article Barcode | Insured)
            </p>
          </div>

          {/* Top Right Corner: Articles Description (Normal, Insured, Total) */}
          <div className="flex items-center gap-2 bg-neutral-100 border border-neutral-300 px-3 py-1.5 rounded-md self-start sm:self-auto text-xs">
            <span className="text-neutral-500 font-bold uppercase text-[9.5px]">Articles Summary:</span>
            <div className="flex items-center gap-2 font-mono font-bold">
              <span className="bg-white px-2 py-0.5 rounded text-neutral-800 border border-neutral-200">
                Normal: <strong className="text-neutral-950">{normalCount}</strong>
              </span>
              <span className="bg-amber-50 px-2 py-0.5 rounded text-amber-800 border border-amber-200">
                Insured: <strong className="text-amber-900">{insuredCount}</strong>
              </span>
              <span className="bg-[#c92228] px-2 py-0.5 rounded text-white font-black">
                Total: {totalCount}
              </span>
            </div>
          </div>
        </div>

        {/* 4-Column Table: Article Barcode | Insured | Article Barcode | Insured */}
        <div className="border border-neutral-300 rounded overflow-hidden">
          <table className="w-full text-xs text-left border-collapse">
            <thead className="bg-neutral-100 text-neutral-800 font-bold border-b border-neutral-300 text-[11px]">
              <tr>
                {/* Stream 1 */}
                <th className="py-2 px-2.5 border-r border-neutral-300 w-[35%]">
                  Article Barcode
                </th>
                <th className="py-2 px-2 border-r-2 border-neutral-400 text-center w-[15%]">
                  Insured
                </th>
                {/* Stream 2 */}
                <th className="py-2 px-2.5 border-r border-neutral-300 w-[35%]">
                  Article Barcode
                </th>
                <th className="py-2 px-2 text-center w-[15%]">
                  Insured
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-200 text-xs">
              {pairedRows.length > 0 ? (
                pairedRows.map((row, rIdx) => (
                  <tr key={rIdx} className="hover:bg-neutral-50">
                    {/* Left Column 1: Article Barcode */}
                    <td className="py-1.5 px-2.5 border-r border-neutral-200 font-mono text-[11.5px] font-bold text-neutral-900">
                      <span className="text-[10px] text-neutral-400 mr-2 font-sans font-normal">
                        {row.leftIndex}.
                      </span>
                      {row.leftArticle.articleNumber}
                      <span className="text-[9.5px] font-sans text-neutral-500 ml-1.5 font-normal">
                        ({row.leftArticle.articleType})
                      </span>
                    </td>

                    {/* Left Column 2: Insured */}
                    <td className="py-1.5 px-2 border-r-2 border-neutral-400 text-center">
                      {row.leftArticle.isInsured ? (
                        <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
                          <ShieldCheck size={10} /> YES
                        </span>
                      ) : (
                        <span className="text-neutral-400 text-[10px]">No</span>
                      )}
                    </td>

                    {/* Right Column 3: Article Barcode */}
                    <td className="py-1.5 px-2.5 border-r border-neutral-200 font-mono text-[11.5px] font-bold text-neutral-900">
                      {row.rightArticle ? (
                        <>
                          <span className="text-[10px] text-neutral-400 mr-2 font-sans font-normal">
                            {row.rightIndex}.
                          </span>
                          {row.rightArticle.articleNumber}
                          <span className="text-[9.5px] font-sans text-neutral-500 ml-1.5 font-normal">
                            ({row.rightArticle.articleType})
                          </span>
                        </>
                      ) : (
                        <span className="text-neutral-300 italic text-[10px]">—</span>
                      )}
                    </td>

                    {/* Right Column 4: Insured */}
                    <td className="py-1.5 px-2 text-center">
                      {row.rightArticle ? (
                        row.rightArticle.isInsured ? (
                          <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
                            <ShieldCheck size={10} /> YES
                          </span>
                        ) : (
                          <span className="text-neutral-400 text-[10px]">No</span>
                        )
                      ) : (
                        <span className="text-neutral-300 text-[10px]">—</span>
                      )}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={4} className="p-4 text-center text-neutral-500 italic">
                    Bulk enclosed mail (Expected Articles Count: {bag.totalArticlesCount})
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Signature & Verification Block */}
      <div className="grid grid-cols-3 gap-4 pt-4 border-t-2 border-neutral-900 text-xs text-center">
        <div>
          <div className="h-9 flex items-end justify-center font-serif italic text-neutral-400 text-xs">
            [Signature]
          </div>
          <div className="border-t border-dashed border-neutral-400 pt-1 font-bold text-neutral-800 text-[11px]">
            Sorting Assistant (SA)
          </div>
          <div className="text-[9.5px] text-neutral-500">{bag.officeName}</div>
        </div>

        <div>
          <div className="h-9 flex items-end justify-center font-serif italic text-neutral-400 text-xs">
            [Set Round Stamp]
          </div>
          <div className="border-t border-dashed border-neutral-400 pt-1 font-bold text-neutral-800 text-[11px]">
            Date & Set Round Stamp
          </div>
          <div className="text-[9.5px] text-neutral-500">{bag.setName}</div>
        </div>

        <div>
          <div className="h-9 flex items-end justify-center font-serif italic text-neutral-400 text-xs">
            [Signature]
          </div>
          <div className="border-t border-dashed border-neutral-400 pt-1 font-bold text-neutral-800 text-[11px]">
            Supervisor / HSA
          </div>
          <div className="text-[9.5px] text-neutral-500">Department of Posts</div>
        </div>
      </div>
    </div>
  );

  const actionButtons = (
    <div className="flex items-center gap-2 print:hidden flex-wrap">
      <button
        type="button"
        disabled={isGeneratingPdf}
        onClick={handleOpenPdf}
        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-900 hover:bg-black text-white text-xs font-bold transition-colors cursor-pointer shadow-xs disabled:opacity-50"
        title="Open Bag Manifest in PDF viewer (Only Bag Manifest, no web page UI)"
      >
        {isGeneratingPdf ? <Loader2 size={14} className="animate-spin" /> : <FileText size={14} className="text-amber-400" />}
        <span>Open in PDF</span>
      </button>

      <button
        type="button"
        disabled={isGeneratingPdf}
        onClick={handleDownloadPdf}
        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-neutral-950 text-xs font-bold transition-colors cursor-pointer shadow-xs disabled:opacity-50"
        title="Download Standalone Bag Manifest PDF (A4)"
      >
        <Download size={14} />
        <span>Download PDF</span>
      </button>

      <button
        type="button"
        onClick={handleExportExcel}
        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-emerald-600 bg-emerald-50 text-emerald-800 hover:bg-emerald-100 text-xs font-bold shadow-xs cursor-pointer"
        title="Export Articles list to Excel (.xlsx)"
      >
        <FileSpreadsheet size={14} />
        <span className="hidden sm:inline">Export Excel</span>
      </button>

      <button
        type="button"
        onClick={handlePrint}
        className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-[#c92228] text-white hover:bg-[#a01217] text-xs font-bold uppercase tracking-wider shadow-xs cursor-pointer transition-colors"
        title="Print Bag Manifest (Isolated A4, no web UI)"
      >
        <Printer size={14} />
        <span>Print Manifest (A4)</span>
      </button>
    </div>
  );

  if (!isModal) {
    return (
      <div className="w-full">
        <div className="flex justify-between items-center gap-2 mb-3.5 border-b border-neutral-200 pb-2.5 print:hidden">
          <div className="text-xs text-neutral-600 font-medium">
            Manifest for Bag: <strong className="font-mono text-neutral-900">{bag.bagBarcode}</strong> ({totalCount} Articles)
          </div>
          {actionButtons}
        </div>
        {content}

        <PdfPreviewModal
          isOpen={isPdfModalOpen}
          onClose={() => setIsPdfModalOpen(false)}
          pdfResult={pdfResult}
          docType="manifest"
          title={`Bag Manifest Form M-52: ${bag.bagBarcode}`}
        />
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 print:p-0 print:static print:bg-white backdrop-blur-xs">
      <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full p-6 print:shadow-none print:p-0 print:border-none relative">
        <div className="flex items-center justify-between pb-3 border-b border-neutral-200 mb-4 print:hidden">
          <h3 className="font-bold text-neutral-800 text-base flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-blue-500" />
            Official Department of Posts Bag Manifest (A4 Size)
          </h3>
          <div className="flex items-center gap-2">
            {actionButtons}
            {onClose && (
              <button
                type="button"
                onClick={onClose}
                className="p-1 rounded-md text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 cursor-pointer ml-1"
              >
                <X size={18} />
              </button>
            )}
          </div>
        </div>

        <div className="overflow-auto max-h-[82vh] print:max-h-none py-2 flex justify-center">
          {content}
        </div>
      </div>

      <PdfPreviewModal
        isOpen={isPdfModalOpen}
        onClose={() => setIsPdfModalOpen(false)}
        pdfResult={pdfResult}
        docType="manifest"
        title={`Bag Manifest Form M-52: ${bag.bagBarcode}`}
      />
    </div>
  );
};
