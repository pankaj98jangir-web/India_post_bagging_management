import React, { useEffect } from 'react';
import {
  Keyboard,
  X,
  Barcode,
  Monitor,
  Volume2,
  Maximize,
  ArrowRight,
  Sparkles,
  Layers,
  Printer,
} from 'lucide-react';

interface PcShortcutsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTab?: (tabNumber: number) => void;
}

export const PcShortcutsModal: React.FC<PcShortcutsModalProps> = ({
  isOpen,
  onClose,
  onSelectTab,
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const tabShortcuts = [
    { key: 'Alt + 1', label: 'Bag Receive', desc: 'Scan and log incoming closed bags' },
    { key: 'Alt + 2', label: 'Forwarding Bag Receive', desc: 'Log closed bags in transit' },
    { key: 'Alt + 3', label: 'Bag Open', desc: 'Cut bag seal & verify articles' },
    { key: 'Alt + 4', label: 'Bag Close', desc: 'Package articles & generate EBI/EBX' },
    { key: 'Alt + 5', label: 'Print Bag Manifest', desc: 'Generate paper-saving A4 manifest' },
    { key: 'Alt + 6', label: 'Print Bag Label', desc: 'Format 70mm x 120mm thermal label' },
    { key: 'Alt + 7', label: 'Bag Despatch', desc: 'Issue delivery bill & schedule' },
    { key: 'Alt + 8', label: 'Deposit Bag Close', desc: 'Internal handovers with DBI/DBX' },
    { key: 'Alt + 9', label: 'Received Bags Abstract', desc: 'Shift summary of bags received' },
    { key: 'Alt + 0', label: 'Consolidated Abstract', desc: 'Complete opening & closing matrix' },
    { key: 'Tab 11', label: 'Create Consolidated Abstract', desc: 'Manual entry tables for bags and article details' },
    { key: 'Tab 12', label: 'Generate Barcode', desc: 'Generate 70mm x 120mm isolated PDF bag barcode label' },
  ];

  const operationalShortcuts = [
    { key: 'F4 or Alt + L', label: 'Focus Barcode Scanner', desc: 'Instantly jump cursor into active input' },
    { key: 'Alt + R', label: 'Receive Bag', desc: 'Submit Bag Receive in Sub Tab 1' },
    { key: 'Alt + F', label: 'Receive Forwarding Bag', desc: 'Submit Forwarding in Sub Tab 2' },
    { key: 'Alt + O', label: 'Open Selected Bag', desc: 'Confirm bag opening in Sub Tab 3' },
    { key: 'Alt + C', label: 'Generate & Close Bag', desc: 'Auto-assign barcode and seal bag' },
    { key: 'Alt + D', label: 'Complete Despatch', desc: 'Finalize schedule and despatch bags' },
    { key: 'Alt + P', label: 'Close Deposit Bag', desc: 'Generate DBI/DBX barcode & close' },
    { key: 'Esc', label: 'Dismiss / Close Modal', desc: 'Exit dialogs, popups, and prompts' },
  ];

  const workstationKeys = [
    { key: 'F1 or ?', label: 'Keyboard Shortcuts Help', desc: 'Toggle this cheat sheet' },
    { key: 'F2', label: 'Shift Begin', desc: 'Commence fresh shift on selected date' },
    { key: 'F3', label: 'Shift End', desc: 'Finalize shift & save data to local storage archive' },
    { key: 'F8', label: 'Toggle Compact PC Density', desc: 'Maximize screen rows for 1080p monitors' },
    { key: 'F9', label: 'Toggle Scanner Audio Beep', desc: 'Mute / unmute scanner acoustic feedback' },
    { key: 'F11', label: 'Toggle Fullscreen Kiosk', desc: 'Expand to edge-to-edge counter terminal' },
    { key: 'Enter', label: 'Barcode Scanner Suffix', desc: 'USB Scanners auto-send Enter on 13 digits' },
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-900/70 backdrop-blur-xs animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl shadow-2xl border border-neutral-200 w-full max-w-4xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-neutral-900 via-neutral-800 to-neutral-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-600 flex items-center justify-center text-white shadow-xs">
              <Keyboard size={22} />
            </div>
            <div>
              <h2 className="text-base font-black uppercase tracking-wide flex items-center gap-2">
                <span>PC Keyboard Shortcuts & Scanner Guide</span>
                <span className="text-[10px] font-mono bg-white/20 text-amber-300 px-2 py-0.5 rounded">
                  DESKTOP TERMINAL
                </span>
              </h2>
              <p className="text-xs text-neutral-300">
                Operate the postal counter entirely via physical keyboard and USB barcode scanner
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
            title="Close (Esc)"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-neutral-900">
          {/* Top Info Banner */}
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-3.5 flex items-start gap-3 text-xs text-amber-950">
            <Barcode size={20} className="text-amber-700 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">USB Handheld Barcode Scanner Configuration: </span>
              Standard postal scanners operate as USB HID keyboards. Scanning any 13-digit article or bag barcode automatically enters the code and triggers processing without mouse clicks. Use <kbd className="px-1.5 py-0.5 bg-amber-100 border border-amber-300 rounded font-mono font-bold">F4</kbd> at any time to instantly focus the active scan field.
            </div>
          </div>

          {/* 3 Column Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {/* Column 1: Sub Tab Navigation */}
            <div className="space-y-3">
              <div className="flex items-center gap-2 pb-1 border-b border-neutral-200">
                <Layers size={16} className="text-[#c92228]" />
                <h3 className="text-xs font-black uppercase tracking-wider text-neutral-800">
                  Sub Tab Switching (Alt + 1..0)
                </h3>
              </div>
              <div className="space-y-1.5">
                {tabShortcuts.map((item, idx) => (
                  <button
                    key={item.key}
                    type="button"
                    onClick={() => {
                      if (onSelectTab) onSelectTab(idx + 1);
                      onClose();
                    }}
                    className="w-full text-left p-2 rounded-lg bg-neutral-50 hover:bg-red-50 border border-neutral-200 hover:border-red-200 transition-colors flex items-center justify-between group cursor-pointer"
                  >
                    <div>
                      <div className="text-xs font-bold text-neutral-800 group-hover:text-[#c92228]">
                        {item.label}
                      </div>
                      <div className="text-[10px] text-neutral-500">{item.desc}</div>
                    </div>
                    <kbd className="px-2 py-1 bg-white border border-neutral-300 rounded text-[11px] font-mono font-bold text-neutral-700 shadow-2xs group-hover:border-red-300">
                      {item.key}
                    </kbd>
                  </button>
                ))}
              </div>
            </div>

            {/* Column 2: Operations & Forms */}
            <div className="space-y-3">
              <div className="flex items-center gap-2 pb-1 border-b border-neutral-200">
                <Sparkles size={16} className="text-[#c92228]" />
                <h3 className="text-xs font-black uppercase tracking-wider text-neutral-800">
                  Action & Submit Keys
                </h3>
              </div>
              <div className="space-y-1.5">
                {operationalShortcuts.map((item) => (
                  <div
                    key={item.key}
                    className="p-2 rounded-lg bg-neutral-50 border border-neutral-200 flex items-center justify-between"
                  >
                    <div className="pr-2">
                      <div className="text-xs font-bold text-neutral-800">{item.label}</div>
                      <div className="text-[10px] text-neutral-500">{item.desc}</div>
                    </div>
                    <kbd className="px-2 py-1 bg-white border border-neutral-300 rounded text-[11px] font-mono font-bold text-neutral-700 shadow-2xs shrink-0">
                      {item.key}
                    </kbd>
                  </div>
                ))}
              </div>
            </div>

            {/* Column 3: Workstation & Terminal */}
            <div className="space-y-3">
              <div className="flex items-center gap-2 pb-1 border-b border-neutral-200">
                <Monitor size={16} className="text-[#c92228]" />
                <h3 className="text-xs font-black uppercase tracking-wider text-neutral-800">
                  Terminal Controls
                </h3>
              </div>
              <div className="space-y-1.5">
                {workstationKeys.map((item) => (
                  <div
                    key={item.key}
                    className="p-2 rounded-lg bg-neutral-50 border border-neutral-200 flex items-center justify-between"
                  >
                    <div className="pr-2">
                      <div className="text-xs font-bold text-neutral-800">{item.label}</div>
                      <div className="text-[10px] text-neutral-500">{item.desc}</div>
                    </div>
                    <kbd className="px-2 py-1 bg-white border border-neutral-300 rounded text-[11px] font-mono font-bold text-neutral-700 shadow-2xs shrink-0">
                      {item.key}
                    </kbd>
                  </div>
                ))}

                {/* Print Tips */}
                <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-xl space-y-1.5">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-red-900">
                    <Printer size={14} />
                    <span>PC Printing Setup</span>
                  </div>
                  <p className="text-[11px] text-red-800 leading-relaxed">
                    Set default margins to <strong>None / Minimum</strong> in the Chrome / Edge print dialog.
                    Thermal labels format to <strong>70mm x 120mm</strong> landscape. Manifests auto-format to <strong>A4</strong> portrait.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-neutral-100 border-t border-neutral-200 flex items-center justify-between text-xs text-neutral-600">
          <span>Tip: Press <kbd className="font-mono font-bold bg-white px-1.5 py-0.5 border border-neutral-300 rounded">?</kbd> anywhere on screen to toggle this cheat sheet</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-neutral-800 hover:bg-neutral-900 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer"
          >
            Got It (Esc)
          </button>
        </div>
      </div>
    </div>
  );
};
