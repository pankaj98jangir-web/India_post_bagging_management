import React, { useState } from 'react';
import { UserSession, ShiftRecord } from '../types';
import { DopLogo } from './DopLogo';
import { UserCheck, Building, Building2, LogOut, Layers, PlayCircle, StopCircle, Archive } from 'lucide-react';
import { OfficeDirectoryModal } from './OfficeDirectoryModal';
import { formatIndianDate } from '../utils/shiftStorage';

interface HeaderProps {
  session: UserSession;
  onSwitchSession: () => void;
  activeSubTab: string;
  isWidescreen?: boolean;
  onOpenShortcuts?: () => void;
  activeShift?: ShiftRecord | null;
  onOpenShiftBegin?: () => void;
  onOpenShiftEnd?: () => void;
  onOpenShiftHistory?: () => void;
  savedShiftsCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  session,
  onSwitchSession,
  isWidescreen,
  onOpenShortcuts,
  activeShift,
  onOpenShiftBegin,
  onOpenShiftEnd,
  onOpenShiftHistory,
  savedShiftsCount = 0,
}) => {
  const [isDirectoryOpen, setIsDirectoryOpen] = useState(false);

  return (
    <>
      <header className="bg-white border-b border-neutral-200 shadow-2xs sticky top-0 z-30">
        <div className={`${isWidescreen ? 'max-w-[1720px]' : 'max-w-7xl'} mx-auto px-4 sm:px-6 lg:px-8`}>
          <div className="flex items-center justify-between h-16">
            {/* Logo & Portal Identity */}
            <div className="flex items-center gap-4">
              <DopLogo size={40} />
              <div className="hidden sm:block border-l border-neutral-300 pl-4">
                <h1 className="text-sm font-black tracking-tight text-neutral-900 uppercase leading-none">
                  Bagging Operations
                </h1>
                <p className="text-[11px] font-semibold text-neutral-500 mt-1">
                  Mail Network Optimization Project (MNOP) • PC Counter Workstation
                </p>
              </div>
            </div>

            {/* Active Session Badges & Actions */}
            <div className="flex items-center gap-2 sm:gap-2.5 flex-wrap justify-end">
              {/* Working Office & Set */}
              <div className="hidden lg:flex items-center gap-1.5 bg-neutral-50 border border-neutral-200 px-3 py-1.5 rounded-lg text-xs">
                <Building size={14} className="text-[#c92228]" />
                <span className="font-bold text-neutral-900">{session.officeName}</span>
              </div>

              <div className="hidden md:flex items-center gap-1.5 bg-amber-50 border border-amber-200 px-3 py-1.5 rounded-lg text-xs">
                <Layers size={14} className="text-amber-700" />
                <span className="font-bold text-amber-900">{session.setName}</span>
              </div>

              <div className="hidden xl:flex items-center gap-1.5 bg-neutral-50 border border-neutral-200 px-3 py-1.5 rounded-lg text-xs">
                <UserCheck size={14} className="text-emerald-600" />
                <span className="font-mono font-bold text-neutral-800">{session.userId}</span>
              </div>

              {/* PRIMARY USER ACTIONS: Shift Begin / Shift End */}
              {activeShift ? (
                <div className="flex items-center gap-1.5">
                  <div className="hidden sm:flex items-center gap-1.5 bg-emerald-50 border border-emerald-300 px-2.5 py-1.5 rounded-lg text-xs">
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                    </span>
                    <span className="text-emerald-900 font-bold">
                      Shift: {formatIndianDate(activeShift.shiftDate)}
                    </span>
                  </div>

                  {onOpenShiftEnd && (
                    <button
                      type="button"
                      onClick={onOpenShiftEnd}
                      title="End shift and save data to local storage"
                      className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-[#c92228] hover:bg-[#a01217] text-white rounded-lg text-xs font-bold transition-all shadow-xs cursor-pointer"
                    >
                      <StopCircle size={15} />
                      <span>Shift End</span>
                    </button>
                  )}
                </div>
              ) : (
                onOpenShiftBegin && (
                  <button
                    type="button"
                    onClick={onOpenShiftBegin}
                    title="Start a new fresh shift on the date"
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-[#1b5e20] hover:bg-[#144717] text-white rounded-lg text-xs font-bold transition-all shadow-xs cursor-pointer"
                  >
                    <PlayCircle size={15} />
                    <span>Shift Begin</span>
                  </button>
                )
              )}

              {/* Saved Shifts in Local Storage */}
              {onOpenShiftHistory && (
                <button
                  type="button"
                  onClick={onOpenShiftHistory}
                  title="View all shifts saved in local storage"
                  className="inline-flex items-center gap-1.5 px-2.5 py-1.5 bg-neutral-100 hover:bg-neutral-200 text-neutral-700 rounded-lg text-xs font-semibold transition-colors border border-neutral-200 cursor-pointer"
                >
                  <Archive size={14} className="text-amber-700" />
                  <span className="hidden sm:inline">Saved Shifts</span>
                  {savedShiftsCount > 0 && (
                    <span className="bg-amber-300 text-neutral-900 font-bold px-1.5 py-0.2 rounded-full text-[10px] font-mono">
                      {savedShiftsCount}
                    </span>
                  )}
                </button>
              )}

              {/* Directory Viewer Button */}
              <button
                type="button"
                onClick={() => setIsDirectoryOpen(true)}
                title="View All Head Offices & Sub-Offices under Indore RMS and Postal Region"
                className="inline-flex items-center gap-1.5 px-2.5 py-1.5 bg-red-50 hover:bg-red-100 text-[#c92228] rounded-lg text-xs font-bold transition-colors border border-red-200 cursor-pointer"
              >
                <Building2 size={14} />
                <span className="hidden md:inline">Directory</span>
              </button>

              <button
                onClick={onSwitchSession}
                title="Change Set / Office / User"
                className="inline-flex items-center gap-1.5 px-2.5 py-1.5 bg-neutral-100 hover:bg-neutral-200 text-neutral-700 rounded-lg text-xs font-semibold transition-colors border border-neutral-200 cursor-pointer"
              >
                <LogOut size={14} />
                <span className="hidden sm:inline">Switch</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Region Directory Modal */}
      <OfficeDirectoryModal
        isOpen={isDirectoryOpen}
        onClose={() => setIsDirectoryOpen(false)}
      />
    </>
  );
};
