import React, { useState } from 'react';
import { BarcodeRenderer } from './BarcodeRenderer';
import { DopLogo } from './DopLogo';
import { BagRecord } from '../types';
import { Printer, X, FileText, Download, Loader2 } from 'lucide-react';
import { generateDocumentPdf, printIsolatedElement, GeneratedPdfResult } from '../utils/pdfGenerator';
import { PdfPreviewModal } from './PdfPreviewModal';

interface PrintableBagLabelProps {
  bag: BagRecord;
  onClose?: () => void;
  isModal?: boolean;
}

export const PrintableBagLabel: React.FC<PrintableBagLabelProps> = ({
  bag,
  onClose,
  isModal = false,
}) => {
  const [pdfResult, setPdfResult] = useState<GeneratedPdfResult | null>(null);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [isPdfModalOpen, setIsPdfModalOpen] = useState(false);

  const handlePrint = () => {
    printIsolatedElement('printable-dop-bag-label', `Bag Label - ${bag.bagBarcode}`);
  };

  const handleOpenPdf = async () => {
    setIsGeneratingPdf(true);
    try {
      const res = await generateDocumentPdf(
        'printable-dop-bag-label',
        'label',
        `BagLabel_${bag.bagBarcode}.pdf`
      );
      setPdfResult(res);
      setIsPdfModalOpen(true);
    } catch (err) {
      console.error('Failed to generate bag label PDF:', err);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  const handleDownloadPdf = async () => {
    setIsGeneratingPdf(true);
    try {
      const res = await generateDocumentPdf(
        'printable-dop-bag-label',
        'label',
        `BagLabel_${bag.bagBarcode}.pdf`
      );
      res.download();
    } catch (err) {
      console.error('Failed to download bag label PDF:', err);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  // Dimensions: 120mm Width x 70mm Height, with space on the right side
  const content = (
    <div
      id="printable-dop-bag-label"
      className="bg-white text-neutral-900 border-2 border-neutral-950 rounded-lg p-2.5 pr-6 shadow-md select-none mx-auto box-border flex flex-col justify-between print:border-2 print:border-black print:shadow-none print:m-0 print:rounded-none"
      style={{
        width: '120mm',
        height: '70mm',
        maxWidth: '120mm',
        maxHeight: '70mm',
        paddingRight: '7mm', // Right-side spacing requested
      }}
    >
      {/* Top Header: DOP Logo + Bag Type Badge + Timestamp */}
      <div className="flex items-center justify-between border-b border-neutral-900 pb-1 shrink-0">
        <div className="flex items-center gap-2">
          <DopLogo size={28} />
          <div className="leading-tight">
            <span className="text-[9px] font-black uppercase tracking-wider text-neutral-900 block">
              INDIA POST • D.O.P
            </span>
            <span className="text-[7.5px] font-bold text-neutral-600 block">
              {bag.officeName}
            </span>
          </div>
        </div>

        <div className="text-right leading-none">
          <span className="text-[9px] font-black uppercase tracking-wider bg-neutral-900 text-white px-1.5 py-0.5 rounded-xs inline-block">
            {bag.isDepositBag ? 'DEPOSIT BAG' : 'AIR / SURFACE BAG'}
          </span>
          <span className="text-[8px] font-mono font-bold text-neutral-600 block mt-0.5">
            {bag.receivedAt || bag.closedAt || new Date().toLocaleString('en-IN')}
          </span>
        </div>
      </div>

      {/* Destination Office Box */}
      <div className="bg-neutral-100 border border-neutral-800 rounded px-2 py-1 my-0.5 text-center shrink-0">
        <span className="text-[7.5px] uppercase font-black tracking-widest text-neutral-500 block leading-none">
          TO (DESTINATION OFFICE)
        </span>
        <h2 className="text-sm font-black uppercase text-neutral-950 tracking-tight leading-tight truncate">
          {bag.destinationOffice}
        </h2>
      </div>

      {/* Barcode & Bag Number (Center) */}
      <div className="flex flex-col items-center justify-center my-0.5 shrink-0 bg-white">
        <BarcodeRenderer
          value={bag.bagBarcode}
          width={1.8}
          height={34}
          fontSize={11}
        />
        <div className="flex items-center gap-2 text-[8px] font-mono font-bold text-neutral-600 leading-none mt-0.5">
          <span>STATUS: {bag.bagStatus.toUpperCase()}</span>
          <span>•</span>
          <span>ARTICLES: {bag.totalArticlesCount}</span>
        </div>
      </div>

      {/* Bottom Grid: Origin Office / Set Name on left, Bag Weight on right */}
      <div className="grid grid-cols-2 gap-1 pt-1 border-t border-neutral-900 text-xs shrink-0 leading-tight">
        <div>
          <span className="text-[7px] uppercase font-bold tracking-wider text-neutral-500 block">
            ORIGIN / DUTY SET
          </span>
          <span className="font-bold text-neutral-900 text-[10px] block truncate">
            {bag.sourceOffice || bag.officeName}
          </span>
          <span className="font-black text-[#c92228] text-[9px] block">
            {bag.setName}
          </span>
        </div>

        <div className="text-right flex flex-col justify-end">
          <span className="text-[7px] uppercase font-bold tracking-wider text-neutral-500 block">
            BAG WEIGHT
          </span>
          <span className="text-xs font-black text-neutral-950 block">
            {bag.bagWeightKg ? `${bag.bagWeightKg.toFixed(3)} KG` : '2.450 KG'}
          </span>
        </div>
      </div>
    </div>
  );

  const actionButtons = (
    <div className="flex items-center gap-2 print:hidden flex-wrap">
      <button
        type="button"
        disabled={isGeneratingPdf}
        onClick={handleOpenPdf}
        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-900 hover:bg-black text-white text-xs font-bold transition-colors cursor-pointer shadow-xs disabled:opacity-50"
        title="Open Bag Label in PDF viewer (Only Bag Label, no web page UI)"
      >
        {isGeneratingPdf ? <Loader2 size={14} className="animate-spin" /> : <FileText size={14} className="text-amber-400" />}
        <span>Open in PDF</span>
      </button>

      <button
        type="button"
        disabled={isGeneratingPdf}
        onClick={handleDownloadPdf}
        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-neutral-950 text-xs font-bold transition-colors cursor-pointer shadow-xs disabled:opacity-50"
        title="Download Bag Label as PDF (120mm x 70mm)"
      >
        <Download size={14} />
        <span>Download PDF</span>
      </button>

      <button
        type="button"
        onClick={handlePrint}
        className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-[#c92228] text-white hover:bg-[#a01217] text-xs font-bold uppercase tracking-wider shadow-xs cursor-pointer transition-colors"
        title="Print Official Bag Label (Isolated 120mm x 70mm, no web UI)"
      >
        <Printer size={14} />
        <span>Print Label</span>
      </button>
    </div>
  );

  if (!isModal) {
    return (
      <div className="flex flex-col items-center w-full">
        <div className="w-full flex justify-between items-center mb-3.5 border-b border-neutral-200 pb-2.5 print:hidden">
          <div className="text-xs text-neutral-600 font-medium">
            Generated Label for <strong className="font-mono text-neutral-900">{bag.bagBarcode}</strong>
          </div>
          {actionButtons}
        </div>
        {content}

        <PdfPreviewModal
          isOpen={isPdfModalOpen}
          onClose={() => setIsPdfModalOpen(false)}
          pdfResult={pdfResult}
          docType="label"
          title={`Bag Label: ${bag.bagBarcode}`}
        />
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 print:p-0 print:static print:bg-white backdrop-blur-xs">
      <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full p-6 print:shadow-none print:p-0 print:border-none relative">
        <div className="flex items-center justify-between pb-3 border-b border-neutral-200 mb-4 print:hidden">
          <h3 className="font-bold text-neutral-800 text-sm flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            Official Department of Posts Bag Label (120mm × 70mm)
          </h3>
          <div className="flex items-center gap-2">
            {actionButtons}
            {onClose && (
              <button
                type="button"
                onClick={onClose}
                className="p-1.5 rounded-md text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 cursor-pointer ml-1"
              >
                <X size={18} />
              </button>
            )}
          </div>
        </div>

        <div className="overflow-auto max-h-[80vh] print:max-h-none py-2 flex justify-center">
          {content}
        </div>
      </div>

      <PdfPreviewModal
        isOpen={isPdfModalOpen}
        onClose={() => setIsPdfModalOpen(false)}
        pdfResult={pdfResult}
        docType="label"
        title={`Bag Label: ${bag.bagBarcode}`}
      />
    </div>
  );
};
