import React, { useState, useEffect } from 'react';
import { UserSession, BagRecord, DespatchRecord, OfficeName, SetName, ActionSuccessDetails, ShiftRecord } from './types';
import { getInitialSeedBags } from './data/mockData';
import { generateRandomUserId } from './utils/barcode';
import { LoginModal } from './components/LoginModal';
import { Header } from './components/Header';
import { PcWorkstationBar } from './components/PcWorkstationBar';
import { PcBottomDock } from './components/PcBottomDock';
import { PcShortcutsModal } from './components/PcShortcutsModal';
import { ActionSuccessModal } from './components/ActionSuccessModal';
import { playActionChime } from './utils/sound';
import {
  getActiveShift,
  beginShift,
  endActiveShift,
  getSavedShifts,
  formatIndianDate,
  getTodayDateString,
} from './utils/shiftStorage';
import { BeginShiftModal } from './components/BeginShiftModal';
import { EndShiftModal } from './components/EndShiftModal';
import { ShiftHistoryModal } from './components/ShiftHistoryModal';
import { BagReceiveTab } from './components/subtabs/BagReceiveTab';
import { ForwardingBagReceiveTab } from './components/subtabs/ForwardingBagReceiveTab';
import { BagOpenTab } from './components/subtabs/BagOpenTab';
import { BagCloseTab } from './components/subtabs/BagCloseTab';
import { PrintBagManifestTab } from './components/subtabs/PrintBagManifestTab';
import { PrintBagLabelTab } from './components/subtabs/PrintBagLabelTab';
import { BagDespatchTab } from './components/subtabs/BagDespatchTab';
import { DepositBagCloseTab } from './components/subtabs/DepositBagCloseTab';
import { ReceivedBagsAbstractTab } from './components/subtabs/ReceivedBagsAbstractTab';
import { ConsolidatedAbstractTab } from './components/subtabs/ConsolidatedAbstractTab';
import { CreateConsolidatedAbstractTab } from './components/subtabs/CreateConsolidatedAbstractTab';
import { GenerateBarcodeTab } from './components/subtabs/GenerateBarcodeTab';
import {
  Inbox,
  ArrowRightLeft,
  PackageOpen,
  PackageCheck,
  FileText,
  Tag,
  Truck,
  Archive,
  ClipboardList,
  FileSpreadsheet,
  Layers,
  Sparkles,
  Info,
  PlayCircle,
  StopCircle,
  Edit3,
  Barcode,
} from 'lucide-react';

export type SubTabId =
  | 'bag-receive'
  | 'forwarding-bag-receive'
  | 'bag-open'
  | 'bag-close'
  | 'print-manifest'
  | 'print-label'
  | 'bag-despatch'
  | 'deposit-bag-close'
  | 'received-bags-abstract'
  | 'consolidated-abstract'
  | 'create-consolidated-abstract'
  | 'generate-barcode';

interface SubTabConfig {
  id: SubTabId;
  number: number;
  label: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  badgeCount?: (bags: BagRecord[]) => number;
}

const SUB_TABS: SubTabConfig[] = [
  {
    id: 'bag-receive',
    number: 1,
    label: 'Bag Receive',
    icon: Inbox,
    badgeCount: (bags) => bags.filter((b) => b.bagStatus === 'received for open').length,
  },
  {
    id: 'forwarding-bag-receive',
    number: 2,
    label: 'Forwarding Bag Receive',
    icon: ArrowRightLeft,
    badgeCount: (bags) => bags.filter((b) => b.bagStatus === 'received for forwarding').length,
  },
  {
    id: 'bag-open',
    number: 3,
    label: 'Bag Open',
    icon: PackageOpen,
  },
  {
    id: 'bag-close',
    number: 4,
    label: 'Bag Close',
    icon: PackageCheck,
    badgeCount: (bags) => bags.filter((b) => b.bagStatus === 'closed').length,
  },
  {
    id: 'print-manifest',
    number: 5,
    label: 'Print Bag Manifest',
    icon: FileText,
  },
  {
    id: 'print-label',
    number: 6,
    label: 'Print Bag Label',
    icon: Tag,
  },
  {
    id: 'bag-despatch',
    number: 7,
    label: 'Bag Despatch',
    icon: Truck,
  },
  {
    id: 'deposit-bag-close',
    number: 8,
    label: 'Deposit Bag Close',
    icon: Archive,
    badgeCount: (bags) => bags.filter((b) => b.isDepositBag).length,
  },
  {
    id: 'received-bags-abstract',
    number: 9,
    label: 'Received Bags Abstract',
    icon: ClipboardList,
  },
  {
    id: 'consolidated-abstract',
    number: 10,
    label: 'Consolidated Abstract',
    icon: FileSpreadsheet,
  },
  {
    id: 'create-consolidated-abstract',
    number: 11,
    label: 'Create Consolidated Abstract',
    icon: Edit3,
  },
  {
    id: 'generate-barcode',
    number: 12,
    label: 'Generate Barcode',
    icon: Barcode,
  },
];

export default function App() {
  // Step 1: User Session (Login)
  const [session, setSession] = useState<UserSession | null>(null);
  const [showLoginModal, setShowLoginModal] = useState<boolean>(true);

  // Global Bagging Operations State
  const [bags, setBags] = useState<BagRecord[]>([]);
  const [despatches, setDespatches] = useState<DespatchRecord[]>([]);

  // Shift Management State
  const [activeShift, setActiveShift] = useState<ShiftRecord | null>(() => getActiveShift());
  const [savedShifts, setSavedShifts] = useState<ShiftRecord[]>(() => getSavedShifts());
  const [showBeginShiftModal, setShowBeginShiftModal] = useState<boolean>(false);
  const [showEndShiftModal, setShowEndShiftModal] = useState<boolean>(false);
  const [showShiftHistoryModal, setShowShiftHistoryModal] = useState<boolean>(false);

  // Active Sub Tab
  const [activeSubTab, setActiveSubTab] = useState<SubTabId>('bag-receive');
  const [actionSuccess, setActionSuccess] = useState<ActionSuccessDetails | null>(null);

  // PC Workstation States
  const [isSoundEnabled, setIsSoundEnabled] = useState<boolean>(() => {
    return localStorage.getItem('dop_scanner_sound') !== 'false';
  });
  const [isCompactMode, setIsCompactMode] = useState<boolean>(() => {
    return localStorage.getItem('dop_compact_mode') === 'true';
  });
  const [isWidescreen, setIsWidescreen] = useState<boolean>(() => {
    return localStorage.getItem('dop_widescreen') !== 'false';
  });
  const [showShortcutsModal, setShowShortcutsModal] = useState<boolean>(false);

  const toggleSound = () => {
    setIsSoundEnabled((prev) => {
      const next = !prev;
      localStorage.setItem('dop_scanner_sound', String(next));
      return next;
    });
  };

  const toggleCompactMode = () => {
    setIsCompactMode((prev) => {
      const next = !prev;
      localStorage.setItem('dop_compact_mode', String(next));
      return next;
    });
  };

  const toggleWidescreen = () => {
    setIsWidescreen((prev) => {
      const next = !prev;
      localStorage.setItem('dop_widescreen', String(next));
      return next;
    });
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
  };

  // Focus barcode scanner input in active tab
  const handleFocusScanner = () => {
    const container = document.getElementById('active-subtab-container');
    if (container) {
      const input = container.querySelector<HTMLInputElement>(
        'input.pc-scanner-input, input[type="text"]:not([disabled])'
      );
      if (input) {
        input.focus();
        input.select();
      }
    }
  };

  // Auto-focus scanner input when subtab changes
  useEffect(() => {
    const timer = setTimeout(() => {
      handleFocusScanner();
    }, 120);
    return () => clearTimeout(timer);
  }, [activeSubTab]);

  // Global PC keyboard shortcuts (F1, F4, F8, F9, Esc, Alt+1..0)
  useEffect(() => {
    const handleGlobalShortcuts = (e: KeyboardEvent) => {
      // 1. F1: Help / Shortcuts Cheat Sheet
      if (e.key === 'F1') {
        e.preventDefault();
        setShowShortcutsModal((prev) => !prev);
        return;
      }

      // F2: Begin Shift
      if (e.key === 'F2') {
        e.preventDefault();
        setShowBeginShiftModal(true);
        return;
      }

      // F3: End Shift
      if (e.key === 'F3') {
        e.preventDefault();
        setShowEndShiftModal(true);
        return;
      }

      // 2. ?: Help (when not actively typing inside a text input/textarea)
      const target = e.target as HTMLElement;
      const isEditingText =
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.isContentEditable);
      if (e.key === '?' && !isEditingText) {
        e.preventDefault();
        setShowShortcutsModal((prev) => !prev);
        return;
      }

      // 3. F4 or Alt + L: Focus Barcode Scanner
      if (e.key === 'F4' || (e.altKey && (e.key === 'l' || e.key === 'L'))) {
        e.preventDefault();
        handleFocusScanner();
        return;
      }

      // 4. F8: Toggle Compact UI
      if (e.key === 'F8') {
        e.preventDefault();
        toggleCompactMode();
        return;
      }

      // 5. F9: Toggle Scanner Sound
      if (e.key === 'F9') {
        e.preventDefault();
        toggleSound();
        return;
      }

      // 6. Escape: Close modals
      if (e.key === 'Escape') {
        if (showShortcutsModal) {
          setShowShortcutsModal(false);
          return;
        }
        if (actionSuccess) {
          setActionSuccess(null);
          return;
        }
      }

      // 7. Alt + 1 to Alt + 0 for tab navigation
      if (e.altKey) {
        const keyToTab: Record<string, SubTabId> = {
          '1': 'bag-receive',
          '2': 'forwarding-bag-receive',
          '3': 'bag-open',
          '4': 'bag-close',
          '5': 'print-manifest',
          '6': 'print-label',
          '7': 'bag-despatch',
          '8': 'deposit-bag-close',
          '9': 'received-bags-abstract',
          '0': 'consolidated-abstract',
        };

        if (keyToTab[e.key]) {
          e.preventDefault();
          setActiveSubTab(keyToTab[e.key]);
        }
      }
    };

    window.addEventListener('keydown', handleGlobalShortcuts);
    return () => window.removeEventListener('keydown', handleGlobalShortcuts);
  }, [showShortcutsModal, actionSuccess]);

  // Handle action success with audio chime
  const handleSetActionSuccess = (details: ActionSuccessDetails | null) => {
    setActionSuccess(details);
    if (details) {
      playActionChime(isSoundEnabled);
    }
  };

  // Initialize from localStorage or mock data
  useEffect(() => {
    const savedSession = localStorage.getItem('dop_user_session');
    if (savedSession) {
      try {
        const parsed = JSON.parse(savedSession);
        if (parsed && !/^\d{8}$/.test(parsed.userId || '')) {
          parsed.userId = generateRandomUserId();
          localStorage.setItem('dop_user_session', JSON.stringify(parsed));
        }
        setSession(parsed);
        setShowLoginModal(false);
      } catch (err) {
        console.warn(err);
      }
    }

    const savedBags = localStorage.getItem('dop_bags_data');
    if (savedBags) {
      try {
        setBags(JSON.parse(savedBags));
      } catch (err) {
        console.warn(err);
      }
    } else {
      // Seed default bags for Indore NSH / SET/1
      const initial = getInitialSeedBags('Indore NSH', 'SET/1');
      setBags(initial);
      localStorage.setItem('dop_bags_data', JSON.stringify(initial));
    }
  }, []);

  // Save bags whenever modified
  useEffect(() => {
    if (bags.length > 0) {
      localStorage.setItem('dop_bags_data', JSON.stringify(bags));
    }
  }, [bags]);

  const handleLogin = (newSession: UserSession) => {
    setSession(newSession);
    setShowLoginModal(false);
    localStorage.setItem('dop_user_session', JSON.stringify(newSession));

    // If no bags exist for this office, ensure seed bags exist
    if (bags.length === 0) {
      const seeded = getInitialSeedBags(newSession.officeName, newSession.setName);
      setBags(seeded);
    }
  };

  const handleSwitchSession = () => {
    setShowLoginModal(true);
  };

  // Sub Tab 1: Receive Bag
  const handleReceiveBag = (newBag: BagRecord) => {
    setBags((prev) => [newBag, ...prev]);
  };

  // Sub Tab 2: Receive Forwarding Bag
  const handleReceiveForwardingBag = (newBag: BagRecord) => {
    setBags((prev) => [newBag, ...prev]);
  };

  // Sub Tab 3: Update Bag (e.g. Bag Open)
  const handleUpdateBag = (updatedBag: BagRecord) => {
    setBags((prev) => prev.map((b) => (b.id === updatedBag.id ? updatedBag : b)));
  };

  // Sub Tab 4: Close Bag
  const handleCloseBag = (closedBag: BagRecord) => {
    setBags((prev) => [closedBag, ...prev]);
  };

  // Sub Tab 7: Despatch Bags
  const handleDespatchBags = (despatch: DespatchRecord, bagIds: string[]) => {
    setDespatches((prev) => [despatch, ...prev]);
    // Mark bags as despatched and preserve final destination office
    setBags((prev) =>
      prev.map((b) => {
        if (!bagIds.includes(b.id)) return b;
        const matchingDespatchBag = despatch.bags.find((db) => db.id === b.id);
        return {
          ...b,
          bagStatus: 'despatched' as const,
          despatchedAt: despatch.despatchedAt,
          despatchScheduleId: despatch.scheduleId,
          finalDestinationOffice: matchingDespatchBag?.finalDestinationOffice || b.finalDestinationOffice,
        };
      })
    );
  };

  // Sub Tab 8: Close Deposit Bag
  const handleCloseDepositBag = (depositBag: BagRecord) => {
    setBags((prev) => [depositBag, ...prev]);
  };

  // Delete bag helper (for editing errors)
  const handleDeleteBag = (bagId: string) => {
    setBags((prev) => prev.filter((b) => b.id !== bagId));
  };

  // Shift Handlers
  const handleRefreshSavedShifts = () => {
    setSavedShifts(getSavedShifts());
  };

  const handleBeginShift = (config: {
    shiftDate: string;
    officeName: OfficeName;
    setName: SetName;
    userId: string;
    startWithFreshEmpty: boolean;
  }) => {
    // If an existing shift is in progress, archive it first
    if (activeShift) {
      endActiveShift({
        activeShift,
        bags,
        despatches,
        handoverRemarks: `Auto-archived prior to starting new shift on ${config.shiftDate}.`,
        supervisorSignOff: 'Supervisor Handover Verification',
      });
      setSavedShifts(getSavedShifts());
    }

    const newShift = beginShift({
      shiftDate: config.shiftDate,
      officeName: config.officeName,
      setName: config.setName,
      userId: config.userId,
    });
    setActiveShift(newShift);

    // Update active session identity
    const updatedSession: UserSession = {
      officeName: config.officeName,
      setName: config.setName,
      userId: config.userId,
      loginTime: new Date().toISOString(),
    };
    setSession(updatedSession);
    localStorage.setItem('dop_user_session', JSON.stringify(updatedSession));

    // Reset or seed bags
    if (config.startWithFreshEmpty) {
      setBags([]);
      setDespatches([]);
      localStorage.setItem('dop_bags_data', JSON.stringify([]));
    } else {
      const seeded = getInitialSeedBags(config.officeName, config.setName);
      setBags(seeded);
      localStorage.setItem('dop_bags_data', JSON.stringify(seeded));
    }

    handleSetActionSuccess({
      title: 'Shift Begun Successfully',
      subtitle: `Fresh operational shift opened for ${formatIndianDate(config.shiftDate)} • ${config.setName}`,
      badge: 'SHIFT ACTIVE',
      actionType: 'receive',
      details: [
        { label: 'Shift Date', value: formatIndianDate(config.shiftDate) },
        { label: 'Duty Set', value: config.setName },
        { label: 'Working Office', value: config.officeName },
        { label: 'Operator ID', value: config.userId },
        { label: 'Initial Queue', value: config.startWithFreshEmpty ? 'Fresh (0 Bags)' : 'Sample Seed Bags' },
      ],
    });
  };

  const handleEndShift = (params: { handoverRemarks: string; supervisorSignOff: string }) => {
    const shiftToClose: ShiftRecord = activeShift || {
      id: `SHIFT-${getTodayDateString().replace(/-/g, '')}-${session?.userId || '10048219'}-${Date.now().toString().slice(-4)}`,
      shiftDate: getTodayDateString(),
      startTime: new Date().toLocaleTimeString('en-IN'),
      officeName: session?.officeName || 'Indore NSH',
      setName: session?.setName || 'SET/1',
      userId: session?.userId || '10048219',
      status: 'active',
      bags: [],
      despatches: [],
      summary: {
        totalBagsReceived: 0,
        totalBagsForwardReceived: 0,
        totalBagsOpened: 0,
        totalBagsClosed: 0,
        totalBagsDespatched: 0,
        totalDepositBags: 0,
        totalArticlesProcessed: 0,
        totalWeightKg: 0,
        speedPostArticles: 0,
        insuredArticles: 0,
      },
    };

    const closed = endActiveShift({
      activeShift: shiftToClose,
      bags,
      despatches,
      handoverRemarks: params.handoverRemarks,
      supervisorSignOff: params.supervisorSignOff,
    });

    setActiveShift(null);
    setSavedShifts(getSavedShifts());

    handleSetActionSuccess({
      title: 'Shift Ended & Saved to Local Storage',
      subtitle: `Operational shift successfully finalized and saved to local storage archive`,
      badge: 'ARCHIVED',
      actionType: 'close',
      details: [
        { label: 'Shift ID', value: closed.id },
        { label: 'Shift Date', value: formatIndianDate(closed.shiftDate) },
        { label: 'Bags Archived', value: closed.bags.length },
        { label: 'Despatches Archived', value: closed.despatches.length },
        { label: 'Articles Processed', value: closed.summary.totalArticlesProcessed },
        { label: 'Total Weight', value: `${closed.summary.totalWeightKg} kg` },
        { label: 'LocalStorage Status', value: 'Saved in dop_saved_shifts for future reference' },
      ],
    });
  };

  const handleRestoreShift = (shift: ShiftRecord) => {
    setBags(shift.bags || []);
    setDespatches(shift.despatches || []);
    localStorage.setItem('dop_bags_data', JSON.stringify(shift.bags || []));
    setActiveShift(shift);
    setShowShiftHistoryModal(false);

    handleSetActionSuccess({
      title: 'Shift Restored to Active Workspace',
      subtitle: `Loaded ${shift.bags.length} bags from saved shift archive (${formatIndianDate(shift.shiftDate)})`,
      badge: 'RESTORED',
      actionType: 'open',
      details: [
        { label: 'Shift ID', value: shift.id },
        { label: 'Shift Date', value: formatIndianDate(shift.shiftDate) },
        { label: 'Set / Office', value: `${shift.setName} • ${shift.officeName}` },
        { label: 'Bags Restored', value: shift.bags.length },
        { label: 'Despatches Restored', value: (shift.despatches || []).length },
      ],
    });
  };

  // Reset demo data to fresh seed
  const handleResetData = () => {
    if (!session) return;
    if (window.confirm('Reset all bags to initial sample data for this office?')) {
      const fresh = getInitialSeedBags(session.officeName, session.setName);
      setBags(fresh);
      localStorage.setItem('dop_bags_data', JSON.stringify(fresh));
    }
  };

  return (
    <div className="min-h-screen bg-[#f4f5f8] text-neutral-900 flex flex-col font-sans">
      {/* Step 1 Login Modal */}
      {showLoginModal && (
        <LoginModal onLogin={handleLogin} currentSession={session} />
      )}

      {/* Main Authenticated Application */}
      {session && (
        <>
          {/* Top-Level PC Workstation Status Bar */}
          <PcWorkstationBar
            session={session}
            isSoundEnabled={isSoundEnabled}
            onToggleSound={toggleSound}
            isCompactMode={isCompactMode}
            onToggleCompact={toggleCompactMode}
            isWidescreen={isWidescreen}
            onToggleWidescreen={toggleWidescreen}
            onOpenShortcuts={() => setShowShortcutsModal(true)}
            onToggleFullscreen={toggleFullscreen}
            activeShift={activeShift}
            onOpenShiftBegin={() => setShowBeginShiftModal(true)}
            onOpenShiftEnd={() => setShowEndShiftModal(true)}
            onOpenShiftHistory={() => setShowShiftHistoryModal(true)}
            savedShiftsCount={savedShifts.length}
          />

          {/* Header */}
          <Header
            session={session}
            onSwitchSession={handleSwitchSession}
            activeSubTab={activeSubTab}
            isWidescreen={isWidescreen}
            onOpenShortcuts={() => setShowShortcutsModal(true)}
            activeShift={activeShift}
            onOpenShiftBegin={() => setShowBeginShiftModal(true)}
            onOpenShiftEnd={() => setShowEndShiftModal(true)}
            onOpenShiftHistory={() => setShowShiftHistoryModal(true)}
            savedShiftsCount={savedShifts.length}
          />

          {/* Main Container */}
          <main
            className={`flex-1 w-full mx-auto px-3 sm:px-5 lg:px-7 py-4 space-y-4 transition-all duration-150 ${
              isWidescreen ? 'max-w-[1720px]' : 'max-w-7xl'
            } ${isCompactMode ? 'pc-compact' : ''}`}
          >
            {/* Bagging Operations Main Tab Card */}
            <div className="bg-white rounded-2xl border border-neutral-200 shadow-xs overflow-hidden print:border-none print:shadow-none">
              {/* Tab Master Title Strip */}
              <div className="px-6 py-4 bg-gradient-to-r from-neutral-900 to-neutral-800 text-white flex flex-col lg:flex-row lg:items-center justify-between gap-4 print:hidden">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-red-600 rounded-lg text-white">
                    <Layers size={20} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h2 className="text-base font-black uppercase tracking-wide">
                        Bagging Operations Module
                      </h2>
                      <span className="text-[10px] font-mono bg-white/20 px-2 py-0.5 rounded text-amber-300">
                        {session.officeName}
                      </span>
                      {activeShift ? (
                        <span className="inline-flex items-center gap-1.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-bold px-2 py-0.5 rounded-full">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                          <span>Shift Active: {formatIndianDate(activeShift.shiftDate)} ({activeShift.setName})</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-semibold px-2 py-0.5 rounded-full">
                          No Active Shift
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-neutral-300 mt-0.5">
                      Postal Bag Lifecycle: Receiving, Opening, Closing, Manifests, Despatch, and Duty Abstracts
                    </p>
                  </div>
                </div>

                {/* Shift Action Controls & Helpers */}
                <div className="flex items-center gap-2 flex-wrap">
                  {/* Shift Begin Button */}
                  <button
                    type="button"
                    onClick={() => setShowBeginShiftModal(true)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-[#1b5e20] hover:bg-[#144717] text-white rounded-lg text-xs font-bold transition-all shadow-xs cursor-pointer border border-emerald-600"
                    title="Start a new fresh shift on the date (Shortcut: F2)"
                  >
                    <PlayCircle size={15} className="text-emerald-300" />
                    <span>Shift Begin</span>
                    <kbd className="hidden sm:inline text-[9px] font-mono bg-emerald-950/60 px-1 rounded text-emerald-200">F2</kbd>
                  </button>

                  {/* Shift End Button */}
                  <button
                    type="button"
                    onClick={() => setShowEndShiftModal(true)}
                    disabled={!activeShift && bags.length === 0}
                    className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all shadow-xs cursor-pointer border ${
                      activeShift || bags.length > 0
                        ? 'bg-[#c92228] hover:bg-[#a01217] text-white border-red-600'
                        : 'bg-neutral-800 text-neutral-500 border-neutral-700 cursor-not-allowed'
                    }`}
                    title="End shift and save data to local storage (Shortcut: F3)"
                  >
                    <StopCircle size={15} className="text-amber-300" />
                    <span>Shift End</span>
                    <kbd className="hidden sm:inline text-[9px] font-mono bg-red-950/60 px-1 rounded text-red-200">F3</kbd>
                  </button>

                  {/* Saved Shifts Archive in Local Storage */}
                  <button
                    type="button"
                    onClick={() => setShowShiftHistoryModal(true)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 hover:text-white rounded-lg text-xs font-semibold border border-neutral-700 transition-colors cursor-pointer"
                    title="View historical shifts saved in local storage"
                  >
                    <Archive size={14} className="text-amber-400" />
                    <span>Saved Shifts</span>
                    {savedShifts.length > 0 && (
                      <span className="bg-amber-400 text-neutral-950 font-bold px-1.5 py-0.2 rounded-full text-[10px] font-mono">
                        {savedShifts.length}
                      </span>
                    )}
                  </button>

                  {/* Reset Demo Data */}
                  <button
                    type="button"
                    onClick={handleResetData}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white rounded-lg text-xs font-semibold border border-neutral-700 transition-colors cursor-pointer"
                    title="Reload default sample postal bags"
                  >
                    <Sparkles size={13} className="text-amber-400" />
                    <span>Reload Sample</span>
                  </button>
                </div>
              </div>

              {/* 10 Sub Tabs Horizontal Scroller */}
              <div className="bg-neutral-100 border-b border-neutral-200 p-2 overflow-x-auto print:hidden">
                <nav className="flex space-x-1.5 min-w-max" aria-label="Bagging Operations Sub Tabs">
                  {SUB_TABS.map((tab) => {
                    const Icon = tab.icon;
                    const isActive = activeSubTab === tab.id;
                    const count = tab.badgeCount ? tab.badgeCount(bags) : undefined;

                    return (
                      <button
                        key={tab.id}
                        type="button"
                        onClick={() => setActiveSubTab(tab.id)}
                        className={`flex items-center gap-2 px-3.5 py-2.5 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                          isActive
                            ? 'bg-[#c92228] text-white shadow-xs'
                            : 'bg-white text-neutral-700 hover:bg-neutral-50 hover:text-neutral-900 border border-neutral-200'
                        }`}
                      >
                        <span
                          className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black ${
                            isActive ? 'bg-white/20 text-white' : 'bg-neutral-200 text-neutral-800'
                          }`}
                        >
                          {tab.number}
                        </span>
                        <Icon size={16} />
                        <span>{tab.label}</span>
                        {typeof count === 'number' && count > 0 && (
                          <span
                            className={`px-1.5 py-0.5 rounded-full text-[10px] font-black ${
                              isActive ? 'bg-white text-[#c92228]' : 'bg-red-100 text-red-800'
                            }`}
                          >
                            {count}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </nav>
              </div>

              {/* Active Sub Tab Render View */}
              <div id="active-subtab-container" className="p-6 bg-[#fafafa]">
                {activeSubTab === 'bag-receive' && (
                  <BagReceiveTab
                    session={session}
                    bags={bags}
                    onReceiveBag={handleReceiveBag}
                    onDeleteBag={handleDeleteBag}
                    onActionSuccess={handleSetActionSuccess}
                  />
                )}

                {activeSubTab === 'forwarding-bag-receive' && (
                  <ForwardingBagReceiveTab
                    session={session}
                    bags={bags}
                    onReceiveForwardingBag={handleReceiveForwardingBag}
                    onDeleteBag={handleDeleteBag}
                    onActionSuccess={handleSetActionSuccess}
                  />
                )}

                {activeSubTab === 'bag-open' && (
                  <BagOpenTab
                    session={session}
                    bags={bags}
                    onUpdateBag={handleUpdateBag}
                    onActionSuccess={handleSetActionSuccess}
                  />
                )}

                {activeSubTab === 'bag-close' && (
                  <BagCloseTab
                    session={session}
                    bags={bags}
                    onCloseBag={handleCloseBag}
                    onActionSuccess={handleSetActionSuccess}
                  />
                )}

                {activeSubTab === 'print-manifest' && (
                  <PrintBagManifestTab
                    session={session}
                    bags={bags}
                  />
                )}

                {activeSubTab === 'print-label' && (
                  <PrintBagLabelTab
                    session={session}
                    bags={bags}
                  />
                )}

                {activeSubTab === 'bag-despatch' && (
                  <BagDespatchTab
                    session={session}
                    bags={bags}
                    onDespatchBags={handleDespatchBags}
                    onActionSuccess={handleSetActionSuccess}
                  />
                )}

                {activeSubTab === 'deposit-bag-close' && (
                  <DepositBagCloseTab
                    session={session}
                    bags={bags}
                    onCloseDepositBag={handleCloseDepositBag}
                    onActionSuccess={handleSetActionSuccess}
                  />
                )}

                {activeSubTab === 'received-bags-abstract' && (
                  <ReceivedBagsAbstractTab
                    session={session}
                    bags={bags}
                  />
                )}

                {activeSubTab === 'consolidated-abstract' && (
                  <ConsolidatedAbstractTab
                    session={session}
                    bags={bags}
                  />
                )}

                {activeSubTab === 'create-consolidated-abstract' && (
                  <CreateConsolidatedAbstractTab
                    session={session}
                  />
                )}

                {activeSubTab === 'generate-barcode' && (
                  <GenerateBarcodeTab
                    session={session}
                  />
                )}
              </div>
            </div>

            {/* Success Action Notification / Modal */}
            <ActionSuccessModal
              actionData={actionSuccess}
              onClose={() => setActionSuccess(null)}
              onNavigateToTab={(t) => setActiveSubTab(t as SubTabId)}
            />

            {/* Quick Operational Info Bar */}
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-amber-900 print:hidden">
              <div className="flex items-center gap-2">
                <Info size={16} className="text-amber-700 shrink-0" />
                <span>
                  <strong>Barcode Rule Notice:</strong> Article numbers strictly follow 13 characters (2 letters + 9 digits + 2 letters e.g.{' '}
                  <code className="font-mono bg-white px-1 py-0.5 rounded">EE123456789IN</code>). System generated bag labels start with{' '}
                  <code className="font-mono bg-white px-1 py-0.5 rounded">EBI/EBX</code> (Indore NSH),{' '}
                  <code className="font-mono bg-white px-1 py-0.5 rounded">CBI</code> (Indore PH),{' '}
                  <code className="font-mono bg-white px-1 py-0.5 rounded">LBI</code> (Indore RMS), or{' '}
                  <code className="font-mono bg-white px-1 py-0.5 rounded">DBI/DBX</code> for Deposit Bags.
                </span>
              </div>
            </div>
          </main>

          {/* Sticky PC Bottom Workstation Dock */}
          <PcBottomDock
            activeSubTab={activeSubTab}
            onSelectTab={setActiveSubTab}
            onFocusScanner={handleFocusScanner}
            onToggleShortcuts={() => setShowShortcutsModal(true)}
          />

          {/* PC Shortcuts Cheat Sheet Modal */}
          <PcShortcutsModal
            isOpen={showShortcutsModal}
            onClose={() => setShowShortcutsModal(false)}
          />

          {/* Shift Begin Modal */}
          {session && (
            <BeginShiftModal
              isOpen={showBeginShiftModal}
              onClose={() => setShowBeginShiftModal(false)}
              currentSession={session}
              activeShiftExists={!!activeShift}
              currentBagsCount={bags.length}
              onConfirmBeginShift={handleBeginShift}
            />
          )}

          {/* Shift End Modal */}
          {session && (
            <EndShiftModal
              isOpen={showEndShiftModal}
              onClose={() => setShowEndShiftModal(false)}
              activeShift={
                activeShift || {
                  id: `SHIFT-${getTodayDateString().replace(/-/g, '')}-${session.userId}-01`,
                  shiftDate: getTodayDateString(),
                  startTime: new Date().toLocaleTimeString('en-IN'),
                  officeName: session.officeName,
                  setName: session.setName,
                  userId: session.userId,
                  status: 'active',
                  bags,
                  despatches,
                  summary: {
                    totalBagsReceived: 0,
                    totalBagsForwardReceived: 0,
                    totalBagsOpened: 0,
                    totalBagsClosed: 0,
                    totalBagsDespatched: 0,
                    totalDepositBags: 0,
                    totalArticlesProcessed: 0,
                    totalWeightKg: 0,
                    speedPostArticles: 0,
                    insuredArticles: 0,
                  },
                }
              }
              bags={bags}
              despatches={despatches}
              onConfirmEndShift={handleEndShift}
            />
          )}

          {/* Shift History & Local Storage Archive Modal */}
          <ShiftHistoryModal
            isOpen={showShiftHistoryModal}
            onClose={() => setShowShiftHistoryModal(false)}
            savedShifts={savedShifts}
            onRefreshShifts={handleRefreshSavedShifts}
            onRestoreShift={handleRestoreShift}
          />

          {/* Footer */}
          <footer className="bg-white border-t border-neutral-200 py-4 pb-14 text-center text-xs text-neutral-500 print:hidden">
            <p>
              Department of Posts, Ministry of Communications, Government of India — Indore Postal Division
            </p>
          </footer>
        </>
      )}
    </div>
  );
}
