import { DespatchSchedule } from '../types';

const SCHEDULES_STORAGE_KEY = 'dop_despatch_schedules_v2';
export const SCHEDULES_UPDATE_EVENT = 'dop-despatch-schedules-updated';

// Realistic pre-configured default schedules for Indore RMS Division
export const DEFAULT_DESPATCH_SCHEDULES: DespatchSchedule[] = [
  {
    id: 'sch-bpl-01',
    scheduleCode: 'SCH-01',
    scheduleName: 'Indore RMS - Bhopal NSH Morning Transit',
    destinationOffice: 'Bhopal NSH',
    finalDestinationOffices: [
      'Bhopal GPO (462001)',
      'Hoshangabad HO (461001)',
      'Itarsi RMS TMO (461111)',
      'Sehore HO (466001)',
      'Betul HO (460001)',
      'Vidisha HO (464001)',
    ],
    transitMode: 'Road / MMS',
    departureTime: '10:30',
    carrierOrVehicle: 'MMS Van MP-09-AB-1845',
    remarks: 'Road transport through Indore-Bhopal Highway. Exchange at Bhopal RMS.',
    isSystemDefault: true,
  },
  {
    id: 'sch-bom-02',
    scheduleCode: 'SCH-02',
    scheduleName: 'Indore RMS - Mumbai NSH Evening Air & Rail',
    destinationOffice: 'Mumbai NSH',
    finalDestinationOffices: [
      'Mumbai GPO (400001)',
      'Mumbai Air NSH (400099)',
      'Pune NSH (411001)',
      'Thane HO (400601)',
      'Nashik HO (422001)',
      'Navi Mumbai HO (400703)',
    ],
    transitMode: 'Train / RMS',
    departureTime: '16:50',
    carrierOrVehicle: '12962 Avantika Superfast Express',
    remarks: 'Daily evening RMS transit to Mumbai Central. Connects western states.',
    isSystemDefault: true,
  },
  {
    id: 'sch-del-03',
    scheduleCode: 'SCH-03',
    scheduleName: 'Indore RMS - New Delhi NSH Night Rajdhani',
    destinationOffice: 'New Delhi NSH',
    finalDestinationOffices: [
      'New Delhi GPO (110001)',
      'Delhi Air NSH (110037)',
      'Gurugram HO (122001)',
      'Noida HO (201301)',
      'Faridabad HO (121001)',
      'Ghaziabad HO (201001)',
    ],
    transitMode: 'Train / RMS',
    departureTime: '21:15',
    carrierOrVehicle: '20957 New Delhi AC SF Express',
    remarks: 'Night RMS van connecting Northern Sorting Hub.',
    isSystemDefault: true,
  },
  {
    id: 'sch-ujn-04',
    scheduleCode: 'SCH-04',
    scheduleName: 'Indore RMS - Ujjain RMS TMO Local Van',
    destinationOffice: 'Ujjain RMS TMO',
    finalDestinationOffices: [
      'Ujjain HO (456001)',
      'Nagda SO (456335)',
      'Khachrod SO (456224)',
      'Badnagar SO (456771)',
      'Tarana SO (456665)',
      'Mahidpur SO (456443)',
    ],
    transitMode: 'Road / MMS',
    departureTime: '08:45',
    carrierOrVehicle: 'Postal Dept Van MP-09-GA-4412',
    remarks: 'Local division feeder van connecting Ujjain sub-division.',
    isSystemDefault: true,
  },
  {
    id: 'sch-knw-05',
    scheduleCode: 'SCH-05',
    scheduleName: 'Indore RMS - Khandwa RMS TMO Nimar Feeder',
    destinationOffice: 'Khandwa RMS TMO',
    finalDestinationOffices: [
      'Khandwa HO (450001)',
      'Burhanpur HO (450331)',
      'Khargone HO (451001)',
      'Barwani HO (451551)',
      'Nepanagar SO (450221)',
      'Sanawad SO (451111)',
    ],
    transitMode: 'Road / MMS',
    departureTime: '11:15',
    carrierOrVehicle: 'MMS Nimar Van MP-09-CD-8901',
    remarks: 'Servicing Khandwa, Burhanpur, and West Nimar region.',
    isSystemDefault: true,
  },
  {
    id: 'sch-rtm-06',
    scheduleCode: 'SCH-06',
    scheduleName: 'Indore RMS - Ratlam RMS TMO Western Junction',
    destinationOffice: 'Ratlam RMS TMO',
    finalDestinationOffices: [
      'Ratlam HO (457001)',
      'Jaora HO (457226)',
      'Mandsaur HO (458001)',
      'Neemuch HO (458441)',
      'Jhabua HO (457661)',
      'Alirajpur HO (457887)',
    ],
    transitMode: 'Train / RMS',
    departureTime: '13:30',
    carrierOrVehicle: '19330 Viramgam Express',
    remarks: 'Feeds Malwa-Rajasthan border districts and Western Railway junctions.',
    isSystemDefault: true,
  },
];

// Retrieve all schedules from localStorage, merging with defaults
export function getStoredSchedules(): DespatchSchedule[] {
  try {
    const raw = localStorage.getItem(SCHEDULES_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (e) {
    console.error('Failed to parse despatch schedules from localStorage', e);
  }

  // Initialize with defaults if empty
  saveSchedules(DEFAULT_DESPATCH_SCHEDULES);
  return DEFAULT_DESPATCH_SCHEDULES;
}

// Save complete schedules array to localStorage and broadcast event
export function saveSchedules(schedules: DespatchSchedule[]): void {
  try {
    localStorage.setItem(SCHEDULES_STORAGE_KEY, JSON.stringify(schedules));
    window.dispatchEvent(new CustomEvent(SCHEDULES_UPDATE_EVENT, { detail: schedules }));
  } catch (e) {
    console.error('Failed to save despatch schedules to localStorage', e);
  }
}

// Add a new schedule
export function addDespatchSchedule(schedule: DespatchSchedule): { success: boolean; message: string } {
  const current = getStoredSchedules();
  
  // Check code uniqueness
  const codeExists = current.find(
    (s) => s.scheduleCode.trim().toUpperCase() === schedule.scheduleCode.trim().toUpperCase()
  );
  if (codeExists) {
    return { success: false, message: `Schedule code "${schedule.scheduleCode}" already exists! Please use a unique code.` };
  }

  const updated = [schedule, ...current];
  saveSchedules(updated);
  return { success: true, message: `Schedule "${schedule.scheduleCode} (${schedule.scheduleName})" saved successfully!` };
}

// Update existing schedule
export function updateDespatchSchedule(
  id: string,
  updatedData: Partial<DespatchSchedule>
): { success: boolean; message: string } {
  const current = getStoredSchedules();
  const index = current.findIndex((s) => s.id === id);

  if (index === -1) {
    return { success: false, message: `Schedule not found!` };
  }

  // Check code uniqueness if code changed
  if (
    updatedData.scheduleCode &&
    updatedData.scheduleCode.trim().toUpperCase() !== current[index].scheduleCode.trim().toUpperCase()
  ) {
    const collision = current.find(
      (s, i) => i !== index && s.scheduleCode.trim().toUpperCase() === updatedData.scheduleCode!.trim().toUpperCase()
    );
    if (collision) {
      return { success: false, message: `Schedule code "${updatedData.scheduleCode}" is already in use by another schedule!` };
    }
  }

  const updatedSchedule: DespatchSchedule = {
    ...current[index],
    ...updatedData,
    updatedAt: new Date().toLocaleString('en-IN'),
  };

  const updatedList = [...current];
  updatedList[index] = updatedSchedule;

  saveSchedules(updatedList);
  return { success: true, message: `Schedule "${updatedSchedule.scheduleCode}" updated and saved successfully!` };
}

// Delete a schedule
export function deleteDespatchSchedule(id: string): { success: boolean; message: string } {
  const current = getStoredSchedules();
  const filtered = current.filter((s) => s.id !== id);

  if (filtered.length === current.length) {
    return { success: false, message: 'Schedule not found.' };
  }

  saveSchedules(filtered);
  return { success: true, message: 'Schedule deleted successfully.' };
}

// Reset schedules to default Indore RMS routes
export function resetSchedulesToDefault(): DespatchSchedule[] {
  saveSchedules(DEFAULT_DESPATCH_SCHEDULES);
  return DEFAULT_DESPATCH_SCHEDULES;
}
