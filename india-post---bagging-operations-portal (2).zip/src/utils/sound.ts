// Web Audio API sound generator for PC postal workstation scanner simulation
// Zero external dependencies, pure native browser AudioContext

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

export function isSoundGloballyEnabled(): boolean {
  if (typeof window === 'undefined') return true;
  return localStorage.getItem('dop_scanner_sound') !== 'false';
}

export function playScanSuccess(enabled?: boolean) {
  const isEnabled = enabled !== undefined ? enabled : isSoundGloballyEnabled();
  if (!isEnabled) return;
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    // Crisp postal scanner 1400Hz -> 1800Hz chirp
    osc.frequency.setValueAtTime(1400, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(1760, ctx.currentTime + 0.05);

    gain.gain.setValueAtTime(0.18, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + 0.09);
  } catch {
    // Ignore audio autoplay restrictions gracefully
  }
}

export function playScanError(enabled?: boolean) {
  const isEnabled = enabled !== undefined ? enabled : isSoundGloballyEnabled();
  if (!isEnabled) return;
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    // Dual buzz for duplicate or invalid barcode
    const playTone = (freq: number, startDelay: number, duration: number) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, ctx.currentTime + startDelay);

      gain.gain.setValueAtTime(0.2, ctx.currentTime + startDelay);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + startDelay + duration);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(ctx.currentTime + startDelay);
      osc.stop(ctx.currentTime + startDelay + duration);
    };

    playTone(240, 0, 0.12);
    playTone(180, 0.14, 0.16);
  } catch {
    // Ignore audio autoplay restrictions gracefully
  }
}

export function playActionChime(enabled?: boolean) {
  const isEnabled = enabled !== undefined ? enabled : isSoundGloballyEnabled();
  if (!isEnabled) return;
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    // Pleasant high major third chime on bag close / despatch
    const now = ctx.currentTime;
    [523.25, 659.25, 783.99].forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.06);

      gain.gain.setValueAtTime(0.12, now + idx * 0.06);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.06 + 0.2);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + idx * 0.06);
      osc.stop(now + idx * 0.06 + 0.22);
    });
  } catch {
    // Ignore audio autoplay restrictions
  }
}

