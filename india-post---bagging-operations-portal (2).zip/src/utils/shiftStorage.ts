import { BagRecord, DespatchRecord, OfficeName, SetName, ShiftRecord, ShiftSummary } from '../types';

const STORAGE_ACTIVE_SHIFT = 'dop_active_shift';
const STORAGE_SAVED_SHIFTS = 'dop_saved_shifts';

/**
 * Calculates real-time shift statistical totals from bag and despatch records
 */
export function calculateShiftSummary(
  bags: BagRecord[],
  despatches: DespatchRecord[]
): ShiftSummary {
  let totalBagsReceived = 0;
  let totalBagsForwardReceived = 0;
  let totalBagsOpened = 0;
  let totalBagsClosed = 0;
  let totalBagsDespatched = 0;
  let totalDepositBags = 0;
  let totalArticlesProcessed = 0;
  let totalWeightKg = 0;
  let speedPostArticles = 0;
  let insuredArticles = 0;

  for (const bag of bags) {
    if (bag.bagStatus === 'received for open') totalBagsReceived++;
    if (bag.bagStatus === 'received for forwarding') totalBagsForwardReceived++;
    if (bag.bagStatus === 'opened') totalBagsOpened++;
    if (bag.bagStatus === 'closed') totalBagsClosed++;
    if (bag.bagStatus === 'despatched') totalBagsDespatched++;
    if (bag.isDepositBag) totalDepositBags++;

    totalArticlesProcessed += bag.totalArticlesCount || 0;
    speedPostArticles += bag.speedPostCount || 0;
    insuredArticles += bag.insuredCount || 0;
    totalWeightKg += bag.bagWeightKg || 0;
  }

  return {
    totalBagsReceived,
    totalBagsForwardReceived,
    totalBagsOpened,
    totalBagsClosed,
    totalBagsDespatched,
    totalDepositBags,
    totalArticlesProcessed,
    totalWeightKg: Math.round(totalWeightKg * 100) / 100,
    speedPostArticles,
    insuredArticles,
  };
}

/**
 * Gets the current active shift from localStorage if one is currently in progress
 */
export function getActiveShift(): ShiftRecord | null {
  try {
    const raw = localStorage.getItem(STORAGE_ACTIVE_SHIFT);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (parsed && parsed.status === 'active') {
      return parsed;
    }
    return null;
  } catch (err) {
    console.error('Error reading active shift:', err);
    return null;
  }
}

/**
 * Saves the active shift state to localStorage
 */
export function saveActiveShift(shift: ShiftRecord): void {
  try {
    localStorage.setItem(STORAGE_ACTIVE_SHIFT, JSON.stringify(shift));
  } catch (err) {
    console.error('Error saving active shift:', err);
  }
}

/**
 * Creates and starts a new shift for the given date, office, duty set, and operator ID.
 */
export function beginShift(params: {
  shiftDate: string; // YYYY-MM-DD
  officeName: OfficeName;
  setName: SetName;
  userId: string;
}): ShiftRecord {
  const timestamp = Date.now();
  const dateFormatted = params.shiftDate.replace(/-/g, '');
  const id = `SHIFT-${dateFormatted}-${params.userId}-${timestamp.toString().slice(-4)}`;
  
  const now = new Date();
  const startTime = now.toLocaleString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
  });

  const newShift: ShiftRecord = {
    id,
    shiftDate: params.shiftDate,
    startTime,
    officeName: params.officeName,
    setName: params.setName,
    userId: params.userId,
    status: 'active',
    bags: [],
    despatches: [],
    summary: {
      totalBagsReceived: 0,
      totalBagsForwardReceived: 0,
      totalBagsOpened: 0,
      totalBagsClosed: 0,
      totalBagsDespatched: 0,
      totalDepositBags: 0,
      totalArticlesProcessed: 0,
      totalWeightKg: 0,
      speedPostArticles: 0,
      insuredArticles: 0,
    },
  };

  saveActiveShift(newShift);
  return newShift;
}

/**
 * Ends the active shift, computes final statistics, saves the completed shift snapshot to local storage history,
 * and clears the active shift.
 */
export function endActiveShift(params: {
  activeShift: ShiftRecord;
  bags: BagRecord[];
  despatches: DespatchRecord[];
  handoverRemarks?: string;
  supervisorSignOff?: string;
}): ShiftRecord {
  const now = new Date();
  const endTime = now.toLocaleString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
  });

  const finalSummary = calculateShiftSummary(params.bags, params.despatches);

  const completedShift: ShiftRecord = {
    ...params.activeShift,
    endTime,
    status: 'ended',
    bags: [...params.bags],
    despatches: [...params.despatches],
    summary: finalSummary,
    handoverRemarks: params.handoverRemarks || 'Shift completed successfully and handed over.',
    supervisorSignOff: params.supervisorSignOff || 'Supervisory verification completed.',
    savedAt: new Date().toISOString(),
  };

  // 1. Add to saved shifts list in localStorage
  const savedShifts = getSavedShifts();
  // Avoid duplicate ID if saved before
  const filtered = savedShifts.filter((s) => s.id !== completedShift.id);
  const updatedList = [completedShift, ...filtered];
  
  try {
    localStorage.setItem(STORAGE_SAVED_SHIFTS, JSON.stringify(updatedList));
  } catch (err) {
    console.error('Failed to save shift in history:', err);
  }

  // 2. Remove active shift
  try {
    localStorage.removeItem(STORAGE_ACTIVE_SHIFT);
  } catch (err) {
    console.error('Failed to clear active shift:', err);
  }

  return completedShift;
}

/**
 * Retrieves all historically ended shifts saved in localStorage
 */
export function getSavedShifts(): ShiftRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_SAVED_SHIFTS);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (err) {
    console.error('Failed to read saved shifts:', err);
    return [];
  }
}

/**
 * Deletes a saved shift record from history in localStorage
 */
export function deleteSavedShift(shiftId: string): ShiftRecord[] {
  const list = getSavedShifts();
  const updated = list.filter((s) => s.id !== shiftId);
  try {
    localStorage.setItem(STORAGE_SAVED_SHIFTS, JSON.stringify(updated));
  } catch (err) {
    console.error('Failed to delete saved shift:', err);
  }
  return updated;
}

/**
 * Formats standard ISO YYYY-MM-DD to DD/MM/YYYY Indian date format
 */
export function formatIndianDate(dateStr: string): string {
  if (!dateStr) return '';
  const parts = dateStr.split('-');
  if (parts.length === 3) {
    return `${parts[2]}/${parts[1]}/${parts[0]}`;
  }
  return dateStr;
}

/**
 * Returns today's date in YYYY-MM-DD for date inputs
 */
export function getTodayDateString(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}
