import * as XLSX from 'xlsx';
import { ArticleItem } from '../types';

export function exportArticlesToExcel(
  articles: ArticleItem[],
  bagBarcode: string,
  destinationOffice: string,
  officeName: string,
  setName: string
) {
  const rows = articles.map((art, idx) => ({
    'Sr No': idx + 1,
    'Article Barcode': art.articleNumber,
    'Article Type': art.articleType,
    'Insured Article': art.isInsured ? 'YES' : 'NO',
    'Scanned Date Time': art.scannedAt,
    'Weight (g)': art.weightGrams || 150,
    'Destination Office': destinationOffice,
    'Bag Barcode': bagBarcode,
    'Origin Office': officeName,
    'Set': setName,
  }));

  const worksheet = XLSX.utils.json_to_sheet(rows);

  // Set column widths
  worksheet['!cols'] = [
    { wch: 8 },  // Sr No
    { wch: 18 }, // Article Barcode
    { wch: 14 }, // Article Type
    { wch: 16 }, // Insured
    { wch: 22 }, // Scanned Date Time
    { wch: 12 }, // Weight
    { wch: 26 }, // Destination
    { wch: 18 }, // Bag Barcode
    { wch: 20 }, // Origin Office
    { wch: 10 }, // Set
  ];

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Scanned Articles');

  const fileName = `Bag_${bagBarcode || 'Scanned'}_Articles_${new Date().toISOString().slice(0, 10)}.xlsx`;
  XLSX.writeFile(workbook, fileName);
}
