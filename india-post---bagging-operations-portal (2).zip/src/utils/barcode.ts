import { OfficeName } from '../types';

/**
 * Validates 13-character article barcode format:
 * First 2 letters, middle 9 digits, last 2 letters (e.g., EE123456789IN)
 */
export function validateArticleBarcode(code: string): { isValid: boolean; error?: string } {
  const trimmed = code.trim().toUpperCase();
  if (trimmed.length !== 13) {
    return {
      isValid: false,
      error: `Article number must be exactly 13 characters (current length: ${trimmed.length})`,
    };
  }
  const regex = /^[A-Z]{2}[0-9]{9}[A-Z]{2}$/;
  if (!regex.test(trimmed)) {
    return {
      isValid: false,
      error: 'Invalid format! Must have 2 letters, 9 digits, followed by 2 letters (e.g. EE123456789IN)',
    };
  }
  return { isValid: true };
}

/**
 * Validates 13-character bag barcode format:
 * First 3 letters, followed by 10 digits (e.g., EBI0123456789)
 */
export function validateBagBarcode(code: string): { isValid: boolean; error?: string } {
  const trimmed = code.trim().toUpperCase();
  if (trimmed.length !== 13) {
    return {
      isValid: false,
      error: `Bag number must be exactly 13 characters (current length: ${trimmed.length})`,
    };
  }
  const regex = /^[A-Z]{3}[0-9]{10}$/;
  if (!regex.test(trimmed)) {
    return {
      isValid: false,
      error: 'Invalid format! Must start with 3 letters followed by 10 digits (e.g. EBI0123456789)',
    };
  }
  return { isValid: true };
}

/**
 * Generates a system bag barcode strictly following Department of Posts rules:
 * - Indore NSH: EBI / EBX (close bag), DBI / DBX (deposit bag close)
 * - Indore PH: CBI (close bag), DBI / DBX (deposit bag close)
 * - Indore RMS L1U: LBI (close bag), DBI / DBX (deposit bag close)
 * - Indore TMO: TBI (close bag), DBI / DBX (deposit bag close)
 * - Deposit bags for all offices: DBI or DBX
 * Total 13 characters: 3 letters prefix + 10 random numeric digits.
 */
export function generateSystemBagBarcode(
  officeName: OfficeName,
  isDepositBag: boolean = false,
  existingBarcodes: Set<string> = new Set()
): string {
  let prefix = 'EBI';

  if (isDepositBag) {
    const depositPrefixes = ['DBI', 'DBX'];
    prefix = depositPrefixes[Math.floor(Math.random() * depositPrefixes.length)];
  } else {
    switch (officeName) {
      case 'Indore NSH': {
        const nshPrefixes = ['EBI', 'EBX'];
        prefix = nshPrefixes[Math.floor(Math.random() * nshPrefixes.length)];
        break;
      }
      case 'Indore PH':
        prefix = 'CBI';
        break;
      case 'Indore RMS L1U':
        prefix = 'LBI';
        break;
      case 'Indore TMO':
        prefix = 'TBI';
        break;
      default:
        prefix = 'EBI';
    }
  }

  // Generate 10 random digits and ensure uniqueness
  let attempts = 0;
  while (attempts < 1000) {
    let digits = '';
    for (let i = 0; i < 10; i++) {
      digits += Math.floor(Math.random() * 10).toString();
    }
    const candidate = `${prefix}${digits}`;
    if (!existingBarcodes.has(candidate)) {
      return candidate;
    }
    attempts++;
  }

  // Fallback timestamp based
  const fallbackDigits = Date.now().toString().slice(-10);
  return `${prefix}${fallbackDigits}`;
}

/**
 * Helper to generate random 13-char article barcode for quick testing/scanning
 */
export function generateRandomArticleBarcode(articleType: 'Speed Post' | 'Parcel' | 'Registered' = 'Speed Post'): string {
  let prefix = 'EE';
  if (articleType === 'Parcel') prefix = 'CP';
  if (articleType === 'Registered') prefix = 'RN';

  let digits = '';
  for (let i = 0; i < 9; i++) {
    digits += Math.floor(Math.random() * 10).toString();
  }
  return `${prefix}${digits}IN`;
}

/**
 * Generate random 8-digit User/Employee ID (e.g. 10048219)
 */
export function generateRandomUserId(): string {
  const num = Math.floor(10000000 + Math.random() * 90000000);
  return num.toString();
}

/**
 * Validates that user ID is strictly an 8-digit numeric number
 */
export function validateUserId(id: string): { isValid: boolean; error?: string } {
  const trimmed = id.trim();
  if (!trimmed) {
    return { isValid: false, error: 'User ID is required.' };
  }
  if (!/^\d{8}$/.test(trimmed)) {
    return {
      isValid: false,
      error: 'User ID must be strictly an 8-digit numeric number (e.g. 10048219).',
    };
  }
  return { isValid: true };
}

