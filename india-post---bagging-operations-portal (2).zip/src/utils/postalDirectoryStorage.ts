import { POSTAL_OFFICES, PostalOfficeSuggestion } from '../data/postalOffices';

const DIRECTORY_STORAGE_KEY = 'dop_postal_offices_directory_v2';
export const DIRECTORY_UPDATE_EVENT = 'dop-postal-directory-updated';

// Retrieve all postal offices from localStorage, merging with defaults
export function getStoredPostalOffices(): PostalOfficeSuggestion[] {
  try {
    const raw = localStorage.getItem(DIRECTORY_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (e) {
    console.error('Failed to parse postal offices directory from localStorage', e);
  }

  // If not stored yet, initialize with defaults
  savePostalOffices(POSTAL_OFFICES);
  return POSTAL_OFFICES;
}

// Save complete directory to localStorage and broadcast event
export function savePostalOffices(offices: PostalOfficeSuggestion[]): void {
  try {
    localStorage.setItem(DIRECTORY_STORAGE_KEY, JSON.stringify(offices));
    window.dispatchEvent(new CustomEvent(DIRECTORY_UPDATE_EVENT, { detail: offices }));
  } catch (e) {
    console.error('Failed to save postal offices directory to localStorage', e);
  }
}

// Add a new office to the directory
export function addPostalOffice(newOffice: PostalOfficeSuggestion): { success: boolean; message: string } {
  const current = getStoredPostalOffices();
  const exists = current.find(
    (o) => o.name.trim().toLowerCase() === newOffice.name.trim().toLowerCase()
  );

  if (exists) {
    return { success: false, message: `Office "${newOffice.name}" already exists in the directory!` };
  }

  const updatedList = [newOffice, ...current];
  savePostalOffices(updatedList);
  return { success: true, message: `Office "${newOffice.name}" added and saved successfully!` };
}

// Update an existing office (name, PIN code, division, parent HO, etc.)
export function updatePostalOffice(
  originalName: string,
  updatedData: Partial<PostalOfficeSuggestion>
): { success: boolean; message: string } {
  const current = getStoredPostalOffices();
  const index = current.findIndex(
    (o) => o.name.trim().toLowerCase() === originalName.trim().toLowerCase()
  );

  if (index === -1) {
    return { success: false, message: `Office "${originalName}" not found in directory!` };
  }

  // If name is changing, check for collision
  if (
    updatedData.name &&
    updatedData.name.trim().toLowerCase() !== originalName.trim().toLowerCase()
  ) {
    const collision = current.find(
      (o, i) => i !== index && o.name.trim().toLowerCase() === updatedData.name!.trim().toLowerCase()
    );
    if (collision) {
      return { success: false, message: `Another office with name "${updatedData.name}" already exists!` };
    }
  }

  const updatedOffice: PostalOfficeSuggestion = {
    ...current[index],
    ...updatedData,
  };

  const updatedList = [...current];
  updatedList[index] = updatedOffice;

  savePostalOffices(updatedList);
  return { success: true, message: `Office "${updatedOffice.name}" updated and saved successfully!` };
}

// Delete an office from directory
export function deletePostalOffice(officeName: string): { success: boolean; message: string } {
  const current = getStoredPostalOffices();
  const filtered = current.filter(
    (o) => o.name.trim().toLowerCase() !== officeName.trim().toLowerCase()
  );

  if (filtered.length === current.length) {
    return { success: false, message: `Office "${officeName}" was not found.` };
  }

  savePostalOffices(filtered);
  return { success: true, message: `Office "${officeName}" deleted successfully.` };
}

// Reset directory to default India Post Indore & National hierarchy
export function resetPostalOfficesToDefault(): PostalOfficeSuggestion[] {
  savePostalOffices(POSTAL_OFFICES);
  return POSTAL_OFFICES;
}
