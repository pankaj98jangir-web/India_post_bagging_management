import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

export type DocumentType = 'label' | 'manifest' | 'maillist';

export interface GeneratedPdfResult {
  blob: Blob;
  blobUrl: string;
  fileName: string;
  download: () => void;
  openInNewWindow: () => void;
}

/**
 * Generates a high-resolution, pure PDF from a target DOM element.
 * Ensures that ONLY the document itself (Bag Label, Bag Manifest, or Despatch Mail List)
 * is included in the PDF, with zero extraneous website layout, buttons, or page elements.
 */
export async function generateDocumentPdf(
  elementOrId: HTMLElement | string,
  docType: DocumentType,
  fileName: string = 'document.pdf'
): Promise<GeneratedPdfResult> {
  const element = typeof elementOrId === 'string' ? document.getElementById(elementOrId) : elementOrId;
  if (!element) {
    throw new Error(`Target document element "${elementOrId}" not found in DOM.`);
  }

  // Use high scale (2.5x) for sharp barcodes and official typography
  const canvas = await html2canvas(element, {
    scale: 2.5,
    useCORS: true,
    logging: false,
    backgroundColor: '#ffffff',
    windowWidth: element.scrollWidth,
    windowHeight: element.scrollHeight,
    onclone: (clonedDoc, clonedEl) => {
      // Ensure element styles are completely visible without print media overrides
      clonedEl.style.boxShadow = 'none';
      clonedEl.style.margin = '0';
    },
  });

  const imgData = canvas.toDataURL('image/png');

  let pdf: jsPDF;

  if (docType === 'label') {
    // 120mm Width x 70mm Height (Department of Posts standard bag label)
    pdf = new jsPDF({
      orientation: 'landscape',
      unit: 'mm',
      format: [120, 70],
      compress: true,
    });
    pdf.addImage(imgData, 'PNG', 0, 0, 120, 70, undefined, 'FAST');
  } else {
    // Standard A4 portrait (210mm x 297mm) for Manifests (Form M-52) and Despatch Mail Lists (Form M-11)
    pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
      compress: true,
    });

    const pageWidth = 210;
    const pageHeight = 297;
    const margin = 6;
    const printWidth = pageWidth - margin * 2;
    const printHeight = (canvas.height * printWidth) / canvas.width;

    if (printHeight <= pageHeight - margin * 2) {
      // Fits on a single A4 page
      pdf.addImage(imgData, 'PNG', margin, margin, printWidth, printHeight, undefined, 'FAST');
    } else {
      // If slight overflow, scale to fit 1 clean page nicely; otherwise split across pages
      const scaleToFitRatio = (pageHeight - margin * 2) / printHeight;
      if (scaleToFitRatio >= 0.82) {
        const fittedW = printWidth * scaleToFitRatio;
        const fittedH = printHeight * scaleToFitRatio;
        const xOffset = (pageWidth - fittedW) / 2;
        pdf.addImage(imgData, 'PNG', xOffset, margin, fittedW, fittedH, undefined, 'FAST');
      } else {
        // Multi-page slicing
        let heightLeft = printHeight;
        let position = margin;
        pdf.addImage(imgData, 'PNG', margin, position, printWidth, printHeight, undefined, 'FAST');
        heightLeft -= (pageHeight - margin * 2);

        while (heightLeft > 0) {
          position = heightLeft - printHeight + margin;
          pdf.addPage();
          pdf.addImage(imgData, 'PNG', margin, position, printWidth, printHeight, undefined, 'FAST');
          heightLeft -= (pageHeight - margin * 2);
        }
      }
    }
  }

  const blob = pdf.output('blob');
  const blobUrl = URL.createObjectURL(blob);

  const download = () => {
    pdf.save(fileName.endsWith('.pdf') ? fileName : `${fileName}.pdf`);
  };

  const openInNewWindow = () => {
    try {
      const opened = window.open(blobUrl, '_blank');
      if (!opened) {
        // If popup is blocked by browser/iframe, trigger direct download
        download();
      }
    } catch {
      download();
    }
  };

  return {
    blob,
    blobUrl,
    fileName,
    download,
    openInNewWindow,
  };
}

/**
 * Prints strictly the target element using an isolated hidden iframe,
 * guaranteeing zero website chrome, headers, navigation tabs, or buttons leak into the printout/PDF.
 */
export function printIsolatedElement(elementId: string, title: string = 'Department of Posts Document') {
  const element = document.getElementById(elementId);
  if (!element) return;

  const iframe = document.createElement('iframe');
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = '0';
  document.body.appendChild(iframe);

  const doc = iframe.contentWindow?.document;
  if (!doc) return;

  const styles = Array.from(document.querySelectorAll('link[rel="stylesheet"], style'))
    .map((el) => el.outerHTML)
    .join('\n');

  doc.open();
  doc.write(`
    <!DOCTYPE html>
    <html>
      <head>
        <title>${title}</title>
        ${styles}
        <style>
          body {
            background: #ffffff !important;
            margin: 0 !important;
            padding: 8px !important;
            display: flex !important;
            justify-content: center !important;
            font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
          }
          @page {
            margin: 4mm;
            size: auto;
          }
          .print-hidden, button, header, nav, aside {
            display: none !important;
          }
        </style>
      </head>
      <body>
        ${element.outerHTML}
      </body>
    </html>
  `);
  doc.close();

  iframe.contentWindow?.focus();
  setTimeout(() => {
    iframe.contentWindow?.print();
    setTimeout(() => {
      try {
        document.body.removeChild(iframe);
      } catch {
        // no-op
      }
    }, 1500);
  }, 400);
}
